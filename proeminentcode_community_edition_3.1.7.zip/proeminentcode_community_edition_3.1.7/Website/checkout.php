<?php


define("_VALID","Yes");

include_once("include/config/config.php");
include_once("include/traffic/traffic.php");


// Get Theme Functions
include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/php/functions.php");


// If shop is disabled
if($GLOBALS['shop_status'] == 0){
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}


// Price Format
function pc_make_price_IPN($x){
	$price = '';
	if($x != '' && $x != ' '){
	    $shop_currency_symbol_value = '';
	    // Thousand Separator
	        $ts = '';
	    if($GLOBALS['shop_currency_ts'] == 'w'){
		    $ts = ' ';
	    }else if($GLOBALS['shop_currency_ts'] == 'c'){
		    $ts = ',';
	    }else{
		    $ts = '.';
	    }
	    // Decimal Separator
	    $ds = '';
	    if($GLOBALS['shop_currency_ds'] == 'w'){
		    $ds = ' ';
	    }else if($GLOBALS['shop_currency_ds'] == 'c'){
		    $ds = ',';
	    }else{
		    $ds = '.';
	    }
	
	
	    $sql = "SELECT * FROM pc_options WHERE option_name='shop_currency' LIMIT 1";
	    $query = $GLOBALS['mysqli']->query($sql);	
	    if($query === FALSE){
	        $shop_currency_symbol_value = '';
	    }else{
		    $count = $query->num_rows;
		    if($count > 0){
			    $row = $query->fetch_assoc();
			    $cur = $row['option_value'];
				$shop_currency_array = array(
                    '$' => 'AUD',
	                '€' => 'EUR',
	                '$' => 'CAD',
	                '¥' => 'CNY',
	                'Kč' => 'CZK',
	                'Rs.' => 'INR',
	                '¥' => 'JPY',
	                'Rs.' => 'NPR',
	                '£' => 'GBP',
	                'lei' => 'RON',
	                'руб.' => 'RUB',
	                '₺' => 'TRY',
	                '₴' => 'UAH',
	                '$' => 'USD'
                );
                foreach($shop_currency_array as $k => $v){
                    if(preg_match("/$v/", $cur)){
                        break;
                    }else{
                        $shop_currency_symbol_value = "$";
                    }
                }
                $shop_currency_symbol_value = $k;
		    }else{
	            $shop_currency_symbol_value = '';
		    }
    	}
	    $price = '<b>' . $shop_currency_symbol_value . '</b> ' . number_format($x, $GLOBALS['shop_currency_nd'], $ds, $ts);
	}
	return $price;
}

$what_is_this = '';

// Page Variables
$message = '';
$title = $user_language['website.checkout.title'];
$keywords = '';
$description = '';
$css = '';
$top_script = '';
$bottom_script = '';
$page_cotent_class = 'col-md-8';
$page_sidebar_class = 'col-md-4';
$content = '';
$oder_details = '';

// Bank Variables
$bank_accountName = '';
$bank_accountNumber = '';
$bank_bankName = '';
$bank_sortCode = '';
$bank_IBAN = '';
$bank_BIC = '';
$bank_transfer_info = '';

$checkout_name = '';
$checkout_type = '';
if(isset($_GET['id'])){
	$checkout_type = $_GET['id'];
    if($checkout_type == 'bank-transfer'){
		$what_is_this = 'bank-transfer';
		// Some Stuff
		$title = $user_language['website.checkout.text.banktransfer'];
		$oder_details = '<p>' . $user_language['website.checkout.text.banktransfer.details'] . '<p>';
		
		// Details 
		$sql_bankTransfer = "SELECT * FROM pc_gateways WHERE gateway_name='Bank Transfer' AND gateway_status='1' AND gateway_configured='1' LIMIT 1";
		$query_bankTransfer = $mysqli->query($sql_bankTransfer);
		if($query_bankTransfer === FALSE){
			include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
            exit();
		}else{
			$count_bankTransfer = $query_bankTransfer->num_rows;
			if($count_bankTransfer > 0){
				
				$row_bankTransfer = $query_bankTransfer->fetch_assoc();
				//
				$bank_accountName = $row_bankTransfer['gateway_var_1'];
				if($bank_accountName != '' && $bank_accountName != ' '){
					$bank_accountName = '<p>' . $user_language['website.checkout.text.accountname'] . ': <b>' . $bank_accountName . '</b></p>';
					$bank_transfer_info .= $bank_accountName;
				}
				
				//
				$bank_accountNumber = $row_bankTransfer['gateway_var_2'];
				if($bank_accountNumber != '' && $bank_accountNumber != ' '){
					$bank_accountNumber = '<p>' . $user_language['website.checkout.text.accountnumber'] . ': <b>' . $bank_accountNumber . '</b></p>';
					$bank_transfer_info .= $bank_accountNumber;
				}
				
				//
				$bank_bankName = $row_bankTransfer['gateway_var_3'];
				if($bank_bankName != '' && $bank_bankName != ' '){
					$bank_bankName = '<p>' . $user_language['website.checkout.text.bankname'] . ': <b>' . $bank_bankName . '</b></p>';
					$bank_transfer_info .= $bank_bankName;
				}
				
				//
				$bank_sortCode = $row_bankTransfer['gateway_var_4'];
				if($bank_sortCode != '' && $bank_sortCode != ' '){
					$bank_sortCode = '<p>' . $user_language['website.checkout.text.sortcode'] . ': <b>' . $bank_sortCode . '</b></p>';
					$bank_transfer_info .= $bank_sortCode;
				}
				
				//
				$bank_IBAN = $row_bankTransfer['gateway_var_5'];
				if($bank_IBAN != '' && $bank_IBAN != ' '){
					$bank_IBAN = '<p>' . $user_language['website.checkout.text.IBAN'] . ': <b>' . $bank_IBAN . '</b></p>';
					$bank_transfer_info .= $bank_IBAN;
				}
				
				//
				$bank_BIC = $row_bankTransfer['gateway_var_6'];
				if($bank_BIC != '' && $bank_BIC != ' '){
					$bank_BIC = '<p>' . $user_language['website.checkout.text.bic'] . ': <b>' . $bank_BIC . '</b></p>';
					$bank_transfer_info .= $bank_BIC;
				}
				
			}else{
				include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
                exit();
			}
		}
	}else if($checkout_type == 'cash'){
		$title = $user_language['website.checkout.text.cash'];
		$oder_details = '<p>' . $user_language['website.checkout.text.cash.details'] . '<p>';
		$what_is_this = 'cash';
	}else{
		include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
        exit();
	}
}else{
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}


// Post Variables
$post_country = '';
$post_firstname = '';
$post_lastname = '';
$post_companyName = '';
$post_address = '';
$post_city = '';
$post_state = '';
$post_zipCode = '';
$post_email = '';
$post_phone = '';
$post_cart_string = '';
$post_order_member = '';
$post_total = '';
$post_subtotal = '';
$post_discount = '';
$post_taxes = '';
$post_shipping = '';



// CHECK USER STATUS
if($user_status == true){
	$post_order_member = $session_userId;
    $sql_getMember = "SELECT * FROM pc_members WHERE member_ID='$session_userId' AND member_status='g' AND 	member_activated='1' LIMIT 1";
    $query_getMember = $mysqli->query($sql_getMember);
    if($query_getMember === FALSE){
	   //
    }else{
	    $count_getMember = $query_getMember->num_rows;
	    if($count_getMember > 0){
		    $row_getMember = $query_getMember->fetch_assoc();
		    $post_firstname = $row_getMember['member_firstname'];
            $post_lastname = $row_getMember['member_lastname'];
            $post_companyName = $row_getMember['member_company'];
            $post_email = $row_getMember['member_email'];
            $post_phone = $row_getMember['member_phone'];
            $post_country = $row_getMember['member_country'];
		    $post_country = '<option value="' . $post_country . '">' . $post_country . '</option>';
            $post_state = $row_getMember['member_state'];
            $post_city = $row_getMember['member_city'];
            $post_address = $row_getMember['member_address'];
            $post_zipCode = $row_getMember['member_zipcode'];
	    }else{
		    //
	    }
    }
}


$cart_table = '';
$cart_product_string = '';
// START RENDER THE CART
$cartOutput = "";
$cartTotal = "";
$cartSubtotal = "";
$cartTaxes = "";
$cartDiscount = "";
$cart_taxes = '';
$cart_shipping = '';
$taxes_amount = 0;
$shipping_amount = '';
$cart_items = '';

$digital_table = '';
$digital_prodcuts = 0;
$digital_table_values = '';

// CART SYSTEM
if(!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"]) < 1){
	header("location: " . $GLOBALS['url'] . "/" . pc_get_page_url($GLOBALS['website_cart']) . "/");
	exit();
}else{
	// START COUPONS
$coupon_code = '';
$coupon_type = '';
$coupon_discount = '';
$coupon_number = '';
$coupon_form = '';
// Coupons status
if($GLOBALS['shop_coupons'] == 1){
	
	// Coupon Form
	$coupon_form = '
	    <h3>' . $user_language['website.cart.text.coupon'] . '</h3>
        <hr>
		<form action="' . $GLOBALS['url'] . '/cart" method="post" class="form-inline">
		    <div class="form-group">
                <label for="inputPassword2" class="sr-only"></label>
                <input type="text" name="coupon_code" class="form-control" maxlength="50" placeholder="' . $user_language['website.form.placefolder.couponcode'] . '" style="width: 204px;" autocomplete="off" maxlength="50">
            </div>
            <input type="submit" class="btn btn-info" value="' . $user_language['website.form.button.applycoupon'] . '">
		</form>
		<br>
	';
	
	// Apply Coupon
    if(isset($_POST['coupon_code'])){
		$coupon_code = $_POST['coupon_code'];
	    $coupon_code = $mysqli->real_escape_string($coupon_code);
	    $sql_coupon = "SELECT * FROM pc_coupons WHERE coupon_code='$coupon_code' AND coupon_status='1' AND DATE(CURDATE()) < DATE(coupon_expire) LIMIT 1";
	    $query_coupon = $mysqli->query($sql_coupon);
	    if($query_coupon === FALSE){
		   $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.cart.alert.couponwrong'] . '</div>';
	    }else{
			$count_coupon = $query_coupon->num_rows;
			if($count_coupon > 0){
		        $row_coupon = $query_coupon->fetch_assoc();
				$coupon_times = $row_coupon['coupon_times'];
				$coupon_type =  $row_coupon['coupon_type'];
				$coupon_discount = $row_coupon['coupon_discount'];
				if($coupon_times != '' && $coupon_times != ' '){
					if($coupon_times == 0){
						$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.cart.alert.couponwrong'] . '</div>';
					}else{
						$_SESSION['coupon_code'] = $coupon_code;
					    $_SESSION['coupon_type'] = $coupon_type;
					    $_SESSION['coupon_discount'] = $coupon_discount;
					    $update_times = $coupon_times + 1;
					    // Update used times
					    $sql_updateTimes = "UPDATE pc_coupons SET coupon_used='$update_times' WHERE coupon_code='$coupon_code' AND coupon_status='1' LIMIT 1";
					    $query_updateTimes = $mysqli->query($sql_updateTimes);
					}
				}else{
					$_SESSION['coupon_code'] = $coupon_code;
					$_SESSION['coupon_type'] = $coupon_type;
					$_SESSION['coupon_discount'] = $coupon_discount;
					$update_times = $coupon_times + 1;
					// Update used times
					$sql_updateTimes = "UPDATE pc_coupons SET coupon_used='$update_times' WHERE coupon_code='$coupon_code' AND coupon_status='1' LIMIT 1";
					$query_updateTimes = $mysqli->query($sql_updateTimes);
				}
	        }else{
		        $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.cart.alert.couponwrong'] . '</div>';
	        }
	    }
    }else{
	    if(isset($_SESSION["coupon_code"]) && isset($_SESSION["coupon_type"]) && isset($_SESSION["coupon_discount"])){
		    $coupon_code = $_SESSION['coupon_code'];
            $coupon_type = $_SESSION['coupon_type'];
            $coupon_discount = $_SESSION['coupon_discount'];
	    }else{
			$_SESSION['coupon_code'] = '';
			$_SESSION['coupon_type'] = '';
			$_SESSION['coupon_discount'] = '';
		}
    }
}
// END COUPONS
	// START CART
	//Begin Table
	$cart_table .= '
        <h3>' . $user_language['website.cart.text.shoppingcart'] . '</h3>
        <hr>
		<div class="table-responsive">
		    <table class="table table-striped">
			    <thead>
                    <tr>
					    <th>#</th>
                        <th>' . $user_language['website.cart.text.price'] . '</th>
                        <th>' . $user_language['website.cart.text.total'] . '</th>
                    </tr>
                </thead>
			<tbody>
		';
	$i = 0; 
	if(isset($_SESSION["cart_array"])){
		// Start Loop Products
        foreach($_SESSION["cart_array"] as $each_item){ 
	        $item_id = $each_item['item_id'];
		
		// Features String
		$item_feature = '';
		
		
		// PayPal Product Options
		$on0 = '';
		$os0 = '';
		$on1 = '';
		$os1 = '';
		$on2 = '';
		$os2 = '';
		
		
		// 2Checkout Product Options
		$o_1_name = '';
		$o_1_value = '';
		$o_2_name = '';
		$o_2_value = '';
		$o_3_name = '';
		$o_3_value = '';
		
		
		// Feature 1
		$item_feature_1 = '';
		$item_option_1_name = $each_item['option_1_name'];
		$item_option_1_value = $each_item['option_1_value'];
		if($item_option_1_name != '' && $item_option_1_name != ' '){
			if($item_option_1_value != '' && $item_option_1_value != ' '){
				$item_feature_1 = '<span>' . $item_option_1_name .': </span>' . $item_option_1_value . '<br>';
			}
		}
		
		// Feature 2
		$item_feature_2 = '';
		$item_option_2_name = $each_item['option_2_name'];
		$item_option_2_value = $each_item['option_2_value'];
		if($item_option_2_name != '' && $item_option_2_name != ' '){
			if($item_option_2_value != '' && $item_option_2_value != ' '){
				$item_feature_2 = '<span>' . $item_option_2_name .': </span>' . $item_option_2_value . '<br>';
			}
		}
								
		// Feature 3
		$item_feature_3 = '';
		$item_option_3_name = $each_item['option_3_name'];
		$item_option_3_value = $each_item['option_3_value'];
		if($item_option_3_name != '' && $item_option_3_name != ' '){
			if($item_option_3_value != '' && $item_option_3_value != ' '){
				$item_feature_3 = '<span>' . $item_option_3_name .': </span>' . $item_option_3_value . '';
			}
		}
								
		$item_feature = $item_feature_1 . $item_feature_2 . $item_feature_3;
		                        
		// Get product details						
		$sql_getProduct = "SELECT * FROM pc_products WHERE product_ID='$item_id' AND product_status='p' OR 	product_status='h' LIMIT 1";
		$query_getProduct = $mysqli->query($sql_getProduct);
		if($query_getProduct === FALSE){
			// No products table
		}else{
			$count_getProduct = $query_getProduct->num_rows;
		    if($count_getProduct > 0){
				while($row_getProduct = $query_getProduct->fetch_assoc()) {
				    $product_ID = $row_getProduct["product_ID"];
					$product_url = $row_getProduct["product_url"];
			        $product_name = $row_getProduct["product_name"];
			        $product_price = $row_getProduct["product_price"];
					$product_virtual = $row_getProduct["product_virtual"];
					
					
					// Shipping
					if($GLOBALS['shop_free_shipping'] == 1){
						if($product_virtual == 0){
							
							$product_weight = $row_getProduct["product_weight"];

							
							
							$product_dimension_length = $row_getProduct["product_dimension_length"];
							$product_dimension_width = $row_getProduct["product_dimension_width"];
							$product_dimension_height = $row_getProduct["product_dimension_height"];
							
							$product_shipping = $GLOBALS['shop_shipping_cost_weight'] * $product_weight + $GLOBALS['shop_shipping_cost_dimensions'] * $product_dimension_length * $product_dimension_width * $product_dimension_height;
							
							$product_shipping = $product_shipping * $each_item['quantity'];
							
							$shipping_amount = $shipping_amount + $product_shipping;
						}
					}
					
		        }
		        
				$product_total = '';
				$pricetotal = $product_price * $each_item['quantity'];
				$product_total = $pricetotal ;
		        $cartTotal = $pricetotal + $cartTotal;
		        //setlocale(LC_MONETARY, "en_US");
                //$pricetotal = money_format("%10.2n", $pricetotal);
		        $x = $i + 1;
				

	
				// Clean Vars
				$item_option_1_name_string = '';
				if($item_option_1_name == '' || $item_option_1_name == ' '){
					$item_option_1_name_string = 'NULL';
				}else{
					$item_option_1_name_string = $item_option_1_name;
				}
				$iitem_option_1_value_string = '';
				if($item_option_1_value == '' || $item_option_1_value == ' '){
					$item_option_1_value_string = 'NULL';
				}else{
					$item_option_1_value_string = $item_option_1_value;
				}
				
				$item_option_2_name_string = '';
				if($item_option_2_name == '' || $item_option_2_name == ' '){
					$item_option_2_name_string = 'NULL';
				}else{
					$item_option_2_name_string = $item_option_2_name;
				}
				$item_option_2_value_string = '';
				if($item_option_2_value == '' || $item_option_2_value == ' '){
					$item_option_2_value_string = 'NULL';
				}else{
					$item_option_2_value_string = $item_option_2_value;
				}
				
				$item_option_3_name_string = '';
				if($item_option_3_name == '' || $item_option_3_name == ' '){
					$item_option_3_name_string = 'NULL';
				}else{
					$item_option_3_name_string = $item_option_3_name;
				}
				$item_option_3_value_string = '';
				if($item_option_3_value == '' || $item_option_3_value == ' '){
					$item_option_3_value_string = 'NULL';
				}else{
					$item_option_3_value_string = $item_option_3_value;
				}
				
				$cart_items .= '
				    <tr>
				    <td style="padding: 8px;line-height: 1.42857143;vertical-align: top;"><b>' . $x . '.</b></td>
				    <td style="padding: 8px;line-height: 1.42857143;vertical-align: top;"><b><a href="' . $GLOBALS['url'] . '/product/' . $product_url . '" target="_blank" style="color: #337ab7;text-decoration: none;">' . $product_name . '</a></b></td>
					<td style="padding: 8px;line-height: 1.42857143;vertical-align: top;"><b style="font-weight: bold;">' . $item_feature . '</b></td>
					<td style="padding: 8px;line-height: 1.42857143;vertical-align: top;">' . $each_item['quantity'] . '</td>
					<td width="100" style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;"><b>' . pc_make_price_IPN($product_price) . '</b></td>
                    <td width="100" style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;"><b>' . pc_make_price_IPN($product_total) . '</b></td>
				</tr>
				';
				
				
				// Create String Products
		        $cart_product_string .= $item_id . '-{' . $product_price . '|' . $each_item['quantity'] . '|' . $item_option_1_name_string . '|' . $item_option_1_value_string . '|' . $item_option_2_name_string . '|' . $item_option_2_value_string . '|' . $item_option_3_name_string . '|' . $item_option_3_value_string . '},'; 
		        
				// Cart Content Product
		        $i++;
			}else{
				// No products found
			}	
		} 
        }
		// End Loop Products
	}else{
		unset($_SESSION["cart_array"]);
	}
	
	
	$cartTotal_amount = $cartTotal;
	// If Discount
	$cartDiscount_amount = 0;
	if($GLOBALS['shop_coupons'] == 1){
		if($coupon_code != '' && $coupon_type != '' && $coupon_discount != ''){
			if($coupon_type == 'a'){
				$cartDiscount_amount = $cartTotal_amount - $coupon_discount;
			}else{
				$cartDiscount_amount = $cartTotal_amount/100 * $coupon_discount;
			}
		}
	}
	
	$cartSubtotal_amount = 0;
	$cartSubtotal_amount = $cartTotal;
	$cartSubtotal = $cartTotal;
	$post_subtotal = $cartSubtotal;
	$cartTotal = $cartTotal - $cartDiscount_amount;
	
	
	// Taxes
	if($GLOBALS['shop_taxes'] != '' && $GLOBALS['shop_taxes'] != ''){
		$x = $x + 1;
		$taxes_amount = $cartSubtotal/100 * $GLOBALS['shop_taxes'];
		$post_taxes = $taxes_amount;
		$post_taxes = money_format("%10.2n", $post_taxes);
		$cart_taxes = '
		    <tr>
                <td>' . $user_language['website.cart.text.taxes'] .' ' . $GLOBALS['shop_taxes'] . '%</h5></td>
                <td><strong>' . pc_make_price($taxes_amount) . '</strong></h5></td>
            </tr>
		';
	}
	
    // Coupons
    if($GLOBALS['shop_coupons'] == 1){
	    if($cartDiscount_amount > 0){
		    $cartDiscount_amount = preg_replace('#[^0-9.,]#i', '', $cartDiscount_amount);
		    if($coupon_code != '' && $coupon_code != ' '){
			    $x = $x + 1;
			}
	        $post_discount = $cartDiscount_amount;
			$post_discount = money_format("%10.2n", $post_discount);
		    $cartDiscount = '
				    <tr>
                        <td></td>
                        <td></td>
                        <td>' . $user_language['website.cart.text.discount'] .'</td>
                        <td><strong>- ' . pc_make_price($cartDiscount_amount) . '</strong></td>
                    </tr>
		    ';
	    }
	}
	
	
	// SHIPPING
	$co_shipping = '';
	$pp_shipping = '';
	if($GLOBALS['shop_free_shipping'] == 1){
		if($shipping_amount > 0){
			
			$x = $x + 1;
			
			// Output
			$post_shipping = $shipping_amount;
			$post_shipping = money_format("%10.2n", $post_shipping);
			$cart_shipping = '
			    <tr>
					<td></td>
                    <td></td>
                    <td>' . $user_language['website.cart.text.shippingcosts'] . '</td>
                    <td><strong>' . pc_make_price($shipping_amount) . '</strong></td>
                </tr>
			';
			
		}
	}else{
		$shipping_amount = 0;
	}
	
	 
	 
    //$cartTotal = money_format("%10.2n", $cartTotal);
	$cartTotal = $cartTotal + $taxes_amount + $shipping_amount;
	$post_total = $cartTotal;
	$post_total = money_format("%10.2n", $post_total);
    $cartTotal = pc_make_price($cartTotal);
	//$cartSubtotal = money_format("%10.2n", $cartSubtotal);
	$cartSubtotal = pc_make_price($cartSubtotal);	
							
							
	
	// Min Order
	$shop_min_order_val = 0;
	if($GLOBALS['shop_min_order'] != '' && $GLOBALS['shop_min_order'] != '' && $GLOBALS['shop_min_order'] > 0){
	    $shop_min_order_val = money_format("%10.2n", $GLOBALS['shop_min_order']);
		if($cartSubtotal_amount < $shop_min_order_val){
			$checkout_methods = '<div class="alert alert-info" role="alert">' . $user_language['website.cart.alert.minorder'] . ' ' . pc_make_price($shop_min_order_val) . '</div>';
		}
	}
	
	
	// Min Order
	$shop_max_order_val = 0;
	if($GLOBALS['shop_max_order'] != '' && $GLOBALS['shop_max_order'] != '' && $GLOBALS['shop_max_order'] > 0){
	    $shop_max_order_val = money_format("%10.2n", $GLOBALS['shop_max_order']);
		if($cartSubtotal_amount > $shop_max_order_val){
			$checkout_methods = '<div class="alert alert-info" role="alert">' . $user_language['website.cart.alert.maxnorder'] . ' ' . pc_make_price($shop_max_order_val) . '</div>';
		}
	}
	
	
							
							
	// Close Table
    $cart_table .= '
		<tr>
                                                <td></td>
                                                <td></td>
                                                <td>' . $user_language['website.cart.text.subtotal'] . '</td>
                                                <td><strong>' . $cartSubtotal . '</strong></td>
												<td></td>
                                            </tr>
											' . $cartDiscount . '
											' . $cart_taxes . '
											' . $cart_shipping . '
                                            <tr>
												<td></td>
                                                <td></td>
                                                <td>' . $user_language['website.cart.text.total'] . '</td>
                                                <td><strong>' . $cartTotal . '</strong></td>
                                            </tr>
							            </tbody>
							        </table>
									</div>
									';
	// END CART
	// START CONTENT
	// END CONTENT
	if(isset($_POST['country'])){
	
	// Post Variables
	$post_country = $_POST['country'];
    $post_firstname = $_POST['first_name'];
    $post_lastname = $_POST['last_name'];
    $post_companyName = $_POST['company_name'];
    $post_address = $_POST['address'];
    $post_city = $_POST['city'];
    $post_state = $_POST['state'];
    $post_zipCode = $_POST['postcode'];
    $post_email = $_POST['email'];
    $post_phone = $_POST['phone'];
	$post_phone = $_POST['phone'];
	$post_cart_string = $_POST['cart_string'];
	
	$x = 0;
	
	
	// Country  | Count 1
	if($post_country != '' && $post_country != ' '){
		if(strlen($post_country) < 51){
			$post_country_copy = preg_replace('#[^A-Za-z ]#i', '', $post_country);
			if($post_country == $post_country_copy){
				$post_country = $mysqli->real_escape_string($post_country);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.country.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.country.len'] . '</div>';
		}
	}else{
	    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.country.empty'] . '</div>';
    }
	
	
	// First Name | Count 2
	if($x == 1){
		if($post_firstname != '' && $post_firstname != ' '){
			if(strlen($post_firstname) < 101){
				$post_firstname_copy = strip_tags($post_firstname);
				$post_firstname_copy = stripslashes($post_firstname_copy);
				if($post_firstname == $post_firstname_copy){
					$post_firstname = $mysqli->real_escape_string($post_firstname);
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.firstname.char'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.firstname.len'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.firstname.empty'] . '</div>';
		}
	}
	
	
	// Last Name | Count 3
	if($x == 2){
	    if($post_lastname != '' && $post_lastname != ' '){
			    if(strlen($post_lastname) < 101){
				    $post_lastname_copy = strip_tags($post_lastname);
				    $post_lastname_copy = stripslashes($post_lastname_copy);
				    if($post_lastname == $post_lastname_copy){
					    $post_lastname = $mysqli->real_escape_string($post_lastname);
						$x = $x + 1;
				    }else{
					    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.lastname.char'] . '</div>';
				    }
			    }else{
				    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.lastname.len'] . '</div>';
			    }
		    }else{
			    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.lastname.empty'] . '</div>';
		    }
	}
	
	
	// Company Name | Count 4
	if($x == 3){
		if($post_companyName != '' && $post_companyName != ' '){
		    if(strlen($post_companyName) < 151){
				$post_companyName = htmlentities($post_companyName, ENT_QUOTES);
				$post_companyName = $mysqli->real_escape_string($post_companyName);
				$x = $x + 1;
		    }else{
			    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.companyname.len'] . '</div>';
			}
		}else{
		    $post_companyName = '';
	        $x = $x + 1;
		}
	}
	
	
	// Address | Count 5
	if($x == 4){
		if($post_address != '' && $post_address != ' '){
		    if(strlen($post_address) < 501){
				$post_address = htmlentities($post_address, ENT_QUOTES);
				$post_address = $mysqli->real_escape_string($post_address);	
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.address.len'] . '</div>';
			}
		}else{
		    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.address.empty'] . '</div>';
	    }
	}
	
	
	// City | Count 6
	if($x == 5){
		if($post_city != '' && $post_city != ' '){
		    if(strlen($post_city) < 101){
				$post_city = htmlentities($post_city, ENT_QUOTES);
				$post_city = $mysqli->real_escape_string($post_city);	
				$x = $x + 1;	
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.city.len'] . '</div>';
			}
	    }else{
	        $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.city.empty'] . '</div>';
	    }
	}
	
	
	// State | Count 7
	if($x == 6){
		if($post_state != '' && $post_state != ' '){
		    if(strlen($post_state) < 101){
				$post_state = htmlentities($post_state, ENT_QUOTES);
				$post_state = $mysqli->real_escape_string($post_state);
				$x = $x + 1;	
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.state.len'] . '</div>';
			}
		}else{
			$post_state = '';
		    $x = $x + 1;
	    }
	}
	
	
	// Zip Code | Count 8
	if($x == 7){
		if($post_zipCode != '' && $post_zipCode != ' '){
		    if(strlen($post_zipCode) < 33){
			    $post_zipCode_copy =  preg_replace('#[^A-Za-z0-9]#i', '', $post_zipCode);
				if($post_zipCode == $post_zipCode_copy){
				    $post_zipCode = $mysqli->real_escape_string($post_zipCode);
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.zipcode.char'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.zipcode.len'] . '</div>';
			}
		}else{
		    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.zipcode.empty'] . '</div>';
	    }
	}
	
	
	// Email | Count 9
	if($x == 8){
		if($post_email != '' && $post_email != ' '){
		    if(strlen($post_email) < 256){
			    $post_email = filter_var($post_email, FILTER_SANITIZE_EMAIL);
		        if(filter_var($post_email, FILTER_VALIDATE_EMAIL)){
					$email_check = pc_member_check_email($post_email, $session_userId);
					if($email_check == false){
						$x = $x + 1;
						$post_email = $mysqli->real_escape_string($post_email);
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.email.taken'] . '</div>';
					}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.email.wrong'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.email.len'] . '</div>';
			}
		}else{
		    $message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.email.empty'] . '</div>';
	    }
	}
	
	
	// Phone | Count 10
	if($x == 9){
		if($post_phone != '' && $post_phone != ' '){
		    if(strlen($post_phone) < 16){
			    $post_phone_copy = preg_replace('#[^0-9]#i', '', $post_phone);
				if($post_phone == $post_phone_copy){
				    $post_phone = $mysqli->real_escape_string($post_phone);
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.phone.char'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.phone.len'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.myaccount.alert.phone.empty'] . '</div>';
		}
	}
	
	// Cart String | Count 11
	if($x == 10){
		if($post_cart_string == $cart_product_string){
	        $x = $x + 1;
			$post_cart_string = $mysqli->real_escape_string($post_cart_string);
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $user_language['website.checkout.alert.products.wrong'] . '</div>';
		}
	}
	
	// Final
	if($x == 11){
		$post_payment_currency_value = $GLOBALS['shop_currency'];
		$post_payment_status = 'pending';
		
		
		
		if($what_is_this == 'bank-transfer'){
		    $post_order_payment_type = 'bank transfer';
		    $method = 'Bank Transfer';
	    }else if($what_is_this == 'cash'){
			$post_order_payment_type = 'cash delivery';
		    $method = 'Cash on Delivery';
		}
		
		
		// Affiliate Thingy
		$post_affiliate_ID = '';
		$post_affiliate_fee = '';
		if($GLOBALS['affiliate_program'] == 1){
			
			if(isset($_SESSION['affiliate_idx'])){
				
				// Session
				$post_affiliate_ID = preg_replace('#[^0-9]#', '', $_SESSION['affiliate_idx']);
				
				// Check if affiliate ok
				if(pc_affiliate_account_check($post_affiliate_ID)){
					
					// Calculate affiliate fee
					$post_affiliate_fee = $cartSubtotal_amount/100 * $GLOBALS['affiliate_commission'];
					$post_affiliate_fee = money_format("%10.2n", $post_affiliate_fee);
					
				}
				
			}else if(isset($_COOKIE['affiliate_idy'])){
				
				// Cookie
				$post_affiliate_ID = preg_replace('#[^0-9]#', '', $_COOKIE['affiliate_idy']);
				
				// Check if affiliate ok
				if(pc_affiliate_account_check($post_affiliate_ID)){
					
					// Calculate affiliate fee
					$post_affiliate_fee = $cartSubtotal_amount/100 * $GLOBALS['affiliate_commission'];
					$post_affiliate_fee = money_format("%10.2n", $post_affiliate_fee);
					
				}
				
			}else{
				// do nothing
			}
			
		}
		
		
		$sql_updateMember = "
		    INSERT INTO pc_orders(
			    order_products,
				order_member,
				order_payer_email,
				order_phone,
				order_firstname,
				order_lastname,
				order_company,
				order_method,
				order_total,
				order_discount,
				order_taxes,
				order_shipping,
				order_payment_currency,
				order_payment_type,
				order_payment_status,
				order_address_street,
				order_address_city,
				order_address_state,
				order_address_zip,
				order_country,
				order_affiliate_ID,
				order_affiliate_fee,
				order_date
			) VALUES(
			    '$post_cart_string',
				'$post_order_member',
				'$post_email',
				'$post_phone',
				'$post_firstname',
				'$post_lastname',
				'$post_companyName',
				'$method',
				'$post_total',
				'$post_discount',
				'$post_taxes',
				'$post_shipping',
				'$post_payment_currency_value',
				'$post_order_payment_type',
				'$post_payment_status',
				'$post_address',
				'$post_city',
				'$post_state',
				'$post_zipCode',
				'$post_country',
				'$post_affiliate_ID',
				'$post_affiliate_fee',
				now()
			)";
		$query_updateMember = $mysqli->query($sql_updateMember);
		if($query_updateMember === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $uer_language['website.checkout.alert.banktransfer.crash'] . '</div>';
			unset($_SESSION["cart_array"]);
			if(isset($_SESSION["coupon_code"]) && isset($_SESSION["coupon_type"]) && isset($_SESSION["coupon_discount"])){
		    unset($_SESSION['coupon_code']);
            unset($_SESSION['coupon_type']);
            unset($_SESSION['coupon_discount']);
			}
		}else{
			// Clean Cart
			unset($_SESSION["cart_array"]);
			if(isset($_SESSION["coupon_code"]) && isset($_SESSION["coupon_type"]) && isset($_SESSION["coupon_discount"])){
		    unset($_SESSION['coupon_code']);
            unset($_SESSION['coupon_type']);
            unset($_SESSION['coupon_discount']);
			}
			
			$order_id = $mysqli->insert_id;
			
			$secret_key = md5($order_id);
			
			//////////////////////////////////
			$product_items_array = '';
			$product_items_array = explode(",", $post_cart_string);
			$product_items_array = array_slice($product_items_array, 0, 1000000);
			$hash_num = 1;
			$x = 0;
			foreach($product_items_array as $k =>$key){
				// Product String
				$item = $product_items_array[$k];
				$item_array = explode("-", $item);
				// Product ID
				$item_product_ID = preg_replace('#[^0-9]#i', '', $item_array[0]);
				if($item_product_ID != '' && $item_product_ID != ' ' && $item_product_ID != 0){
					if (!isset($item_array[1])) {
                        $item_array[1] = NULL;
                    }
				    $item_product_values = $item_array[1];
					
					$sql_getDigitalProduct = "SELECT * FROM pc_products WHERE product_ID='$item_product_ID' AND product_virtual='1' AND product_downloadable='1' LIMIT 1";
					$query_getDigitalProduct = $mysqli->query($sql_getDigitalProduct);
					if($query_getDigitalProduct === FALSE){
						
					}else{
						$count_getDigitalProduct = $query_getDigitalProduct->num_rows;
						if($count_getDigitalProduct > 0){
							$row_getDigitalProduct = $query_getDigitalProduct->fetch_assoc();
							$product_ID_D = $row_getDigitalProduct['product_ID'];
							$product_limits = $row_getDigitalProduct['product_limits'];
					        $product_expiry = $row_getDigitalProduct['product_expiry'];
					        if($product_expiry != '' && $product_expiry != ' ' && $product_expiry != 0){
						        $one_day = date("Y-m-d H:i:s");
						        $date = date_create($one_day);
                                date_add($date, date_interval_create_from_date_string($product_expiry . ' days'));
                                $product_expiry = date_format($date, 'Y-m-d H:i:s');
								$sql_digitalProduct = "INSERT INTO pc_products_virtualDownloadable(product_id, order_id, order_key, user_email, user_id, downloads_remaining, access_expires, permission_date) VALUES('$product_ID_D','$order_id','$secret_key','$post_email','$post_order_member','$product_limits','$product_expiry',now())";
							    $mysqli->query($sql_digitalProduct);
							    $digital_prodcuts = $digital_prodcuts + 1;
					        }
						}
					}
					
				}
			}
			
			//////////////////////////////////
		    //
		// Digital Products
		if($digital_prodcuts > 0){
			$sql_updateDigital = "UPDATE pc_products_virtualDownloadable SET order_id='$order_id' WHERE order_key='$order_verify_sign'";
			$query_updateDigital = $mysqli->query($sql_updateDigital);
			if($query_updateDigital === FALSE){
				//
			}else{
				
				$sql_createLinks = "SELECT * FROM pc_products_virtualDownloadable WHERE order_key='$secret_key' AND order_id='$order_id'";
				$query_createLinks = $mysqli->query($sql_createLinks);
				if($query_createLinks === FALSE){
					
				}else{
					$count_createLinks = $query_createLinks->num_rows;
					if($count_createLinks > 0){
						$digital_table .= '
						    <h3>' . $user_language['website.payment.text.digitalproducts'] . '</h3>
							<p>' . $user_language['website.checkout.text.rememberdownload'] . '</p>
							';
						while($row_createLinks = $query_createLinks->fetch_assoc()){
							$dpp = '';
							
							$product_id = $row_createLinks['product_id'];
							// Get dpp
							$dpp = $row_createLinks['permission_id'];
							
							$download_product_name = pc_get_product_name($product_id);
							$digital_table .= '<p><a href="' . $GLOBALS['url'] . '/download?dpp=' . $dpp . '&pid=' . $product_id . '&oid=' . $order_id . '&okey=' . $secret_key . '">' . $user_language['website.download.title'] . ' ' . $download_product_name . '</a></p>';
						}
					}
				}
			}
		}
			
			
			// TR
		$tr_discount = '';
		$tr_taxes = '';
		$tr_shipping = '';
		
		
		// Discount
		if($post_discount != '' && $post_discount != ' ' && $post_discount != 0){
			$tr_discount = '
			    <tr>
				<td colspan="5" style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;"><b>' . $user_language['website.cart.text.discount'] . '</b></td>
                <td style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;"><b>- ' . pc_make_price_IPN($post_discount) . '</b></td>
				</tr>
			';
		}
		
		
		// Taxes
		if($post_taxes != '' && $post_taxes != ' ' && $post_taxes != 0){
			$tr_taxes = '
			    <tr>
				<td colspan="5" style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;"><b>' . $user_language['website.cart.text.taxes'] . '</b></td>
                <td style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;"><b>' . pc_make_price_IPN($post_taxes) . '</b></td>
				</tr>
			';
		}
		
		
		// Shipping
		if($post_shipping != '' && $post_shipping != ' ' && $post_shipping != 0){
			$tr_shipping = '
			    <tr>
				<td colspan="5"  style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;"><b>' . $user_language['website.cart.text.shippingcosts'] . '</b></td>
                <td style="padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;"><b>' . pc_make_price_IPN($post_shipping) . '</b></td>
				</tr>
			';
		}

			
			// Get Ready for email
			if($what_is_this == 'bank-transfer'){
			    $to = $post_email;
		    	$from = $GLOBALS['auto_email'];
			    $subject = $user_language['website.payment.ordernumber'] . ' ' . $order_id . ' [' . $GLOBALS['site_name'] . ']';
			    $mail_body = "
		<!DOCTYPE html>
		<html>
		<head>
		<meta charset='utf-8'>
		</head>
		<body style='font-family: arial;margin: 0px;padding: 0px;'>
		    <h2>" . $user_language['website.payment.email.title'] . "</h2>
		    <br/>
			<p>" . $user_language['website.payment.email.message'] . "</p>
			<br/>
			<h3>" . $user_language['website.checkout.text.banktransfer.h3'] . "</h3>
			<p>" . $user_language['website.checkout.text.banktransfer.orderreference'] . ": <b>#" . $order_id . "</b></p>
			" . $bank_transfer_info . "
			<br>
			<h3>" . $user_language['website.payment.text.orderdetails'] . "</h3>
			<table border='1' cellpadding='0' cellspacing='0' style='border-color: #DDD;'>
			    <thead>
                    <tr style='background: #F1F1F1;'>
					    <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>#</th>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>" . $user_language['website.cart.text.product'] . "</th>
						<td style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>&nbsp;</td>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>" . $user_language['website.cart.text.quantity'] . "</th>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: center;'>" . $user_language['website.cart.text.price'] . "</th>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: center;'>" . $user_language['website.cart.text.total'] . "</th>
                    </tr>
                </thead>
				<tbody>
				    " .  $cart_items . "
					<tr>
						<td colspan='5' style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;'><b>" . $user_language['website.cart.text.subtotal'] . "</b></td>
                        <td style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;'><b>" . pc_make_price_IPN($post_subtotal) . "</b></td>
					</tr>
					" . $tr_discount . "
					" . $tr_taxes . "
					" . $tr_shipping . "
					<tr>
						<td colspan='5' style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;'><b>" . $user_language['website.cart.text.total'] . "</b></td>
                        <td style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;'><b>" . pc_make_price_IPN($post_total) . "</b></td>
					</tr>
				</tbody>
			</table>
			<br>
			<h3>" . $user_language['website.payment.text.shippingaddress'] . "</h3>
			<p>" . $post_country . ", " . $post_state . " " . $post_city . ", " . $post_address . ", " . $post_zipCode . "</p>
			<br>
			" . $digital_table . "
						<br/>
						<br/>
			            </body>
			            </html>
	            ";
				$headers = "From: $from\r\n";
		        $headers .= "MIME-Version: 1.0\n";
	            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
	            $email_send = mail($to, $subject, $mail_body, $headers);
				
				// Safe Redirect
			header("location: " . $GLOBALS['url'] . "/" . pc_get_page_url($GLOBALS['website_payment']) . "/banktransfer/");
			exit();
		    }else if($what_is_this == 'cash'){
			    $to = $post_email;
		    	$from = $GLOBALS['auto_email'];
			    $subject = $user_language['website.payment.ordernumber'] . ' ' . $order_id . ' [' . $GLOBALS['site_name'] . ']';
			    $mail_body = "
		<!DOCTYPE html>
		<html>
		<head>
		<meta charset='utf-8'>
		</head>
		<body style='font-family: arial;margin: 0px;padding: 0px;'>
		    <h2>" . $user_language['website.payment.email.title'] . "</h2>
		    <br/>
			<p>" . $user_language['website.payment.email.message'] . "</p>
			<br/>
			<h3>" . $user_language['website.payment.text.orderdetails'] . "</h3>
			<table border='1' cellpadding='0' cellspacing='0' style='border-color: #DDD;'>
			    <thead>
                    <tr style='background: #F1F1F1;'>
					    <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>#</th>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>" . $user_language['website.cart.text.product'] . "</th>
						<td style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>&nbsp;</td>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: left;'>" . $user_language['website.cart.text.quantity'] . "</th>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: center;'>" . $user_language['website.cart.text.price'] . "</th>
                        <th style='vertical-align: bottom;padding: 8px;
line-height: 1.42857143;text-align: center;'>" . $user_language['website.cart.text.total'] . "</th>
                    </tr>
                </thead>
				<tbody>
				    " .  $cart_items . "
					<tr>
						<td colspan='5' style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;'><b>" . $user_language['website.cart.text.subtotal'] . "</b></td>
                        <td style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;'><b>" . pc_make_price_IPN($post_subtotal) . "</b></td>
					</tr>
					" . $tr_discount . "
					" . $tr_taxes . "
					" . $tr_shipping . "
					<tr>
						<td colspan='5' style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: right;'><b>" . $user_language['website.cart.text.total'] . "</b></td>
                        <td style='padding: 8px;line-height: 1.42857143;vertical-align: top;text-align: center;'><b>" . pc_make_price_IPN($post_total) . "</b></td>
					</tr>
				</tbody>
			</table>
			<br>
			<h3>" . $user_language['website.payment.text.shippingaddress'] . "</h3>
			<p>" . $post_country . ", " . $post_state . " " . $post_city . ", " . $post_address . ", " . $post_zipCode . "</p>
			<br>
			" . $digital_table . "
						<br/>
						<br/>
			            </body>
			            </html>
	            ";
				$headers = "From: $from\r\n";
		        $headers .= "MIME-Version: 1.0\n";
	            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
	            $email_send = mail($to, $subject, $mail_body, $headers);
				// Safe Redirect
			header("location: " . $GLOBALS['url'] . "/" . pc_get_page_url($GLOBALS['website_payment']) . "/cash/");
			exit();
			}
			
			
		}
	}
}
}


?>
<?php include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/checkout.php"); ?>