<?php


if(_VALID != 'Yes'){
	define("_VALID","Yes");
}

include_once("include/config/config.php");
include_once("include/traffic/traffic.php");


// Get Theme Functions
include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/php/functions.php");


$title = $user_language['website.404.title'];
$keywords = '';
$description = '';
$css = '';
$top_script = '';
$bottom_script = '';
$page_cotent_class = '';
$page_sidebar_class = '';
$content = '<p>' . $user_language['website.404.text.pagenotfound'] . '</p>';

?>
<?php include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/404.php"); ?>
