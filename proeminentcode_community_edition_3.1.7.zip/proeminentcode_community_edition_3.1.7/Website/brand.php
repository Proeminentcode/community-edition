<?php


// Start things
define("_VALID","Yes");


include_once("include/config/config.php");
include_once("include/traffic/traffic.php");


// Get Theme Functions
include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/php/functions.php");


// If shop is disabled
if($GLOBALS['shop_status'] == 0){
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}


$brand_ID = '';
if(isset($_GET['id'])){
	$url_name = $_GET['id'];
    $url_name = preg_replace('#[^A-Za-z0-9-]#i', '', $url_name);
    $sql_brandName = "SELECT brand_ID FROM pc_products_brands WHERE brand_url='$url_name' AND brand_status='p' LIMIT 1";
    $query_brandName = $mysqli->query($sql_brandName);
    if($query_brandName == FALSE){
	    include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
        exit();
    }else{
	    $count_brandName = $query_brandName->num_rows;
        if($count_brandName < 1){
	        include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
            exit();
        }
    }
    $new_row = $query_brandName->fetch_assoc();
    $brand_ID = $new_row['brand_ID'];	
}else{
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}


$title = '';
$keywords = '';
$css = '';
$top_script = '';
$bottom_script = '';
$description = '';
$page_cotent_class = '';
$page_sidebar_class = '';
$content = '';



// VARIABLES
// Basic Info
$brand_name = '';
$brand_content = '';
$brand_banner = '';
$brand_sidebar = '';
$brand_sidebar_ID = '';
$brand_products = '';
// Get Brand
$sql_brand = "SELECT * FROM pc_products_brands WHERE brand_ID='$brand_ID' AND brand_status='p' LIMIT 1";
$query_brand = $mysqli->query($sql_brand);
if($query_brand === FALSE){
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}else{
	$count_brand = $query_brand->num_rows;
	if($count_brand > 0){
		$row_brand = $query_brand->fetch_assoc();
		
		// Basic Info
		$title = $row_brand['brand_name'];
		$brand_content = html_entity_decode($row_brand['brand_content'], ENT_QUOTES);
		// Decrypt Site Url
		$brand_content = pc_dynamic_site_url_decrypt($brand_content);
		if($brand_content != '' && $brand_content != ' ' && $brand_content != '<p><br/></p>' && $brand_content != '&nbsp;'){
			$brand_content = $brand_content . '<br><br>';
		}
		
		
				
		// Sidebar
        $brand_sidebar = $row_brand['brand_sidebar'];
		if($brand_sidebar == 'left'){
			$page_cotent_class = 'col-md-8 col-md-push-4';
            $page_sidebar_class = 'col-md-4 col-md-pull-8';
		}else if($brand_sidebar == 'right'){
			$page_cotent_class = 'col-md-8';
            $page_sidebar_class = 'col-md-4';
		}else{
			$page_cotent_class = 'col-md-12';
            $page_sidebar_class = 'dont-display';
		}
        $page_sidebar_ID = $row_brand['brand_sidebar_ID'];
		
		
		// Products
		$sql_getProducts = "SELECT * FROM pc_products WHERE product_brand='$brand_ID' AND product_status='p' ORDER BY product_date";
		$query_getProducts = $mysqli->query($sql_getProducts);
		if($query_getProducts === FALSE){
			$brand_products = '<div class="alert alert-warning" role="alert">' . $user_language['website.search.alert.noproducts'] . '</div>';
		}else{
			$count_getProducts = $query_getProducts->num_rows;
			if($count_getProducts > 0){
				$brand_products .= '
		    <h3>' . number_function($count_getProducts, "number") .  ' ' . $user_language['website.search.text.products'] . '</h3>
		    <hr>
		    <div class="row">
	    ';
	    while($row_results = $query_getProducts->fetch_assoc()){
			$product_ID = $row_results['product_ID'];
				$stock_av = '';
				$product_rating = '';
				if($GLOBALS['shop_ratings_reviews'] == 1){
					$product_rating = '<p style="text-align: center;">' . pc_get_product_rating($product_ID) . '</p>';	
				}
			    $product_name = $row_results['product_name'];
				$product_stock = $row_results['product_stock'];
								if($GLOBALS['shop_stock_hide'] == 1){
									if($product_stock != '' && $product_stock != ' '){
										if($GLOBALS['shop_stock_out'] < $product_stock){
										    $stock_av = '<p style="text-align: center;color: #5cb85c;">' . pc_get_language_word("website.product.text.yesstock") . '</p>';
									    }else{
										    $stock_av = '<p style="text-align: center;color: #d9534f;">' . pc_get_language_word("website.product.text.nostock") . '</p>';
									    }
									}else{
										$stock_av = '<p style="text-align: center;color: #5cb85c;">' . pc_get_language_word("website.product.text.yesstock") . '</p>';
									}
								}
			    $product_url = $row_results["product_url"];
		        $product_price = '<p style="text-align: center;" class="pc-product-price">' . pc_make_price($row_results['product_price']) . '</p>';
		        $product_sale = $row_results['product_sale'];
				if($product_sale != '' && $product_sale != ' ' && $product_sale != 0){
					$product_sale = '<p style="text-align: center;" class="pc-product-price"><i style="color: #d9534f;text-decoration: line-through;">' . pc_make_price($product_sale) . '</i></p>';
				}else{
					$product_sale = '';
				}
				$product_tumbnail = $row_results['product_tumbnail'];
			    if($product_tumbnail != '' && $product_tumbnail != ' '){
								    $product_tumbnail = '
									    <div class="pc-product-thumbnail">
										    <a href="' . $GLOBALS['url'] . '/product/' . $product_url . '">
											    <div class="pc-product-thumbnail-inside" style="background: url(' . $GLOBALS['url'] . '/' . $product_tumbnail . ');background-size: cover;background-position: center;"></div>
											</a>
										</div>
									';
							    }else{
									$product_tumbnail = '
									    <div class="pc-product-thumbnail">
										    <div class="pc-product-thumbnail-inside"></div>
										</div>
									';
								}

		            $brand_products .= '
				        <div class="col-sm-12 col-sm-4 col-md-3">
				            <div class="pc-product-box">
				                ' . $product_tumbnail . '
				                <div style="height: 70px;"><h5 style="text-align: center;"><a href="' . $GLOBALS['url'] . '/product/' . $product_url . '" class="pc-product-name">' . $product_name . '</a></h5></div>
								' . $product_rating . '
								' . $stock_av . '
							    <div style="height: 20px;overflow: hidden;">' . $product_sale . '</div>
						        ' . $product_price . '
					            <div style="text-align: center;">
						            <a href="' . $GLOBALS['url'] . '/product/' . $product_url . '" class="btn btn-info pc-product-button" style="margin-bottom:10px;">' . pc_get_language_word("website.form.button.viewproduct") . '</a>
						        </div>
					        </div>
					    </div>
				    ';
	    }
	    $brand_products .= '
	        </div>   
	    ';
			}else{
				$brand_products = '<div class="alert alert-warning" role="alert">' . $user_language['website.search.alert.noproducts'] . '</div>';
			}
		}
		
		
		
		$content = $brand_content . $brand_products;
		
		// Banner
		$brand_banner = $row_brand['brand_banner'];
		if($brand_banner != '' && $brand_banner != ' '){
			$brand_banner = '<div class="banner-brand-box"><img src="' . $GLOBALS['url'] . '/' . $brand_banner . '" width="100%"></div>';
		}else{
			$brand_banner = '';
		}
	}else{
		include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
        exit();
	}
}


?>
<?php include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/brand.php"); ?>
