<?php


// Start things
define("_VALID","Yes");


include_once("include/config/config.php");
include_once("include/traffic/traffic.php");


// Get Theme Functions
include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/php/functions.php");


// If shop is disabled
if($GLOBALS['shop_status'] == 0){
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}


$category_ID = '';
if(isset($_GET['id'])){
	$url_name = $_GET['id'];
    $url_name = preg_replace('#[^A-Za-z0-9-]#i', '', $url_name);
    $sql_categoryName = "SELECT category_ID FROM pc_products_categories WHERE category_url='$url_name' AND category_status='p' LIMIT 1";
    $query_categoryName = $mysqli->query($sql_categoryName);
    if($query_categoryName == FALSE){
	    include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
        exit();
    }else{
	    $count_categoryName = $query_categoryName->num_rows;
        if($count_categoryName < 1){
	        include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
            exit();
        }
    }
    $new_row = $query_categoryName->fetch_assoc();
    $category_ID = $new_row['category_ID'];	
}else{
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}


$title = '';
$keywords = '';
$css = '';
$top_script = '';
$bottom_script = '';
$description = '';
$page_cotent_class = '';
$page_sidebar_class = '';
$content = '';



// VARIABLES
// Basic Info
$category_name = '';
$category_content = '';
$category_banner = '';
$category_sidebar = '';
$category_sidebar_ID = '';
$category_products = '';
// Get Brand
$sql_category = "SELECT * FROM pc_products_categories WHERE category_ID='$category_ID' AND category_status='p' LIMIT 1";
$query_category = $mysqli->query($sql_category);
if($query_category === FALSE){
	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
    exit();
}else{
	$count_category = $query_category->num_rows;
	if($count_category > 0){
		$row_category = $query_category->fetch_assoc();
		
		// Basic Info
		$title = $row_category['category_name'];
		$category_content = html_entity_decode($row_category['category_content'], ENT_QUOTES);
		// Decrypt Site Url
		$category_content = pc_dynamic_site_url_decrypt($category_content);
		if($category_content != '' && $category_content != ' ' && $category_content != '<p><br/></p>' && $category_content != '&nbsp;'){
			$category_content = $category_content . '<br><br>';
		}
		
		
				
		// Sidebar
        $brand_sidebar = $row_category['category_sidebar'];
		if($brand_sidebar == 'left'){
			$page_cotent_class = 'col-md-8 col-md-push-4';
            $page_sidebar_class = 'col-md-4 col-md-pull-8';
		}else if($brand_sidebar == 'right'){
			$page_cotent_class = 'col-md-8';
            $page_sidebar_class = 'col-md-4';
		}else{
			$page_cotent_class = 'col-md-12';
            $page_sidebar_class = 'dont-display';
		}
        $page_sidebar_ID = $row_category['category_sidebar_ID'];
		
		
		// Products
		$category_products_head = '';
		$category_products_list = '';
		$sql_getProducts = "SELECT * FROM pc_products WHERE product_status='p' ORDER BY product_date";
		$query_getProducts = $mysqli->query($sql_getProducts);
		if($query_getProducts === FALSE){
			$category_products = '<div class="alert alert-warning" role="alert">' . $user_language['website.search.alert.noproducts'] . '</div>';
		}else{
			$count_getProducts = $query_getProducts->num_rows;
			if($count_getProducts > 0){
				$count_getProducts = 0;
				 $category_products_list .= '<div class="row">';
	    while($row_results = $query_getProducts->fetch_assoc()){
			$product_ID = $row_results['product_ID'];
			$product_category = $row_results['product_category'];
			$product_category_items = explode(",", $product_category);
			foreach($product_category_items as $i =>$key){
				if($category_ID == $key){
					$count_getProducts = $count_getProducts + 1;
					$stock_av = '';
				$product_rating = '';
				if($GLOBALS['shop_ratings_reviews'] == 1){
					$product_rating = '<p style="text-align: center;">' . pc_get_product_rating($product_ID) . '</p>';	
				}
			    $product_name = $row_results['product_name'];
				$product_stock = $row_results['product_stock'];
								if($GLOBALS['shop_stock_hide'] == 1){
									if($product_stock != '' && $product_stock != ' '){
										if($GLOBALS['shop_stock_out'] < $product_stock){
										    $stock_av = '<p style="text-align: center;color: #5cb85c;">' . pc_get_language_word("website.product.text.yesstock") . '</p>';
									    }else{
										    $stock_av = '<p style="text-align: center;color: #d9534f;">' . pc_get_language_word("website.product.text.nostock") . '</p>';
									    }
									}else{
										$stock_av = '<p style="text-align: center;color: #5cb85c;">' . pc_get_language_word("website.product.text.yesstock") . '</p>';
									}
								}
			    $product_url = $row_results["product_url"];
		        $product_price = '<p style="text-align: center;" class="pc-product-price">' . pc_make_price($row_results['product_price']) . '</p>';
		        $product_sale = $row_results['product_sale'];
				if($product_sale != '' && $product_sale != ' ' && $product_sale != 0){
					$product_sale = '<p style="text-align: center;" class="pc-product-price"><i style="color: #d9534f;text-decoration: line-through;">' . pc_make_price($product_sale) . '</i></p>';
				}else{
					$product_sale = '';
				}
				$product_tumbnail = $row_results['product_tumbnail'];
			    if($product_tumbnail != '' && $product_tumbnail != ' '){
								    $product_tumbnail = '
									    <div class="pc-product-thumbnail">
										    <a href="' . $GLOBALS['url'] . '/product/' . $product_url . '">
											    <div class="pc-product-thumbnail-inside" style="background: url(' . $GLOBALS['url'] . '/' . $product_tumbnail . ');background-size: cover;background-position: center;"></div>
											</a>
										</div>
									';
							    }else{
									$product_tumbnail = '
									    <div class="pc-product-thumbnail">
										    <div class="pc-product-thumbnail-inside"></div>
										</div>
									';
								}

		            $category_products_list .= '
				        <div class="col-sm-12 col-sm-4 col-md-3">
				            <div class="pc-product-box">
				                ' . $product_tumbnail . '
				                <div style="height: 70px;"><h5 style="text-align: center;"><a href="' . $GLOBALS['url'] . '/product/' . $product_url . '" class="pc-product-name">' . $product_name . '</a></h5></div>
								' . $product_rating . '
								' . $stock_av . '
							    <div style="height: 20px;overflow: hidden;">' . $product_sale . '</div>
						        ' . $product_price . '
					            <div style="text-align: center;">
						            <a href="' . $GLOBALS['url'] . '/product/' . $product_url . '" class="btn btn-info pc-product-button" style="margin-bottom:10px;">' . pc_get_language_word("website.form.button.viewproduct") . '</a>
						        </div>
					        </div>
					    </div>
				    ';
				}
			}
				
	    }
	    $category_products_list .= '
	        </div>   
	    ';
		$category_products_head .= '
		    <h3>' . number_function($count_getProducts, "number") .  ' ' . $user_language['website.search.text.products'] . '</h3>
		    <hr>
		    
	    ';
		    $category_products = $category_products_head . $category_products_list;
			}else{
				$category_products = '<div class="alert alert-warning" role="alert">' . $user_language['website.search.alert.noproducts'] . '</div>';
			}
		}
		
		
		
		$content = $category_content . $category_products;
		
		// Banner
		$category_banner = $row_category['category_banner'];
		if($category_banner != '' && $category_banner != ' '){
			$category_banner = '<div class="banner-brand-box"><img src="' . $GLOBALS['url'] . '/' . $category_banner . '" width="100%"></div>';
		}else{
			$category_banner = '';
		}
	}else{
	 	include_once($GLOBALS['FOLDER_PATH'] . "/404.php");
        exit();
	}
}


?>
<?php include_once("uploads/themes/" . $GLOBALS['theme'] . "/frontend/category.php"); ?>
