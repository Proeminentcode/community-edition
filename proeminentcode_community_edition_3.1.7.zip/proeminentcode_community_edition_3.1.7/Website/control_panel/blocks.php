<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");



$page_rows = 25;
if(isset($_GET['n'])){
	if($_GET['n'] == '50'){
		$page_rows = 50;
	}else if($_GET['n'] == '100'){
		$page_rows = 100;
	}else if($_GET['n'] == '250'){
		$page_rows = 250;
	}else{
		$page_rows = 25;
	}
}else{
	$page_rows = 25;
}


// Delete Rows
if(isset($_POST['checkbox'])){
	if($admin_power != 'viewer'){
        $cnt = array();
        $cnt = count($_POST['checkbox']);
		if($cnt < $page_rows){
			for($i=0;$i<$cnt;$i++){
                $del_id = $_POST['checkbox'][$i];
		        $del_id = $mysqli->real_escape_string($del_id);
                $sql_deleteRow = "DELETE FROM pc_pages_blocks WHERE block_ID='$del_id'";
                $query_deleteRow = $mysqli->query($sql_deleteRow);
            }
		}else{
			for($i=0;$i<$page_rows;$i++){
                $del_id = $_POST['checkbox'][$i];
		        $del_id = $mysqli->real_escape_string($del_id);
                $sql_deleteRow = "DELETE FROM pc_pages_blocks WHERE block_ID='$del_id'";
                $query_deleteRow = $mysqli->query($sql_deleteRow);
            }
		}
        
	    if($cnt > 0){
		    $message = '<div class="alert alert-success" role="alert">' . $cnt . ' '. $lang['admin.block.alert.action.delete.success'] . '</div>';
	    }else{
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.block.alert.action.delete.noblocks'] . '</div>';
	    }
	}else{
		$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
	}
}




$members_list = '';
$pagination_list = '';
$count_members = 0;
$paginationCtrls = '';
$post_username = '';
$count_countMembers = 0;
$pagenum = '';
$last = '';
if(isset($_POST['post_value']) != ''){
	$post_username = $_POST['post_value'];
	if(strlen($post_username) > 0){
		$post_username = $mysqli->real_escape_string($_POST['post_value']);
	    $sql_members = "SELECT * FROM pc_pages_blocks WHERE block_ID='$post_username' OR block_title='$post_username' ORDER BY block_date DESC";
		$sql_membersPagination = "SELECT COUNT(block_ID) FROM pc_pages_blocks WHERE block_ID='$post_username' OR block_title='$post_username' ORDER BY block_date DESC";
        $query_membersPagination = $mysqli->query($sql_membersPagination);
        $row_membersPagination = $query_membersPagination->fetch_row();
        $num_rows = $row_membersPagination[0];
	}else{		
		$sql_membersPagination = "SELECT COUNT(block_ID) FROM pc_pages_blocks";
        $query_membersPagination = $mysqli->query($sql_membersPagination);
        $row_membersPagination = $query_membersPagination->fetch_row();
        $num_rows = $row_membersPagination[0];
		$last = ceil($num_rows/$page_rows);
        if($last < 1){
            $last = 1;
        }
        $pagenum = 1;
        if(isset($_GET['pn'])){
	        $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
        }
        if($pagenum < 1){ 
            $pagenum = 1; 
        }else if($pagenum > $last){ 
            $pagenum = $last; 
        }
        $limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;
	    $sql_members = "SELECT * FROM pc_pages_blocks ORDER BY block_date DESC $limit";
	}
}else{
	$sql_membersPagination = "SELECT COUNT(block_ID) FROM pc_pages_blocks";
    $query_membersPagination = $mysqli->query($sql_membersPagination);
    $row_membersPagination = $query_membersPagination->fetch_row();
    $num_rows = $row_membersPagination[0];
	$last = ceil($num_rows/$page_rows);
    if($last < 1){
        $last = 1;
    }
    $pagenum = 1;
    if(isset($_GET['pn'])){
	    $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
    }
    if($pagenum < 1){ 
        $pagenum = 1; 
    }else if($pagenum > $last){ 
        $pagenum = $last; 
    }
    $limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;
    $sql_members = "SELECT * FROM pc_pages_blocks ORDER BY block_date DESC $limit";
}






$query_members = $mysqli->query($sql_members);
if($query_members === FALSE){
	$members_list = '<div class="alert alert-warning" role="alert">' . $lang['admin.blocks.alert.noblock'] . '</div>';
}else{
	// Count Everything
	$sql_countMembers = "SELECT * FROM pc_pages_blocks";
	$query_countMembers = $mysqli->query($sql_countMembers);
	$count_countMembers = $query_countMembers->num_rows;
	$count_members = $query_members->num_rows;
	if($count_members > 0){
		$pagination_list = "Page <b>$pagenum</b> of <b>$last</b>";
		$paginationCtrls .= '<nav><ul class="pagination pagination-sm" id="no-margins">';
        if($last != 1){
	        if($pagenum > 1){
                $previous = $pagenum - 1;
		        $paginationCtrls .= '
				    <li>
                        <a href="'.$_SERVER['PHP_SELF'].'?pn='.$previous.'&n=' . $page_rows . '" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
				';
		        for($i = $pagenum-4; $i < $pagenum; $i++){
			        if($i > 0){
		                $paginationCtrls .= '<li><a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'&n=' . $page_rows . '">'.$i.'</a></li>';
			        }
	            }
            }
	        $paginationCtrls .= '<li class="active"><a href="#">'.$pagenum.'</a></li>';
	        for($i = $pagenum+1; $i <= $last; $i++){
		        $paginationCtrls .= '<li><a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'&n=' . $page_rows . '">'.$i.'</a></li>';
		        if($i >= $pagenum+4){
			       break;
		        }
	        }
            if($pagenum != $last){
                $next = $pagenum + 1;
                $paginationCtrls .= '
				    <li>
                        <a href="'.$_SERVER['PHP_SELF'].'?pn='.$next.'&n=' . $page_rows . '" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
				';
            }
			$paginationCtrls .= '</ul></nav>';
        }
		$members_list .= '
		<form action="' . $GLOBALS['url'] . '/control_panel/blocks" method="post">
		<button type="submit" class="btn btn-default  btn-sm"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblocks'] . '</button>
		<br>
		<br>
	    <div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
					    <th><input type="checkbox" name="select-all" id="select-all" style="margin-bottom: -3px;"></th>
						<th>' . $lang['admin.table.th.id'] . '</th>
						<th>' . $lang['admin.table.th.blocktitle'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.type'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.status'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.date'] . '</th>												
					</tr>
				</thead>
				<tbody>
	    ';
	    while($row_members = $query_members->fetch_assoc()){
			$main_page_label = '';
			$block_ID = $row_members['block_ID'];
			$block_title = $row_members['block_title'];
			$block_status = $row_members['block_status'];
			$block_type = $row_members['block_type'];
			$block_type_name = '';
			if($block_type == 'textHTML'){
				$block_type_name = $lang['admin.blocks.text.texthtml'];
			}else if($block_type == 'posts'){
				$block_type_name = $lang['admin.blocks.text.posts'];
			}else if($block_type == 'products'){
				$block_type_name = $lang['admin.blocks.text.products'];
			}else if($block_type == 'categories'){
				$block_type_name = $lang['admin.blocks.text.categories'];
			}else if($block_type == 'brands'){
				$block_type_name = $lang['admin.blocks.text.brands'];
			}else if($block_type == 'contactForm'){
				$block_type_name = $lang['admin.blocks.text.contactform'];
			}
			$block_date = date_create($row_members['block_date']);
			$block_date = date_format($block_date, 'j M Y');
			$status_style = '';
			if($block_status == 1){
				$block_status = $lang['admin.form.select.option.enabled'];
				$status_style = 'label-success';
			}else{
				$block_status = $lang['admin.form.select.option.disabled'];
				$status_style = 'label-default';
			}
		    $members_list .= '
		        <tr>
				    <td><input type="checkbox" name="checkbox[]" value="' . $block_ID . '"></td>
			        <td>#' . $block_ID . '</td>				
					<td><a href="' . $GLOBALS['url'] .'/control_panel/blocks-editBlock?id=' . $block_ID . '&type=' . $block_type . '">' . $block_title . '</a></td>
					<td style="text-align: center;">' . $block_type_name . '</td>
					<td style="text-align: center;"><span class="label '. $status_style .'">' . $block_status . '</span></td>
					<td style="text-align: center;">' . $block_date . '</td>
				</tr>
		    ';
	    }
	    $members_list .= '
	                </tbody>
			    </table>
		    </div>
			</form>
	    ';
	}else{
		$members_list = '<div class="alert alert-warning" role="alert">' . $lang['admin.blocks.alert.noblock'] . '</div>';
	}
}



if(isset($_GET['status']) != ''){
	$back_stauts = $_GET['status'];
	// New PAge Added
	if($back_stauts == 'success'){
	    $message = '<div class="alert alert-success" role="alert">' . $lang['admin.newblock.alert.success'] . '</div>';
    }
	// Page Deleted
	if($back_stauts == 'deleted'){
	    $message = '<div class="alert alert-success" role="alert">' . $lang['alert.editblock.alert.remove.success'] . '</div>';
    }
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.blocks.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.blocks.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url'] ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li class="active"><i class="fa fa-cube"></i>&nbsp;&nbsp;<?php echo $lang['admin.blocks.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
						<div class="panel panel-default">
                            <div class="panel-heading heading-white">
							    <h3 class="panel-title"><i class="fa fa-cube"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.blocks.title']; ?></b></h3>
							 </div>
                             <div class="panel-body">
                                 <div class="btn-group">
                                     <button type="button" class="btn <?php echo $admin_theme_btn; ?> dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.newblock']; ?></button>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-newBlock?type=textHTML"><?php echo $lang['admin.blocks.text.texthtml']; ?></a></li>
                                        <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-newBlock?type=posts"><?php echo $lang['admin.blocks.text.posts']; ?></a></li>
                                        <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-newBlock?type=products"><?php echo $lang['admin.blocks.text.products']; ?></a></li>
                                        <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-newBlock?type=brands"><?php echo $lang['admin.blocks.text.brands']; ?></a></li>
                                        <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-newBlock?type=categories"><?php echo $lang['admin.blocks.text.categories']; ?></a></li>
                                        <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-newBlock?type=contactForm"><?php echo $lang['admin.blocks.text.contactform']; ?></a></li>
                                    </ul>
                                 </div>
							     <br/>
								 <br/>
                                 
										     <div class="row">
											     <div class="col-xs-6">
												     <h3 style="margin-top: 2px;margin-bottom: 0px;"><?php echo $num_rows; ?>&nbsp;<?php echo $lang['admin.blocks.title']; ?></h3>
											     </div>
                                 <div class="col-xs-6" style="text-align: right;">
										     <form class="form-inline" action="<?php echo $GLOBALS['url']; ?>/control_panel/blocks" method="post">
											     <div class="form-group">
                                                     <input type="text" class="form-control input-sm" placeholder="<?php echo $lang['admin.form.placeholder.search']; ?>" name="post_value" value="<?php echo $post_username; ?>">
                                                 </div>
												 <button type="submit" class="btn <?php echo $admin_theme_btn; ?> btn-sm"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.search']; ?></button>
											 </form>
											 </div>
											 </div>
											 <hr>
	
                                 <?php echo $members_list; ?>
                                 <br/>
                                 <?php
								     if($num_rows > 0){
										 echo '
                                             <div class="row">
                                                 <div class="col-xs-6">
                                                     <div style="width: 200px;">
                                                         <form class="form-inline" action="' . $GLOBALS['url'] . '/control_panel/blocks" method="get">
														     <div class="form-group">
                                                                 <select class="form-control input-sm" name="n">
                                                                 <option value="' . $page_rows . '">' . $page_rows . '</option>
                                                                 <option value="25">25</option>
                                                                 <option value="50">50</option>
                                                                 <option value="100">100</option>
                                                                 <option value="250">250</option>
                                                                 </select>
															 </div>
															 <button type="submit" class="btn ' . $admin_theme_btn . ' btn-sm">' . $lang['admin.form.button.show'] . '</button>
                                                         </form>
                                                     </div>
                                                 </div>
                                                 <div class="col-xs-6" style="text-align: right">
                                                     ';
												if($num_rows > $page_rows){
												    echo $paginationCtrls;
									            } 
												echo '
                                                 </div>
                                             </div>
								         ';
                                     }
                                 ?>
							 </div>
						</div>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>