<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


$comment_ID = '';
$comment_title = '';
$comment_member = '';
$comment_text = '';
$comment_status = '';
if(isset($_GET['id'])){
	$comment_ID = $_GET['id'];
	$comment_ID = preg_replace('#[^0-9]#i', '', $comment_ID);
	$sql_commentInfo = "SELECT * FROM pc_comments WHERE comment_ID='$comment_ID' LIMIT 1";
	$query_commentInfo = $mysqli->query($sql_commentInfo);
	if($query_commentInfo === FALSE){
		header("location:  " . $GLOBALS['url']. "/control_panel/comments");
	    exit();	
	}else{
		$count_commentInfo = $query_commentInfo->num_rows;
		if($count_commentInfo > 0){
			// START DELETE COMMENT			
			if(isset($_GET['action']) == 'delete'){
				if($admin_power != 'viewer'){
					$sql_productRemove = "DELETE FROM pc_comments WHERE comment_ID='$comment_ID' LIMIT 1";
					$query_productRemove = $mysqli->query($sql_productRemove);
					if($query_productRemove === FALSE){
						$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcomment.alert.commentdelete.crash'] . '</div>';
					}else{
						header("location:  " . $GLOBALS['url'] . "/control_panel/comments?status=deleted");
                        exit();
					}
				}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END DELETE COMMENT	
			// START COMMENT INO
			$row_commentInfo = $query_commentInfo->fetch_assoc();
			$comment_ID = $row_commentInfo['comment_ID'];
            $comment_title = $row_commentInfo['comment_post_ID'];
			$comment_title_name = pc_get_post_title($comment_title);
			$comment_title = '<option value="' . $comment_title . '">' . $comment_title_name . '</option>';
            $comment_member = $row_commentInfo['comment_user_ID'];
			$comment_member_name = pc_get_member_username($comment_member);
			$comment_member = '<option value="' . $comment_member . '">' . $comment_member_name . '</option>';
            $comment_text = $row_commentInfo['comment_content'];
			$comment_user_IP = $row_commentInfo['comment_user_IP'];
			if($comment_user_IP != '' && $comment_user_IP != ' '){
				$comment_user_IP = '
				    <div class="form-group">
                        <label>' . $lang['admin.table.th.ipaddress'] . '</label>
                        <br>
						' . $comment_user_IP. '
				    </div>
				';
			}else{
				$comment_user_IP = '';
			}
			$comment_reply_ID = $row_commentInfo['comment_reply_ID'];
			if($comment_reply_ID != '' && $comment_reply_ID != ' ' && $comment_reply_ID != 0){
				$comment_reply_ID = '
				    <div class="form-group">
                        <label>' . $lang['admin.form.label.replyto'] . '</label>
                        <br>
						' . $lang['admin.form.label.comment'] . ' <a href="' . $GLOBALS['url'] . '/control_panel/comments-editComment?id=' . $comment_reply_ID . '">#' . $comment_reply_ID . '</a>
                    </div>
				';
			}else{
				$comment_reply_ID = '';
			}
            $comment_status = $row_commentInfo['comment_approved'];
			if($comment_status == 'a'){
				$comment_status = '<option value="' . $comment_status . '">' . $lang['admin.form.select.option.approved'] . '</option>';
			}else if($comment_status == 'p'){
				$comment_status = '<option value="' . $comment_status . '">' . $lang['admin.form.select.option.pending'] . '</option>';
			}else{
				$comment_status = '<option value="' . $comment_status . '">' . $lang['admin.form.select.option.deleted'] . '</option>';
			}
			$comment_update = $row_commentInfo['comment_update'];
			if($comment_update != '' && $comment_update != ' '){
				$comment_update = date_function($comment_update, 'datetime');	
				$comment_update = '
				    <div class="form-group">
                                <label>' . $lang['admin.table.th.update'] . '</label>
                                <br>
								' . $comment_update . '
                    </div>
				';							
			}
			$comment_date = date_function($row_commentInfo['comment_date'], 'datetime');
			// END COMMENT INFO
			// START UPDATE COMMENT
			$post_title_POST = '';
$member_name_POST = '';
$comment_POST = '';
$status_POST = '';
if(isset($_POST['post_title'])){
	if($admin_power != 'viewer'){
	$post_title_POST = $_POST['post_title'];
    $member_name_POST = $_POST['member_name'];
    $comment_POST = $_POST['comment'];
	$status_POST = $_POST['status'];
	$x = 0;
	
	// Post Title | Count 1
	if($post_title_POST != '' && $post_title_POST != ' ' && $post_title_POST != 0){
		$check_post = pc_check_post($post_title_POST);
		if($check_post == true){
			// Good
			$post_title_POST = $mysqli->real_escape_string($post_title_POST);
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.postitle.wrong'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.postitle.empty'] . '</div>';
	}
	
	
	// Member Name | Count 2
	if($x == 1){
		if($member_name_POST != '' && $member_name_POST != ' ' && $member_name_POST != 0){
			$check_member = pc_check_member($member_name_POST);
			if($check_member == true){
				// Good
				$member_name_POST = $mysqli->real_escape_string($member_name_POST);
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.member.wrong'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.member.empty'] . '</div>';
		}
	}
	
	
	// Comment | Count 3
	if($x == 2){
		if($comment_POST != '' || $comment_POST != ' '){
			if(strlen($comment_POST) < 10001){
				// ok
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.comment.len'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.comment.empty'] . '</div>';
		}
	}
	
	
	// Status | Count 4
	if($status_POST == 'p' || $status_POST == 'd' || $status_POST == 'a'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcomment.alert.status.wrong'] . '</div>';
	}
	
	
	// Add Comment
	if($x == 4){
		// IP
		$comment_IP = getenv('REMOTE_ADDR');
		if(filter_var($comment_IP, FILTER_VALIDATE_IP)) {
			$comment_IP = $mysqli->real_escape_string($comment_IP);
		}else{
			$comment_IP = '127.0.0.1';
		}
		// Safe Comment
		$comment_POST = htmlentities($comment_POST, ENT_QUOTES);
		$comment_POST = $mysqli->real_escape_string($comment_POST);
		$sql_addComment = "UPDATE pc_comments SET comment_post_ID='$post_title_POST', comment_user_ID='$member_name_POST', comment_approved='$status_POST', comment_update=now(), comment_content='$comment_POST' WHERE comment_ID='$comment_ID' LIMIT 1";
		$query_addComment = $mysqli->query($sql_addComment);
		if($query_addComment === FALSE){
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editcomment.alert.crash'] . '</div>';
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/comments-editComment?id=" . $comment_ID . "&update=success");
			exit();
		}
	}else{
		$comment_POST = htmlentities($comment_POST, ENT_QUOTES);
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}
			// END UPDATE COMMENT
		}else{
			header("location:  " . $GLOBALS['url']. "/control_panel/comments");
	        exit();	
		}
	}
}else{
	header("location:  " . $GLOBALS['url']. "/control_panel/comments");
	exit();
}





// GET POSTS
$posts_list = '';
$sql_getProducts = "SELECT post_ID, post_title FROM pc_posts ORDER BY post_title";
$query_getProducts = $mysqli->query($sql_getProducts);
if($query_getProducts === FALSE){
	$posts_list = '';
}else{
	$count_getProducts = $query_getProducts->num_rows;
	if($count_getProducts > 0){
		while($row_getProducts = $query_getProducts->fetch_assoc()){
			$post_id = $row_getProducts['post_ID'];
			$post_title = $row_getProducts['post_title'];
			$posts_list .= '<option value="' . $post_id  . '">' . $post_title . '</option>';
		}
	}
}


// GET MEMBERS
$members_list = '';
$sql_getMembers = "SELECT member_ID, member_user FROM pc_members ORDER BY member_firstname ASC";
$query_getMembers = $mysqli->query($sql_getMembers);
if($query_getMembers === FALSE){
	$members_list = '';
}else{
	$count_getMembers = $query_getMembers->num_rows;
	if($count_getMembers > 0){
		while($row_getMembers = $query_getMembers->fetch_assoc()){
			$member_ID = $row_getMembers['member_ID'];
			$member_user = $row_getMembers['member_user']; 
			$members_list .= '<option value="' . $member_ID  . '">' . $member_user . '</option>';
		}
	}
}



if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcomment.alert.update.success'] . '</div>';
	}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.editcomment.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<!-- START DELETE COMMENT MODAL -->
<div class="modal fade" id="deleteComment" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.button.deletecomment']; ?></h4>
            </div>
            <div class="modal-body">
                <p><?php echo $lang['alert.editcomment.text.remove.confirm']; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <a href="<?php echo $GLOBALS['url']; ?>/control_panel/comments-editComment?id=<?php echo $comment_ID; ?>&action=delete"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletecomment']; ?></button></a>
            </div>
        </div>
    </div>
</div>
<!-- END DELETE COMMENT MODAL -->
<div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.newcomment.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/comments"><i class="fa fa-comments"></i>&nbsp;&nbsp;<?php echo $lang['admin.comments.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $lang['admin.editcomment.title']; ?> #<?php echo $comment_ID; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/comments-editComment?id=<?php echo $comment_ID; ?>" method="post">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		    <div class="panel panel-default">
            <div class="panel-heading heading-white">
			    <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newcomment.title']; ?></b></h3>
			</div>
            <div class="panel-body">
			    
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.posttitle']; ?></label>
						<select class="form-control" name="post_title">
                            <?php echo $comment_title; ?>
                            <?php echo $posts_list; ?>
                        </select>
                        <br>
                    </div>
                    <div class="form-group">
					    <label><?php echo $lang['admin.form.label.member']; ?></label>
						<select class="form-control" name="member_name">  
                            <?php echo $comment_member; ?>
                            <?php echo $members_list; ?>
                        </select>
                        <br>
                    </div>
                    <div class="form-group">
					    <label><?php echo $lang['admin.form.label.comment']; ?></label>
                        <br>
                        <textarea name="comment" class="form-control" rows="5" style="resize: vertical;"><?php echo $comment_text; ?></textarea>
                        <br>
                    </div>
                    <div class="form-group">
					    <label><?php echo $lang['admin.form.label.status']; ?></label>
                        <select class="form-control" name="status">
                            <?php echo $comment_status; ?>
                            <option value="a"><?php echo $lang['admin.form.select.option.approved']; ?></option>
                            <option value="p"><?php echo $lang['admin.form.select.option.pending']; ?></option>
                            <option value="d"><?php echo $lang['admin.form.select.option.deleted']; ?></option>
                        </select>
                    </div>
			</div>
		</div>
        </div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.editcomment.text.commentinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <?php echo $comment_reply_ID; ?>
                        <?php echo $comment_user_IP; ?>
                        <?php echo $comment_update; ?>
                        <div class="form-group">
                            <label><?php echo $lang['admin.table.th.date']; ?></label>
                            <br>
                            <?php echo $comment_date; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <button type="submit" class="btn <?php echo $admin_theme_btn; ?>" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
            <a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteComment"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletecomment']; ?></a>
            <br>
            <br>
        </form>
		<?php include_once("tmp/footer.php"); ?>
	</div>    
</div>					
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>