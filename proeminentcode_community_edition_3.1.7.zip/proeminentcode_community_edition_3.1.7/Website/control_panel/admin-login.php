<?php


// DEFINE VALID
define("_VALID","Yes");


// VARIABLES
$message = '';
$post_username = '';
$post_password = '';
$checkbox = '';


// CONFIG
include_once("../include/config/config.php");
include_once("../include/traffic/traffic.php");


// CHECK ADMIN STATUS
if($admin_status == true){
    header("location: " . $GLOBALS['url'] . "/control_panel/home");
	exit();	
}

include_once("../include/languages/en_US.lang.php");



// LOG IN SCRIPT
if(isset($_POST['username'])){
	// Check if empty inputs
	if($_POST['username'] != "" && $_POST['password'] != ""){
		// Username
		$post_username = $_POST['username'];
		$post_username = preg_replace('#[^A-Za-z0-9]#i', '', $post_username);
	    $post_username = $mysqli->real_escape_string($post_username);
		// Password
		$post_password = $_POST['password'];
	    $post_password = md5($post_password);
		// Remember me
		if(isset($_POST['rememberme']) != ''){
		    $checkbox = $_POST['rememberme'];	
		}
		// Start log in check
		$sql_login = "SELECT admin_ID, admin_email, admin_username, admin_password FROM pc_admin WHERE admin_username='$post_username' AND admin_password='$post_password' AND admin_status='1' LIMIT 1";
	    $query_login = $mysqli->query($sql_login);
	    if($query_login === FALSE){
			// MySQL Error
			$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.login.wrong']  . '</div>';
			// Insert Error
			$error_title = 'Admins table error';
			$error_location = $config['BASE_DIR'] . '/' . $_SERVER['PHP_SELF'];
			$error_description = 'Could not get the admin data when trying to select the admin admin_ID, admin_email, admin_username, admin_password' . "\n" . 'Error: ' . $mysqli->connect_errno . ', ' . $mysqli->connect_error . "\n";
			$new_error = get_script_error($error_title, $error_location, $error_description);
			if($new_error){
				// Error added to database
			}else{
				// Failed to add error to database
				exit($lang['alert.adderror.crashed']);
			}
	    }else{		
		    // Count result    
			$count_login = $query_login->num_rows;
			if($count_login == 1){	
				// Admin exists
		        $row_login = $query_login->fetch_assoc();
				// Get admin data
				$admin_ID = $row_login['admin_ID'];
				$admin_email = $row_login['admin_email'];
				$admin_username = $row_login['admin_username'];
				$admin_password = $row_login['admin_password'];
				// Check login validation code setting
				$sql_adminValset = "SELECT setting_login_validation FROM pc_admin_settings WHERE admin_ID='$admin_ID' LIMIT 1";
				$query_adminValset = $mysqli->query($sql_adminValset);
				if($query_adminValset === FALSE){
					// The setting table is not here
					// Insert Error
			        $error_title = 'Admins settings table error';
			        $error_location = $config['BASE_DIR'] . '/' . $_SERVER['PHP_SELF'];
			        $error_description = 'Could not get the admin settings data when trying to select the admin setting_login_validation' . "\n" . 'Error: ' . $mysqli->connect_errno . ', ' . $mysqli->connect_error . "\n";
			        $new_error = get_script_error($error_title, $error_location, $error_description);
			        if($new_error){
				        // Error added to database
			        }else{
				       // Failed to add error to database
				       exit($lang['alert.adderror.crashed']);
			        } 
				}else{
					// The settings table exists
					// Check if has the log in validation
					$count_adminValset = $query_adminValset->num_rows;
					if($count_adminValset == 1){
						// The admin has settings
						$row_adminValset = $query_adminValset->fetch_assoc();
						// Get validation value
						$setting_login_validation = $row_adminValset['setting_login_validation'];
						if($setting_login_validation == 'Yes'){
							// The validation is set to yes
							setcookie("emailSecurityVF", $admin_email, strtotime('+2 days'), "/", "", false, true);
			                $security_code = rand(100000, 999999);
			                $sql_securityCode = "UPDATE pc_admin SET admin_security_code='$security_code' WHERE admin_username='$admin_username' AND admin_password='$admin_password' AND admin_status='1' LIMIT 1";
			                $query_securityCode = $mysqli->query($sql_securityCode);
			                if($query_securityCode === FALSE){		
								// Insert Error
			                    $error_title = 'Admin failed to update security code';
			                    $error_location = $config['BASE_DIR'] . '/' . $_SERVER['PHP_SELF'];
			                    $error_description .= 'Could not update the security code' . "\n";
			                    $error_description .= 'Error: ' . $mysqli->connect_errno . ', ' . $mysqli->connect_error . "\n";
			                    $new_error = get_script_error($error_title, $error_location, $error_description);
			                    if($new_error){
				                    // Error added to database
			                    }else{
				                    // Failed to add error to database
				                    exit($lang['alert.adderror.crashed']);
			                    }
				                $message = '<div class="alert alert-danger" role="alert">' . $lang['alert.login.wrong'] . '</div>';
			                }else{
								mail($admin_email, $lang['mail.admin.login.subject.1'] . " | " . $GLOBALS['site_name'], $lang['mail.admin.login.body'] . ": $security_code", "From: " . $GLOBALS['auto_email']);
				                header("location: " . $GLOBALS['url'] . "/control_panel/admin-code");
			                    exit();    
			                }						
						}else{
							// Start creating admin session
							// Update Last Log
							$ip_address = getenv('REMOTE_ADDR');
							$ip_address = preg_replace('#[^A-Za-z0-9.]#', '', $ip_address);
							$ip_address = $mysqli->real_escape_string($ip_address);
							$sql_updateLog = "UPDATE pc_admin SET admin_last_log=now(), admin_last_IP='$ip_address' WHERE admin_username='$admin_username' AND admin_password='$admin_password' AND admin_status='1' LIMIT 1";
							$mysqli->query($sql_updateLog);
							if($checkbox == "forever"){
								// Remember me
				                $_SESSION['idx'] = $admin_ID;
			                    $_SESSION['userx'] = $admin_username;
			                    $_SESSION['passx'] = $admin_password;
			                    setcookie("idy", $admin_ID, strtotime('+30 days'), "/", "", false, true);
			                    setcookie("usery", $admin_username, strtotime('+30 days'), "/", "", false, true);
			                    setcookie("passy", $admin_password, strtotime('+30 days'), "/", "", false, true);
				            }else{
								// Not remember me
					            $_SESSION['idx'] = $admin_ID;
			                    $_SESSION['userx'] = $admin_username;
			                    $_SESSION['passx'] = $admin_password;	
				            }
							// Admin goes home
							header("location: " . $GLOBALS['url'] . "/control_panel/home");
			                exit();	
						}
					}else{
						// The admin has no settings
						// Insert Error
			            $error_title = 'Admin has no settings table error';
			            $error_location = $config['BASE_DIR'] . '/' . $_SERVER['PHP_SELF'];
			            $error_description = 'Could not find the admin settings data when trying to select the admin setting_login_validation' . "\n" . 'Error: ' . $mysqli->connect_errno . ', ' . $mysqli->connect_error . "\n";
			            $new_error = get_script_error($error_title, $error_location, $error_description);
			            if($new_error){
				            // Error added to database
			            }else{
				            // Failed to add error to database
				            exit($lang['alert.adderror.crashed']);
			            } 
					}	
				}	
            }else{
				$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.login.wrong']  . '</div>';
			}
	    }
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.login.empty'] . '</div>';
	}
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $lang['admin.login.title']; ?></title>
<link href="<?php echo $GLOBALS['url'] ?>/assets/bootstrap/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/control_panel/css/dashboard.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/control_panel/css/login.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/assets/fontawesome/fontawesome-4.6.3/css/font-awesome.css" rel="stylesheet">
<script src="<?php echo $GLOBALS['url'] ?>/assets/js/jquery-3.1.0.min.js"></script>
<link rel="shortcut icon" href="<?php echo $GLOBALS['url'] ?>/control_panel/favicon.ico">
</head>
<body>
    <!-- Start Log In Container -->
    <div class="container" style="max-width: 400px;">
        <div class="log-header">
            <img src="<?php echo $GLOBALS['url'] ?>/assets/images/Proeminent_Code_140x140_blue.png" width="100" title="Proeminent Code" alt="Proeminent Code">
        </div>
        <?php echo $message; ?>
	    <div class="panel panel-default">
            <div class="panel-body">
		        <form action="<?php echo $GLOBALS['url'] ?>/control_panel/admin-login" method="post">
			        <h1><?php echo $lang['admin.login.title']; ?></h1>
                    <br>
                    <div class="form-group">
                        <label><?php echo $lang['admin.form.label.username']; ?></label>
                        <input type="text" name="username" class="form-control" id="username" autocomplete="off" maxlentgh="30">
                    </div>
                    <div class="form-group">
                        <label><?php echo $lang['admin.form.label.password']; ?></label>
                        <input type="password" name="password" class="form-control" id="password" maxlentgh="50">
                    </div>
                    <div class="row">
                        <div class="col-xs-7">
                            <div class="left-turtle">
                                <label for="rememberme" style="font-weight: normal;"><input name="rememberme" type="checkbox" id="rememberme" value="forever"> <?php echo $lang['admin.form.label.rememberme']; ?></label>
                            </div>
                        </div>
                        <div class="col-xs-5">
                            <div class="right-turtle">
                                <button type="submit" class="btn btn-info"><i class="fa fa-sign-in"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.login']; ?></button>
                            </div>
                        </div>
                    </div>
                </form>
	        </div>
        </div>
        <div class="bottom-login">
            <p><a href="<?php echo $GLOBALS['url'] ?>/control_panel/admin-lostPass"><?php echo $lang['admin.login.text.lostyourpass']; ?></a></p>
        </div>
	</div>
    <!-- End Log In Container -->
</body>
</html>