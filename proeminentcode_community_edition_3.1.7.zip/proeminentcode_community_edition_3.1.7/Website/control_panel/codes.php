<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


$websiteSetting_script_topValue = '';
$websiteSetting_script_topValue = html_entity_decode($GLOBALS['websiteSetting_script_top'], ENT_NOQUOTES); 
$websiteSetting_script_bottomValue = html_entity_decode($GLOBALS['websiteSetting_script_bottom'], ENT_NOQUOTES);


// Update Scripts
if(isset($_POST['header_code'])){
	if($admin_power == 'admin' || $admin_power == 'editor'){
    $header_code = $_POST['header_code'];		
	$footer_code = $_POST['footer_code'];	
	if(strlen($header_code) > 10000){
		$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.settings.scripts.code.toolong'] . '</div>';
	}else{
		if(strlen($footer_code) > 10000){
			$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.settings.scripts.code.toolong2'] . '</div>';
		}else{
			$header_code = htmlspecialchars($header_code, ENT_QUOTES);
			$header_code = $mysqli->real_escape_string($header_code);
			
			$footer_code = htmlspecialchars($footer_code, ENT_QUOTES);
			$footer_code = $mysqli->real_escape_string($footer_code);
			
			$sql_updateCode_header = "UPDATE pc_options SET option_value='$header_code' WHERE option_name='websiteSetting_script_top' LIMIT 1";
			$query_updateCode_header = $mysqli->query($sql_updateCode_header);
			
			$sql_updateCode_footer = "UPDATE pc_options SET option_value='$footer_code' WHERE option_name='websiteSetting_script_bottom' LIMIT 1";
			$query_updateCode_footer = $mysqli->query($sql_updateCode_footer);
			
			if($query_updateCode_header === FALSE || $query_updateCode_footer === FALSE){
				$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.settings.scripts.crash'] . '</div>';
			}else{
				header("location: " . $GLOBALS['url'] . "/control_panel/codes?updates=success");
			    exit();
			}
		}
	}
	}else{
		$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
	}
}



// Updates OK
if(isset($_GET['updates']) == 'success'){
	$message = '<div class="alert alert-success" role="alert">' . $lang['alert.settings.scripts.success'] . '</div>';
}





?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.scripts.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
        <?php include_once("tmp/header.php"); ?>
        <?php include_once("tmp/aside.php"); ?>
	    <div id="page-content-wrapper">
            <?php echo $message; ?>
	        <h1><?php echo $lang['admin.settings.title']; ?></h1>
		    <ol class="breadcrumb">
                 <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
                 <li class="active"><i class="fa fa-wrench"></i>&nbsp;&nbsp;<?php echo $lang['admin.settings.title']; ?></a></li>
                 <li class="active"><i class="fa fa-cogs"></i>&nbsp;&nbsp;<?php echo $lang['admin.scripts.title']; ?></li>
            </ol>
            <?php include_once("tmp/tmp-quickActions.php"); ?>
            <form action="<?php echo $GLOBALS['url']; ?>/control_panel/codes" method="post" enctype="multipart/form-data">
            <!-- Code Updates -->
                    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
						    <h3 class="panel-title"><i class="fa fa-cogs"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.scripts.title']; ?></b></h3>
						</div>
                        <div class="panel-body">
                            
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.headercode']; ?></label>
                                    <textarea name="header_code" class="form-control" rows="8" style="resize: none;"><?php echo $websiteSetting_script_topValue; ?></textarea>
                                    <br>
                                </div>
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.footercode']; ?></label>
                                    <textarea name="footer_code" class="form-control" rows="8" style="resize: none;"><?php echo $websiteSetting_script_bottomValue; ?></textarea>
                                </div>
                                
                        </div>
                    </div>
                    <!-- Code Updates -->
                    <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
                <br>
                <br>
                            </form>
            <?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>
</div>					
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>