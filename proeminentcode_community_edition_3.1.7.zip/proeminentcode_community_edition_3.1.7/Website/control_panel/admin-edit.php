<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// Settings Updates
$post_admin_username = '';
$post_admin_email = '';
$post_admin_password = '';
$post_admin_phone = '';
$post_admin_language = '';
$post_admin_validation = '';
$post_admin_theme = '';
if(isset($_POST['admin_username'])){
	if($admin_power != 'viewer'){
		// Post Variables
		$post_admin_username = $_POST['admin_username'];
        $post_admin_email = $_POST['admin_email'];
        $post_admin_password = $_POST['admin_password'];
        $post_admin_phone = $_POST['admin_phone'];
		$post_admin_language = $_POST['admin_language'];
        $post_admin_validation = $_POST['admin_validation'];
        $post_admin_theme = $_POST['admin_theme'];
		
		// Count
		$x = 0;
		
		
		// Username | Count 1
	    if($post_admin_username != '' && $post_admin_username != ' '){
		if(strlen($post_admin_username) > 4 && strlen($post_admin_username) < 31){
			$post_admin_username_copy = preg_replace('#[^A-Za-z0-9]#i', '', $post_admin_username);
		    if($post_admin_username == $post_admin_username_copy){
			$post_admin_username = preg_replace('#[^A-Za-z0-9]#i', '', $post_admin_username);
			$post_admin_username = $mysqli->real_escape_string($post_admin_username);
			// Username Check
			$check_username = false;
			$sql_checkUsername = "SELECT admin_ID FROM pc_admin WHERE admin_username<>'$session_user' AND admin_username='$post_admin_username'";
			$query_checkUsername = $mysqli->query($sql_checkUsername);
			if($query_checkUsername === FALSE){
				$check_username = false;
			}else{
				$count_checkUsername = $query_checkUsername->num_rows;
				if($count_checkUsername > 0){
					$check_username = true;
				}else{
					$check_username = false;
				}
			}
			if($check_username == false){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.taken']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.char']  . '</div>';
		}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.len']  . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.empty']  . '</div>';
	}
	
	    
		// Email | Count 2
	    if($x == 1){
		if($post_admin_email != '' && $post_admin_email != ' '){
			if(strlen($post_admin_email) < 256){
				// Email Check
			$post_admin_email = filter_var($post_admin_email, FILTER_SANITIZE_EMAIL);  
            if(filter_var($post_admin_email, FILTER_VALIDATE_EMAIL)){
	            $post_admin_email = $mysqli->real_escape_string($post_admin_email);
				$check_email = false;
				$sql_checkEmail = "SELECT admin_ID FROM pc_admin WHERE admin_email<>'$admin_email' AND admin_email='$post_admin_email'";
				$query_checkEmail = $mysqli->query($sql_checkEmail);
				if($query_checkEmail === FALSE){
					$check_email = false;
				}else{
					$count_checkEmail = $query_checkEmail->num_rows;
					if($count_checkEmail > 0){
						$check_email = true;
					}else{
						$check_email = false;
					}
				}
				if($check_email == false){
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.taken']  . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.wrong']  . '</div>';
			}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.empty']  . '</div>';
		}
	}
	
	
	    // Phone | Count 3
    	if($x == 2){
		if($post_admin_phone != '' && $post_admin_phone != ' '){
			if(strlen($post_admin_phone) < 31){
				$post_admin_phone_copy = preg_replace('#[^0-9]#i', '', $post_admin_phone);
		        if($post_admin_phone == $post_admin_phone_copy){
			        $x = $x + 1;						
		        }else{
			        $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.phone.char']  . '</div>';								
		        }
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.phone.len']  . '</div>';
			}
		}else{
			$post_admin_phone = '';
			$x = $x + 1;
		}
	}
	
	
	    
		// Validation | Count 4
	    if($x == 3){
		if($post_admin_validation == 'Yes' || $post_admin_validation == 'No'){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.validation.wrong']  . '</div>';
		}
	}
	    
	    
		// Theme | Count 5
	    if($x == 4){
		$theme_boolean = false;
		$admin_theme_array = array(
	        'Light Blue' => 'light-blue',
			'Blue Sea' => 'blue-sea',
	        'Summer Yellow' => 'summer-yellow',
	        'Green Tea' => 'green-tea',
	        'Red Fire' => 'red-fire'
        );
		foreach($admin_theme_array as $k => $v){
            if(preg_match("/$v/", $post_admin_theme)){
				$post_admin_theme = $v;
				$theme_boolean = true;
                break;
            }
	    }
		if($theme_boolean == true){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.theme.wrong']  . '</div>';
		}
	}
	
	
	    // Confirm Password | Count 6
		if($x == 5){
	        if($post_admin_password != '' && $post_admin_password != ' '){
				$post_admin_password = md5($post_admin_password);
				if($post_admin_password == $session_pass){
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.adminedit.wrong.password']  . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editadministrators.alert.enterpassword']  . '</div>';
			}
		}
		
		
		// Language | Count 7
        if($x == 6){
			if($post_admin_language != '' && $post_admin_language != ' '){
				if($post_admin_language == 'en_US' || $post_admin_language == 'de_DE' || $post_admin_language == 'ro_RO'){
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.adminedit.wrong.language']  . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.adminedit.empty.language']  . '</div>';
			}
		}		
		
		// Final
		if($x == 7){
			$post_admin_email = $mysqli->real_escape_string($post_admin_email);
		
		// Update Admin
		$sql_updateAdmin = "UPDATE pc_admin SET admin_email='$post_admin_email', admin_username='$post_admin_username', admin_phone='$post_admin_phone' WHERE admin_ID='$session_id' LIMIT 1";
		$query_updateAdmin = $mysqli->query($sql_updateAdmin);
		
		// Update Settings
		$sql_updateSettings = "UPDATE pc_admin_settings SET setting_login_validation='$post_admin_validation', setting_theme='$post_admin_theme', setting_language='$post_admin_language', setting_update=now() WHERE admin_ID='$session_id' LIMIT 1";
		$query_updateSettings = $mysqli->query($sql_updateSettings);
		
		if($query_updateAdmin === FALSE || $query_updateSettings === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.updates.crashed']  . '</div>';
		}else{
		    header("location: " . $GLOBALS['url'] . "/control_panel/admin-edit?update=success");
			exit();
		    }
		}
	
	}else{
		$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower']  . '</div>';
	}
}


if($admin_theme == 'light-blue'){
	$admin_theme_name = '<option value="light-blue">' . $lang['admin.form.select.option.theme.lightblue'] . '</option>';
}else if($admin_theme == 'blue-sea'){
	$admin_theme_name = '<option value="blue-sea">' . $lang['admin.form.select.option.theme.bluesea'] . '</option>';
}else if($admin_theme == 'green-tea'){
	$admin_theme_name = '<option value="green-tea">' . $lang['admin.form.select.option.theme.greentea'] . '</option>';
}else if($admin_theme == 'summer-yellow'){
	$admin_theme_name = '<option value="summer-yellow">' . $lang['admin.form.select.option.theme.summeryellow'] . '</option>';
}else{
	$admin_theme_name = '<option value="red-fire">' . $lang['admin.form.select.option.theme.redfire'] . '</option>';
}


// Success ?
if(isset($_GET['update']) == 'success'){
    $message = '<div class="alert alert-success" role="alert">' . $lang['alert.updates.success']  . '</div>';
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.settings.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
        <?php include_once("tmp/header.php"); ?>
        <?php include_once("tmp/aside.php"); ?>
	    <div id="page-content-wrapper">
            <?php echo $message; ?>
			<h1><?php echo $lang['admin.settings.title']; ?></h1>
			<ol class="breadcrumb">
                <li><a href="<?php echo $GLOBALS['url'] ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
                <li class="active"><i class="fa fa-user"></i>&nbsp;&nbsp;<?php echo $lang['admin.myaccount.title']; ?></li>
                <li class="active"><i class="fa fa-cog"></i>&nbsp;&nbsp;<?php echo $lang['admin.settings.title']; ?></li>
            </ol>
            <?php include_once("tmp/tmp-quickActions.php"); ?>
            <div class="row">
            <form action="<?php echo $GLOBALS['url'] ?>/control_panel/admin-edit" method="post">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.username']; ?></label>
						    <input type="text" name="admin_username" class="form-control" autocomplete="off" maxlength="30" value="<?php echo $session_user; ?>"> 
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.email']; ?></label>
						    <input type="email" name="admin_email" class="form-control" autocomplete="off" maxlength="100" value="<?php echo $admin_email; ?>"> 
                            <br>
						</div>
                        <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.phone']; ?></label>
                                    <input type="tel" name="admin_phone" class="form-control" autocomplete="off" maxlength="30" value="<?php echo $admin_phone; ?>">
                                    <br>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.confirmpassword']; ?></label>
                            <input type="password" name="admin_password" class="form-control" autocomplete="off" maxlength="50">
                        </div>
			        </div>
                </div>
		    </div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-wrench"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newadministrator.text.adminsettings']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                            <input type="hidden" name="admin_language" value="en_US">
                        <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.securitycode']; ?></label>
                                    <select class="form-control"  name="admin_validation">
                                        <option value="<?php echo $admin_validation; ?>"><?php echo $admin_validation; ?></option>
                                        <option value="No"><?php echo $lang['admin.form.select.option.no']; ?></option>
										<option value="Yes"><?php echo $lang['admin.form.select.option.yes']; ?></option>	
									</select>
                                    <br>
                        </div>
                        <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.theme']; ?></label>
                                    <select class="form-control" id="inputTheme" name="admin_theme">
                                        <?php echo $admin_theme_name; ?>
										<option value="light-blue"><?php echo $lang['admin.form.select.option.theme.lightblue']; ?></option>
										<option value="blue-sea"><?php echo $lang['admin.form.select.option.theme.bluesea']; ?></option>
										<option value="green-tea"><?php echo $lang['admin.form.select.option.theme.greentea']; ?></option>
										<option value="summer-yellow"><?php echo $lang['admin.form.select.option.theme.summeryellow']; ?></option>
										<option value="red-fire"><?php echo $lang['admin.form.select.option.theme.redfire']; ?></option>
									</select>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
            <br>
            <br>
            </form>
            <?php include_once("tmp/footer.php"); ?>
		</div>
    </div>				
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>