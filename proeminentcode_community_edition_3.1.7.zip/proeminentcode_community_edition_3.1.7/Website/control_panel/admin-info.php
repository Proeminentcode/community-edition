<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $config['BASE_URL']. "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// Admin 
$admin_date_log = '';
$admin_last_ip = '';
$admin_date_created = '';
$sql_getAdmin = "SELECT * FROM pc_admin WHERE admin_ID='$session_id' LIMIT 1";
$query_getAdmin = $mysqli->query($sql_getAdmin);
if($query_getAdmin === FALSE){
	header("location: " . $config['BASE_URL']. "/control_panel/admin-logout");
	exit();
}else{
	$count_getAdmin = $query_getAdmin->num_rows;
	if($count_getAdmin > 0){
		$row_getAdmin = $query_getAdmin->fetch_assoc();
		$admin_date_log = $row_getAdmin['admin_last_log'];
		$admin_date_created = $row_getAdmin['admin_date'];
		$admin_last_ip = $row_getAdmin['admin_last_IP'];
	}else{
		header("location: " . $config['BASE_URL']. "/control_panel/admin-logout");
	    exit();
	}
}


// Settings
$admin_setting_id = '';
$admin_setting_validation = '';
$admin_setting_lastUp = '';
$admin_setting_created = '';
$sql_getSettings = "SELECT * FROM pc_admin_settings WHERE admin_ID='$session_id' LIMIT 1";
$query_getSettings = $mysqli->query($sql_getSettings);
if($query_getSettings === FALSE){
	header("location: " . $config['BASE_URL']. "/control_panel/admin-logout");
	exit();
}else{
	$count_getSetttings = $query_getSettings->num_rows;
	if($count_getSetttings > 0){
		$row_getSettings = $query_getSettings->fetch_assoc();
		$admin_setting_id = $row_getSettings['setting_ID'];
        $admin_setting_validation = $row_getSettings['setting_login_validation'];
		if($admin_setting_validation == 'Yes'){
			$admin_setting_validation = $lang['admin.table.td.yes'];
		}else{
			$admin_setting_validation = $lang['admin.table.td.no'];
		}
        $admin_setting_lastUp = $row_getSettings['setting_update'];
        $admin_setting_created = $row_getSettings['setting_date'];
	}else{
		header("location: " . $config['BASE_URL']. "/control_panel/admin-logout");
	    exit();
	}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.accountinfo.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
        <?php include_once("tmp/header.php"); ?>
        <?php include_once("tmp/aside.php"); ?>
	    <div id="page-content-wrapper">
            <?php echo $message; ?>
			<h1><?php echo $lang['admin.settings.title']; ?></h1>
			<ol class="breadcrumb">
                <li><a href="<?php echo $GLOBALS['url'] ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
                <li class="active"><i class="fa fa-user"></i>&nbsp;&nbsp;<?php echo $lang['admin.myaccount.title']; ?></li>
                <li class="active"><i class="fa fa-binoculars"></i>&nbsp;&nbsp;<?php echo $lang['admin.accountinfo.title']; ?></li>
            </ol>
            <?php include_once("tmp/tmp-quickActions.php"); ?>
			<div class="panel panel-default">
                <div class="panel-heading heading-white">
				    <h3 class="panel-title"><i class="fa fa-binoculars"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.accountinfo.title']; ?></b></h3>
				</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h3><?php echo $lang['admin.accountinfo.text.account']; ?></h3>
                            <hr>
                            <p><b><?php echo $lang['admin.accountinfo.text.userid']; ?>:</b>  <?php echo $session_id; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.power']; ?>: </b> <?php echo $admin_power; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.username']; ?>: </b> <?php echo $session_user; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.email']; ?>: </b> <?php echo $admin_email; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.phone']; ?>: </b> <?php echo $admin_phone; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.accountsince']; ?>: </b> <?php echo $admin_date_created; ?></p>
				            <p><b><?php echo $lang['admin.accountinfo.text.lastlogin']; ?>: </b> <?php echo $admin_date_log; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.lastip']; ?>: </b> <?php echo $admin_last_ip; ?></p>
                            <br>
                        </div>
                        <div class="col-md-6">
                            <h3><?php echo $lang['admin.accountinfo.text.settings']; ?></h3>
                            <hr>
                            <p><b><?php echo $lang['admin.accountinfo.text.settingid']; ?>: </b> <?php echo $admin_setting_id; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.theme']; ?>: </b> <?php echo $admin_theme_name; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.language']; ?>: </b> <?php echo $admin_language_name; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.loginval']; ?>: </b> <?php echo $admin_setting_validation; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.lastup']; ?>: </b> <?php echo $admin_setting_lastUp; ?></p>
                            <p><b><?php echo $lang['admin.accountinfo.text.datecreated']; ?>: </b> <?php echo $admin_setting_created; ?></p>
                            <br>
                        </div>
                    </div>
				</div>
		    </div>
            <?php include_once("tmp/footer.php"); ?>
		</div>
    </div>				
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>