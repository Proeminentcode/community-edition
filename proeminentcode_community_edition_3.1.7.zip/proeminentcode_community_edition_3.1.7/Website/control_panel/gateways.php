<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url']. "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");



// PAYMENT GATEWAYS
$payment_gateways = '';
$count_getGatewats = 0;
$sql_getGateways = "SELECT * FROM  pc_gateways WHERE gateway_configured='1' ORDER BY gateway_name";
$query_getGatewats = $mysqli->query($sql_getGateways);
if($query_getGatewats === FALSE){
	$payment_gateways = '<div class="alert alert-warning" role="alert">' . $lang['admin.paymentgateways.alert.nogateways'] . '</div>';
}else{
	$count_getGatewats = $query_getGatewats->num_rows;
	if($count_getGatewats > 0){
		$payment_gateways .= '
		    <div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
					    <th>' . $lang['admin.table.th.id'] . '</th>
						<th>' . $lang['admin.table.th.gatewayname'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.total'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.status'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.date'] . '</th>
					</tr>
				</thead>
				<tbody>
		';
		while($row_getGatewats = $query_getGatewats->fetch_assoc()){
			$gateway_ID = $row_getGatewats["gateway_ID"];
			$gateway_type = $row_getGatewats["gateway_type"];
			$gateway_name = $row_getGatewats["gateway_name"];
			$gateway_description = $row_getGatewats['gateway_description'];
			$gateway_status = $row_getGatewats["gateway_status"];
			if($gateway_status == 1){
				$gateway_status = '<span class="label label-success">' . $lang['admin.table.td.enabled'] . '</span>';
			}else{
				$gateway_status = '<span class="label label-default">' . $lang['admin.table.td.disabled'] . '</span>';
			}
			$gateway_logo_link = '../assets/images/gateways/' . $gateway_type . '_gateway.png';
			if(file_exists($gateway_logo_link)){
			    $gateway_logo = '<div style="border: 1px solid #EEE;"><img src="' . $GLOBALS['url'] . '/assets/images/gateways/' . $gateway_type . '_gateway.png" width="100%"></div>';
			}else{
				$gateway_logo = '';
			}
			$gateway_date = $row_getGatewats["gateway_date"];
			$gateway_total = 0;
			$sql_gatewayEarnings = "SELECT * FROM pc_orders WHERE order_method='" . $mysqli->real_escape_string($gateway_name) . "'";
            $query_gatewayEarnings = $mysqli->query($sql_gatewayEarnings);
            if($query_gatewayEarnings === FALSE){
                $gateway_total = 0;
            }else{
	            $count_gatewayEarnings = $query_gatewayEarnings->num_rows;
                if($count_gatewayEarnings > 0){
	                while($row_gatewayEarnings = $query_gatewayEarnings->fetch_assoc()){
	                    $earnings = $row_gatewayEarnings['order_total'];
		                $earnings = preg_replace('#[^0-9.,]#i', '', $earnings);
		                $gateway_total = $gateway_total + $earnings;
	                }
                }else{
	                $gateway_total = 0;
                }
            }
			$gateway_total = pc_make_price($gateway_total);
			$payment_gateways .= '
			    <tr>
				    <td>' . $gateway_ID . '</td>
				    <td><a href="gateways-' . $gateway_type . '?id=' . $gateway_ID . '">' . $gateway_name . '</a></td>
					<td style="text-align: center;">' . $gateway_total . '</td>
			        <td style="text-align: center;">' . $gateway_status . '</td>
			        <td style="text-align: center;">' . date_function($gateway_date, "date") . '</td>
			    </tr>';
			/*$payment_gateways .= '
			    <div>
				    <div class="row">
					    <div class="col-sm-5 col-md-3">
						    ' . $gateway_logo . '
						</div>
						<div class="col-sm-7 col-md-9">
						    <h4>' . $gateway_name . '</h4>
							<p>' . $gateway_description . '</p>
							' . $gateway_status . '
						</div>
					</div>
				</div>
				<hr>
			';*/
		}
		$payment_gateways .= '
		            </tbody>
			    </table>
		    </div>
		';
	}else{
		$payment_gateways = '<div class="alert alert-warning" role="alert">' . $lang['admin.paymentgateways.alert.nogateways'] . '</div>';
	}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.paymentgateways.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.paymentgateways.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li class="active"><i class="fa fa-usd"></i>&nbsp;&nbsp;<?php echo $lang['admin.paymentgateways.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
		<div class="panel panel-default">
            <div class="panel-heading heading-white">
			    <h3 class="panel-title"><i class="fa fa-usd"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.paymentgateways.title']; ?></b></h3>
			</div>
            <div class="panel-body">
                <br>
			    <?php
				    if($count_getGatewats > 0){
						echo '<h3 style="margin-top: 2px;margin-bottom: 0px;">' . $count_getGatewats . ' ' . $lang['admin.paymentgateways.title'] . '</h3>';
					}else{
						echo '<h3 style="margin-top: 2px;margin-bottom: 0px;">' . $lang['admin.paymentgateways.title'] . '</h3>';
					}
				 ?>
                 <hr>
                 <?php echo $payment_gateways; ?>
			</div>
		</div>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>