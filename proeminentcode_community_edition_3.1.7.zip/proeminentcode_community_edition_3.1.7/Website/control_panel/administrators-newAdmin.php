<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// VARIABLES
$post_admin_username = '';
$post_admin_email = '';
$post_admin_password = '';
$post_admin_phone = '';
$post_admin_power = '';
$post_admin_language = '';
$post_admin_validation = '';
$post_admin_theme = '';
if(isset($_POST['admin_username'])){
	if($admin_power == 'admin'){
	$post_admin_username = $_POST['admin_username'];
    $post_admin_email = $_POST['admin_email'];
    $post_admin_password = $_POST['admin_password'];
    $post_admin_phone = $_POST['admin_phone'];
    $post_admin_power = $_POST['admin_power'];
	$post_admin_language = $_POST['admin_language'];
    $post_admin_validation = $_POST['admin_validation'];
    $post_admin_theme = $_POST['admin_theme'];
	
	$x = 0;
	
	
	// Username | Count 1
	if($post_admin_username != '' && $post_admin_username != ' '){
		if(strlen($post_admin_username) > 4 && strlen($post_admin_username) < 31){
			$post_admin_username_copy = preg_replace('#[^A-Za-z0-9]#i', '', $post_admin_username);
		    if($post_admin_username == $post_admin_username_copy){
			$post_admin_username = preg_replace('#[^A-Za-z0-9]#i', '', $post_admin_username);
			$post_admin_username = $mysqli->real_escape_string($post_admin_username);
			// Username Check
			$check_username = false;
			$sql_checkUsername = "SELECT admin_ID FROM pc_admin WHERE admin_username='$post_admin_username'";
			$query_checkUsername = $mysqli->query($sql_checkUsername);
			if($query_checkUsername === FALSE){
				$check_username = false;
			}else{
				$count_checkUsername = $query_checkUsername->num_rows;
				if($count_checkUsername > 0){
					$check_username = true;
				}else{
					$check_username = false;
				}
			}
			if($check_username == false){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.taken']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.char']  . '</div>';
		}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.len']  . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.empty']  . '</div>';
	}
	
	
	// Email | Count 2
	if($x == 1){
		if($post_admin_email != '' && $post_admin_email != ' '){
			if(strlen($post_admin_email) < 256){
				// Email Check
			$post_admin_email = filter_var($post_admin_email, FILTER_SANITIZE_EMAIL);  
            if(filter_var($post_admin_email, FILTER_VALIDATE_EMAIL)){
	            $post_admin_email = $mysqli->real_escape_string($post_admin_email);
				$check_email = false;
				$sql_checkEmail = "SELECT admin_ID FROM pc_admin WHERE admin_email='$post_admin_email'";
				$query_checkEmail = $mysqli->query($sql_checkEmail);
				if($query_checkEmail === FALSE){
					$check_email = false;
				}else{
					$count_checkEmail = $query_checkEmail->num_rows;
					if($count_checkEmail > 0){
						$check_email = true;
					}else{
						$check_email = false;
					}
				}
				if($check_email == false){
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.taken']  . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.wrong']  . '</div>';
			}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.empty']  . '</div>';
		}
	}
	
	
	// Password | Count 3
	if($x == 2){
	    if($post_admin_password != '' && $post_admin_password != ' '){
		    if(strlen($post_admin_password) > 5 && strlen($post_admin_password) < 51){
				$post_admin_password = md5($post_admin_password);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.password.len']  . '</div>';
			}
	    }else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.password.empty']  . '</div>';
		}
	}
	
	
	// Phone | Count 4
	if($x == 3){
		if($post_admin_phone != '' && $post_admin_phone != ' '){
			if(strlen($post_admin_phone) < 31){
				$post_admin_phone_copy = preg_replace('#[^0-9]#i', '', $post_admin_phone);
		        if($post_admin_phone == $post_admin_phone_copy){
			        $x = $x + 1;						
		        }else{
			        $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.phone.char']  . '</div>';								
		        }
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.phone.len']  . '</div>';
			}
		}else{
			$post_admin_phone = '';
			$x = $x + 1;
		}
	}
	
	
	// Power | Count 5
	if($x == 4){
		if($post_admin_power == 'viewer' || $post_admin_power == 'moderator' || $post_admin_power == 'editor' || $post_admin_power == 'admin'){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.power.wrong']  . '</div>';
		}
	}
	
	
	// Language | Count 6
	if($x == 5){
		if($post_admin_language == 'en_US'){
			$x = $x + 1;
		}else{
			$post_admin_language == 'en_US';
			$x = $x + 1;
		}
	}
	
	
	// Validation | Count 7
	if($x == 6){
		if($post_admin_validation == 'Yes' || $post_admin_validation == 'No'){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.validation.wrong']  . '</div>';
		}
	}
	
	
	// Theme | Count 8
	if($x == 7){
		$theme_boolean = false;
		$admin_theme_array = array(
	        'Light Blue' => 'light-blue',
			'Blue Sea' => 'blue-sea',
	        'Summer Yellow' => 'summer-yellow',
	        'Green Tea' => 'green-tea',
	        'Red Fire' => 'red-fire'
        );
		foreach($admin_theme_array as $k => $v){
            if(preg_match("/$v/", $post_admin_theme)){
				$post_admin_theme = $v;
				$theme_boolean = true;
                break;
            }
	    }
		if($theme_boolean == true){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.theme.wrong']  . '</div>';
		}
	}
	
	
	// Final
	if($x == 8){
		
		
		$post_admin_email = $mysqli->real_escape_string($post_admin_email);
		
		// Create Admin
		$sql_addAdmin = "INSERT INTO pc_admin(admin_email, admin_username, admin_password, admin_phone, admin_power, 	admin_date) VALUES('$post_admin_email','$post_admin_username','$post_admin_password','$post_admin_phone','$post_admin_power',now())";
		$query_addAdmin = $mysqli->query($sql_addAdmin);
		
		// Create Settings
		$post_admin_id = $mysqli->insert_id;
		$sql_addSettings = "INSERT INTO pc_admin_settings(admin_ID, setting_language, setting_login_validation, setting_theme, setting_date) VALUES('$post_admin_id','$post_admin_language','$post_admin_validation','$post_admin_theme',now())";
		$query_addSettings = $mysqli->query($sql_addSettings);
		
		if($query_addAdmin === FALSE || $query_addSettings === FALSE){
			$message = '<div class="alert alert-wrong" role="alert">' . $lang['admin.newadministrator.alert.crash']  . '</div>';
		}else{
		    header("location: " . $GLOBALS['url'] . "/control_panel/administrators?status=success");
			exit();
		}
		
	}
	}else{
		$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower']  . '</div>';
	}
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.newadministrator.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.newadministrator.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/administrators"><i class="fa fa-briefcase" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $lang['admin.administrators.title']; ?></a></li>
            <li class="active"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.newadministrator.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/administrators-newAdmin" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.username']; ?></label>
						    <input type="text" class="form-control" name="admin_username" maxlength="30" autocomplete="off" value="<?php echo $post_admin_username; ?>">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.email']; ?></label>
						    <input type="email" class="form-control" name="admin_email" maxlength="255" autocomplete="off" value="<?php echo $post_admin_email; ?>">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.password']; ?></label>
						    <input type="password" class="form-control" name="admin_password" maxlength="50" autocomplete="off">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.phone']; ?></label>
						    <input type="tel" class="form-control" name="admin_phone" maxlength="30" autocomplete="off" value="<?php echo $post_admin_phone; ?>">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.power']; ?></label>
						    <select name="admin_power" class="form-control">
                                <option value="viewer"><?php echo $lang['admin.table.th.viewer']; ?> (<?php echo $lang['admin.form.select.option.viewer.det']; ?>)</option>
                                <option value="moderator"><?php echo $lang['admin.table.th.moderator']; ?> (<?php echo $lang['admin.form.select.option.moderator.det']; ?>)</option>
                                <option value="editor"><?php echo $lang['admin.table.th.editor']; ?> (<?php echo $lang['admin.form.select.option.editor.det']; ?>)</option>
                                <option value="admin"><?php echo $lang['admin.table.th.admin']; ?> (<?php echo $lang['admin.form.select.option.admin.det']; ?>)</option>
                            </select> 
						</div>
			        </div>
                </div>
		    </div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-wrench"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newadministrator.text.adminsettings']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <input type="hidden" name="admin_language" value="en_US">
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.securitycode']; ?></label>
                                    <select class="form-control"  name="admin_validation">
                                         <option value="No"><?php echo $lang['admin.form.select.option.no']; ?></option>
										<option value="Yes"><?php echo $lang['admin.form.select.option.yes']; ?></option>	
									</select>
                                </div>
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.theme']; ?></label>
                                    <select class="form-control" id="inputTheme" name="admin_theme">
										<option value="light-blue"><?php echo $lang['admin.form.select.option.theme.lightblue']; ?></option>
										<option value="blue-sea"><?php echo $lang['admin.form.select.option.theme.bluesea']; ?></option>
										<option value="green-tea"><?php echo $lang['admin.form.select.option.theme.greentea']; ?></option>
										<option value="summer-yellow"><?php echo $lang['admin.form.select.option.theme.summeryellow']; ?></option>
										<option value="red-fire"><?php echo $lang['admin.form.select.option.theme.redfire']; ?></option>
									</select>
                                </div>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.addadmin']; ?></button>
        <br>
        <br>
        </form>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>