<?php



define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


$post_brand_name = '';
$post_brand_url = '';
$post_brand_content = '';
$post_brand_status = '';
$brand_thumbnail = '';
$brand_banner = '';
$post_brand_sidebar = '';
$post_brand_sidebar_ID = '';
if(isset($_POST['brand_name'])){
	if($admin_power != 'viewer'){
	// Get Variables
	$x = 0;
	$post_brand_name = $_POST['brand_name'];
    $post_brand_content = $_POST['brand_content'];
    $post_brand_status = $_POST['brand_status'];
	$post_brand_sidebar = $_POST['brand_sidebar'];
    $post_brand_sidebar_ID = $_POST['brand_sidebar_ID'];
	
	// Brand Name | Count 1
	if($post_brand_name != '' && $post_brand_name != ' '){
		if(strlen($post_brand_name) < 101){
			$post_brand_name_copy = $post_brand_name;
			$post_brand_name_copy = strip_tags($post_brand_name_copy);
			$post_brand_name_copy = stripslashes($post_brand_name_copy);
			if($post_brand_name == $post_brand_name_copy){
				$post_brand_name = $mysqli->real_escape_string($post_brand_name);
				$post_brand_name = str_replace("'", "&#39;", $post_brand_name);
				$x = $x + 1; 
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandname.charproblem'] . '</div>';
			}
	    }else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandname.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newmenu.alert.menuname.empty'] . '</div>';
	}
	
	
	// Brand Content | Count 2
	if(strlen($post_brand_content) < 4294967296){
		$post_brand_content = htmlentities($post_brand_content, ENT_QUOTES);
		$post_brand_content = $mysqli->real_escape_string($post_brand_content);
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandcontent.len'] . '</div>';
	}
	
	
	// Brand Status | Count 3
	if($post_brand_status == 'p' || $post_brand_status == 'u'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandstatus.wrong'] . '</div>';
	}
	
	
	// Brand Thumb | Count 4
	$tumb = false;
	if($_FILES['brand_thumbnail']['tmp_name'] != ""){
		if($_FILES['brand_thumbnail']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.filesize'] . '</div>';
            unlink($_FILES['brand_thumbnail']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['brand_thumbnail']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.filename'] . '</div>';
            unlink($_FILES['brand_thumbnail']['tmp_name']); 	
        }else{
			
			// Find extension
			$tumbnail_extension = '';
			$tumbnail_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['brand_thumbnail']['name'])){
				$tumbnail_extension = '.gif';
				$tumbnail_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['brand_thumbnail']['name'])){
		        $tumbnail_extension = ".jpg";
		        $tumbnail_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['brand_thumbnail']['name'])){
		        $tumbnail_extension = ".png";
		        $tumbnail_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['brand_thumbnail']['name'])){
		        $tumbnail_extension = ".jpeg";
		        $tumbnail_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.filename'] . '</div>';
			}
			$tumb_name = $_FILES['brand_thumbnail']['name'];
			if(strlen($tumb_name) > 1000){
				$tumb_name = substr($tumb_name, 0, 950);
			}
			
			$tumb_name = strip_tags($tumb_name);
			$tumb_name = stripslashes($tumb_name);
			$tumb_name = str_replace('-', '_', $tumb_name);
			$tumb_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $tumb_name);
			$tumb_name = str_replace(' ', '-', $tumb_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $tumb_name)){
				$tumb_name = $tumb_name . $tumbnail_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$tumb_name_copy = str_replace($extension_Array, $extension_Array_replace, $tumb_name);
				while($file_checky == true){
					$tumb_name = $tumb_name_copy . "_" . $c . $tumbnail_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["brand_thumbnail"]["size"];
			if(move_uploaded_file($_FILES['brand_thumbnail']['tmp_name'], "../uploads/media/$media_path/$tumb_name")){
	            $tumb_name = $mysqli->real_escape_string($tumb_name);
				$sql_addTumbMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$tumb_name ','$tumb_name','$tumbnail_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$tumb = true;
				$brand_thumbnail = "uploads/media/$media_path/$tumb_name";
	            $brand_thumbnail = $mysqli->real_escape_string($brand_thumbnail);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.crash'] . '</div>';
			}
			
		}		
	}else{
		$x = $x + 1;
	}
	
	
	// Brand Banner | Count 5
	$banner = false;
	if($_FILES['brand_banner']['tmp_name'] != ""){
		if($_FILES['brand_banner']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.filesize'] . '</div>';
            unlink($_FILES['brand_banner']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['brand_banner']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.filename'] . '</div>';
            unlink($_FILES['brand_banner']['tmp_name']); 	
        }else{
			
			// Find extension
			$banner_extension = '';
			$banner_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['brand_banner']['name'])){
				$banner_extension = '.gif';
				$banner_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['brand_banner']['name'])){
		        $banner_extension = ".jpg";
		        $banner_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['brand_banner']['name'])){
		        $banner_extension = ".png";
		        $banner_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['brand_banner']['name'])){
		        $banner_extension = ".jpeg";
		        $banner_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.filename'] . '</div>';
			}
			$banner_name = $_FILES['brand_banner']['name'];
			if(strlen($banner_name) > 1000){
				$banner_name = substr($banner_name, 0, 950);
			}
			
			$banner_name = strip_tags($banner_name);
			$banner_name = stripslashes($banner_name);
			$banner_name = str_replace('-', '_', $banner_name);
			$banner_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $banner_name);
			$banner_name = str_replace(' ', '-', $banner_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $banner_name)){
				$banner_name = $banner_name . $banner_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$banner_name_copy = str_replace($extension_Array, $extension_Array_replace, $banner_name);
				while($file_checky == true){
					$banner_name = $banner_name_copy . "_" . $c . $banner_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["brand_banner"]["size"];
			if(move_uploaded_file($_FILES['brand_banner']['tmp_name'], "../uploads/media/$media_path/$banner_name")){
	            $banner_name = $mysqli->real_escape_string($banner_name);
				$sql_addBannerMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$banner_name ','$banner_name','$banner_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$banner = true;
				$brand_banner = "uploads/media/$media_path/$banner_name";
	            $brand_banner = $mysqli->real_escape_string($brand_banner);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.crash'] . '</div>';
			}
			
		}	
	}else{
		$x = $x + 1;
	}
	
	
	// Brand Sidebar | count 6
	if($post_brand_sidebar == 'left' || $post_brand_sidebar == 'right' || $post_brand_sidebar == 'none'){
			    $x = $x + 1;
		    }else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newpage.alert.sidebar.display.wrong'] . '</div>';
		    }
	
	
	// Brand Sidebar ID | Count 7
	if($post_brand_sidebar_ID != '' && $post_brand_sidebar_ID != ' '){
			    $check_sideName = pc_check_product_sidebarName($post_brand_sidebar_ID);
			    if($check_sideName == true){
				    $x = $x + 1;
				    $post_brand_sidebar_ID = preg_replace('#[^0-9]#i', '', $post_brand_sidebar_ID);
			    }else{
				    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newpage.alert.sidebar.name.wrong'] . '</div>';
			    }
		    }else{
			    $x = $x + 1;
			    $post_brand_sidebar_ID = '';
    }
	
	
	if($x == 7){
		
		// Crypt Site Url
		$post_brand_content = pc_dynamic_site_url_crypt($post_brand_content);
		
		// Brand URL
		$post_brand_url = strtolower($post_brand_name);
		$post_brand_url = preg_replace('#[^A-Za-z0-9- ]#i', '', $post_brand_url);
		$post_brand_url = str_replace(' ', '-', $post_brand_url);
		$post_brand_url = $mysqli->real_escape_string($post_brand_url);
		$post_brand_url_check = false;
		$sql_brandURL = "SELECT * FROM pc_products_brands WHERE brand_url='$post_brand_url'";
		$query_brandURL = $mysqli->query($sql_brandURL);
		if($query_brandURL === FALSE){
			//
		}else{
			$count_brandURL = $query_brandURL->num_rows;
			if($count_brandURL > 0 ){
				$post_brand_url_check = true;
			}
		}
		
		if($post_brand_url_check == true){
			$cp = 2;
			$check_url = true;
			while($check_url == true){
				
				$post_brand_url_copy = $post_brand_url . "-" . $cp;
				$post_brand_url_copy = $mysqli->real_escape_string($post_brand_url_copy);
				$sql_brandURL = "SELECT brand_name FROM pc_products_brands WHERE brand_url='$post_brand_url_copy'";
		        $query_brandURL = $mysqli->query($sql_brandURL);
		        if($query_brandURL === FALSE){
			        $check_url = false;
		        }else{
					$count_brandURL = $query_brandURL->num_rows;
			        if($count_brandURL > 0){
				        $check_url = true;
			        }else{
						$check_url = false;
					}
				}
				$cp = $cp + 1;
			}
			$post_brand_url = $post_brand_url_copy;
		}
		
		$sql_addBrand = "INSERT INTO pc_products_brands(brand_name, brand_url, brand_content, brand_thumbnail, brand_banner, brand_sidebar, brand_sidebar_ID, brand_status, brand_date) VALUES('$post_brand_name','$post_brand_url','$post_brand_content','$brand_thumbnail','$brand_banner','$post_brand_sidebar','$post_brand_sidebar_ID','$post_brand_status',now())";
		$query_addBrand = $mysqli->query($sql_addBrand);
		if($query_addBrand === FALSE){
			// Crash
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.newproduct.alert.productname.crash'] . '</div>';
			// Decrypt Site Url
			$post_brand_content = pc_dynamic_site_url_decrypt($post_brand_content);
		}else{
			// Ok
			if($brand_thumbnail != '' && $brand_thumbnail != ' '){
			    $mysqli->query($sql_addTumbMedia);
			}
			if($brand_banner != '' && $brand_banner != ' '){
			     $mysqli->query($sql_addBannerMedia);
			}
			header("location: " . $GLOBALS['url'] . "/control_panel/brands?status=success");
			exit();
		}
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}


// SIDEBARS LISTS
$sidebar_list = '';
$sql_sidebars = "SELECT sidebar_ID, sidebar_name FROM pc_sidebars ORDER BY sidebar_name";
$query_sidebars = $mysqli->query($sql_sidebars);
$count_sidebars = $query_sidebars->num_rows;
if($count_sidebars > 0){
	while($row_sidebars = $query_sidebars->fetch_assoc()){
		$sidebar_ID = $row_sidebars["sidebar_ID"];
		$sidebar_name = $row_sidebars["sidebar_name"];
		$sidebar_row = '<option value="' . $sidebar_ID . '">' . $sidebar_name . '</option>';
		$sidebar_list .= $sidebar_row;
	}
}else{
	//
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.newbrand.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.newbrand.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
			<li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/brands"><i class="fa fa-diamond" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $lang['admin.brands.title']; ?></a></li>
            <li class="active"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.newbrand.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/brands-newBrand" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
			            
							<div class="form-group">
								<label><?php echo $lang['admin.form.label.brandname']; ?></label>
						        <input type="text" class="form-control" name="brand_name" maxlength="100" autocomplete="off" value="<?php echo $post_brand_name; ?>">  
							</div>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.content']; ?></label>
                                <textarea id="descriptioneditor" class="form-control" name="brand_content"></textarea>
                            </div>
                            <div class="form-group">
								<label><?php echo $lang['admin.form.label.status']; ?></label>
						        <select name="brand_status" class="form-control">
                                    <option value="p"><?php echo $lang['admin.form.select.option.public']; ?></option>
                                    <option value="u"><?php echo $lang['admin.form.select.option.unpublished']; ?></option>
                                </select>
							</div>
						
					</div>
			    </div>
            </div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-picture-o"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.images']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.tumbnail']; ?></label>
                            <input class="displayNone" multiple id="brand_thumbnail" type="file" size="4" name="brand_thumbnail" style="display: none;"><br>
							<button type="button" id="uploadButton0" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.banner']; ?></label>
                            <input class="displayNone" multiple id="brand_banner" type="file" size="4" name="brand_banner" style="display: none;"><br>
							<button type="button" id="uploadButton2" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                    </div>
                </div>
                <!-- START LAYOUT -->
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
					    <h3 class="panel-title"><i class="fa fa-paint-brush"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.layout']; ?></b></h3>
					</div>
                    <div class="panel-body" style="background: #f5f5f5;">
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarposition']; ?></label>
						        <select class="form-control" name="brand_sidebar">  
								    <option value="right"><?php echo $lang['admin.form.select.option.right']; ?></option>
									<option value="left"><?php echo $lang['admin.form.select.option.left']; ?></option>
                                    <option value="none"><?php echo $lang['admin.form.select.option.none']; ?></option>
								</select>
                            </div>
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarname']; ?></label>
						        <select class="form-control" name="brand_sidebar_ID">  
							        <?php echo $sidebar_list; ?>
								</select>
                            </div>
                    </div>
                </div>
                <!-- END LAYOUT -->
            </div>
        </div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.addbrand']; ?></button>
        </form>
        <br>
        <br>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
    <script src="<?php echo $GLOBALS['url']; ?>/control_panel/include/summernote/summernote.js"></script>
     <script>
	    $(document).ready(function() {
            $('#descriptioneditor').summernote({
                height: 400,
	            callbacks: {
        onImageUpload : function(files, editor, welEditable) {

             for(var i = files.length - 1; i >= 0; i--) {
                     sendFile(files[i], this);
            }
        }
    }
            });
            function sendFile(file, el) {
var form_data = new FormData();
form_data.append('file', file);
$.ajax({
    data: form_data,
    type: "POST",
    url: 'saveimage.php',
    cache: false,
    contentType: false,
    processData: false,
    success: function(url) {
        $(el).summernote('editor.insertImage', url);
    }
});
}
<?php

$array_searchFilter = array("'", '\\', '`');
$array_replaceFilter = array("&#039", "&#092", "&#096");
$post_brand_content = str_replace($array_searchFilter, $array_replaceFilter, $post_brand_content);
$post_brand_content = trim(preg_replace('/\s\s+/', ' ', $post_brand_content));
$post_brand_content = html_entity_decode($post_brand_content);

?>
var markupStr = '<?php echo $post_brand_content; ?>';
$('#descriptioneditor').summernote('code', markupStr);
        });
    </script>
<script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#brand_thumbnail').html($('#brand_thumbnail').val());
			};
			$('#uploadButton0').on('click', function(){
				$('#brand_thumbnail').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
    <script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#brand_banner').html($('#brand_banner').val());
			};
			$('#uploadButton2').on('click', function(){
				$('#brand_banner').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
</body>
</html>