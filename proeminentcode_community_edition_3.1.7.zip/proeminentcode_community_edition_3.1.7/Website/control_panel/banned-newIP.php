<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


$banned_IP_post = '';
$banned_country_post = '';
$banned_reason_post = '';
if(isset($_POST['banned_IP'])){
	if($admin_power != 'viewer'){
	// Variables
	$x = 0;
	$banned_IP_post = $_POST['banned_IP'];
    $banned_country_post = $_POST['banned_country'];
    $banned_reason_post = $_POST['banned_reason'];
	
	// IP | Count 1
	if($banned_IP_post != '' && $banned_IP_post != ' '){
		if(filter_var($banned_IP_post, FILTER_VALIDATE_IP)){
			$banned_IP_post = $mysqli->real_escape_string($banned_IP_post);
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newipban.alert.ip.wrong'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newipban.alert.ip.empty'] . '</div>';
	}
	
	
	// Country | Count 2
	if($x == 1){
	    if($banned_country_post != '' && $banned_country_post != ' '){
		if(strlen($banned_country_post) < 51){
			$banned_country_post_copy = preg_replace('#[^A-Za-z ]#i', '', $banned_country_post);
			if($banned_country_post == $banned_country_post_copy){
				$banned_country_post = $mysqli->real_escape_string($banned_country_post);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newmember.alert.country.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newmember.alert.country.len'] . '</div>';
		}
	    }else{
		$banned_country_post = '';
		$x = $x + 1;
	    }
	}
	
	
	// Reason | Count 3
	if($x == 2){
		if($banned_reason_post != '' || $banned_reason_post != ' '){
			if(strlen($banned_reason_post) < 256){
				// ok
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newipban.alert.reason.len'] . '</div>';
			}
		}else{
			$banned_reason_post = '';
			$x = $x + 1;
		}
	}
	
	
	// Final
	if($x == 3){
		
		// Safe Reason
		$banned_reason_post = htmlentities($banned_reason_post, ENT_QUOTES);
		$banned_reason_post = $mysqli->real_escape_string($banned_reason_post);
		
		// Add IP
		$sql_addIP = "INSERT INTO pc_banned(banned_IP, banned_country, banned_reason, banned_date) VALUES('$banned_IP_post','$banned_country_post','$banned_reason_post',now())";
		$query_addIP = $mysqli->query($sql_addIP);
		if($query_addIP === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.newipban.alert.crash'] . '</div>';
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/banned?status=success");
			exit();
		}
	}else{
		$banned_reason_post = htmlentities($banned_reason_post, ENT_QUOTES);
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.newipban.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.newipban.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/banned"><i class="fa fa-ban" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $lang['admin.bannedips.title']; ?></a></li>
            <li class="active"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.newipban.title']; ?></li>
             
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/banned-newIP" method="post">
		    <div class="panel panel-default">
                <div class="panel-heading heading-white">
			        <h3 class="panel-title"><i class="fa fa-plus"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newipban.title']; ?></b></h3>
			    </div>
                <div class="panel-body">
			        <div class="form-group">
                        <label><?php echo $lang['admin.form.label.IP']; ?></label>
                        <input type="text" name="banned_IP" class="form-control" maxlength="39" value="<?php echo $banned_IP_post; ?>" autocomplete="off">
                        <br>
                    </div>
                    <div class="form-group">
                        <label><?php echo $lang['admin.form.label.country']; ?></label>
                        <select class="form-control" name="banned_country">
                            <option></option>
                            <?php include_once("../include/templates/countryes.php"); ?>
                        </select> 
                        <br>
                    </div>
                    <div class="form-group">
                        <label><?php echo $lang['admin.form.label.reason']; ?></label>
                        <textarea class="form-control" rows="4" name="banned_reason" style="resize: vertical;"><?php echo $banned_reason_post; ?></textarea>
                    </div>
			    </div>
		    </div>
            <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.addIP']; ?></button>
            <br>
            <br>
        </form>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>