<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


if($admin_power != 'admin'){
	header("location: " . $GLOBALS['url'] . "/control_panel/administrators?status=editadmin");
	exit();
}


// VARIABLES
$administrator_ID = '';
$administrator_email = '';
$administrator_username = '';
$administrator_password = '';
$administrator_phone = '';
$administrator_power = '';
$administrator_primary = '';
$administrator_last_IP = '';
$administrator_last_log = '';
$administrator_date = '';
$administrator_last_session = '';
$administrator_language = '';
$administrator_security = '';
$administrator_theme = '';
// ADMIN
if(isset($_GET['id'])){	
    $administrator_ID = $_GET['id'];
	$administrator_ID = preg_replace('#[^0-9]#i', '', $administrator_ID);
	// Check to see if admin is the edit admin
	if($session_id == $administrator_ID){
	    header("location: " . $GLOBALS['url'] . "/control_panel/admin-edit");
	    exit();
    }
	$sql_administratorInfo = "SELECT * FROM pc_admin WHERE admin_ID='$administrator_ID' LIMIT 1";
	$query_administratorInfo = $mysqli->query($sql_administratorInfo);
	if($query_administratorInfo === FALSE){
		header("location: " . $GLOBALS['url'] . "/control_panel/administrators");
	    exit();	
	}else{
		$count_administratorInfo = $query_administratorInfo->num_rows;
		if($count_administratorInfo > 0){
			// START DELETE ADMIN
			if(isset($_GET['action']) == 'delete'){
				if($admin_power == 'admin'){
					
					// Delete Account
					$sql_administratorsAccount = "DELETE FROM pc_admin WHERE admin_ID='$administrator_ID' LIMIT 1";
					$query_administratorsAccount = $mysqli->query($sql_administratorsAccount);
					
					// Delete Settings
					$sql_administratorsSettings = "DELETE FROM pc_admin_settings WHERE admin_ID='$administrator_ID' LIMIT 1";
					$query_administratorsSettings = $mysqli->query($sql_administratorsSettings);
					
					if($query_administratorsAccount === FALSE || $query_administratorsSettings === FALSE){
						$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editadministrators.alert.delete.crash'] . '</div>';
					}else{
						header("location:  " . $GLOBALS['url'] . "/control_panel/administrators?status=deleted");
                        exit();
					}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END DELETE ADMIN
			// START ADMIN INFO
			$row_administratorInfo = $query_administratorInfo->fetch_assoc();
			$administrator_email = $row_administratorInfo['admin_email'];
            $administrator_username = $row_administratorInfo['admin_username'];
			$administrator_password = $row_administratorInfo['admin_password'];
            $administrator_phone = $row_administratorInfo['admin_phone'];
            $administrator_power = $row_administratorInfo['admin_power'];
			$administrator_primary = $row_administratorInfo['admin_primary'];
			$administrator_last_IP = $row_administratorInfo['admin_last_IP'];
			if($administrator_last_IP != '' && $administrator_last_IP != ' '){
				$administrator_last_IP = '
				    <div class="form-group">
                        <label>' . $lang['admin.editmember.text.lastip'] . '</label>
                        <br>
						' . $administrator_last_IP. '
				    </div>
				';
			}
            $administrator_last_log = $row_administratorInfo['admin_last_log'];
			if($administrator_last_log != '' && $administrator_last_log != ' '){
				$administrator_last_log = date_function($administrator_last_log, 'datetime');
				$administrator_last_log = '
				    <div class="form-group">
                        <label>' . $lang['admin.editmember.text.lastlog'] . '</label>
                        <br>
						' . $administrator_last_log. '
				    </div>
				';
			}
            $administrator_date = $row_administratorInfo['admin_date'];
			if($administrator_date != '' && $administrator_date != ' '){
				$administrator_date = date_function($administrator_date, 'datetime');
				$administrator_date = '
				    <div class="form-group">
                        <label>' . $lang['admin.accountinfo.text.datecreated'] . '</label>
                        <br>
						' . $administrator_date. '
				    </div>
				';
			}
            $administrator_last_session = $row_administratorInfo['admin_last_session'];
			if($administrator_last_session != '' && $administrator_last_session != ' '){
				$administrator_last_session = date_function($administrator_last_session, 'datetime');
				$administrator_last_session = '
				    <div class="form-group">
                        <label>' . $lang['admin.table.th.lastseen'] . '</label>
                        <br>
						' . $administrator_last_session. '
				    </div>
				';
			}
			if($administrator_power == 'viewer'){
				$administrator_power = '<option value="viewer">' . $lang['admin.table.th.viewer'] . ' (' . $lang['admin.form.select.option.viewer.det'] . ')</option>';
			}else if($administrator_power == 'moderator'){
				 $administrator_power = '<option value="moderator">' . $lang['admin.table.th.moderator'] . ' (' . $lang['admin.form.select.option.moderator.det'] . ')</option>';                  
			}else if($administrator_power == 'editor'){
				$administrator_power = '<option value="editor">' . $lang['admin.table.th.editor'] . ' (' . $lang['admin.form.select.option.editor.det'] . ')</option>';               
			}else{
				if($administrator_primary == 1){
					header("location: " . $GLOBALS['url'] . "/control_panel/administrators?status=primary");
	                exit();
				}else{
                    $administrator_power = '<option value="admin">' . $lang['admin.table.th.admin'] . ' (' . $lang['admin.form.select.option.admin.det'] . ')</option>';
                }
			}
			$sql_administratorSettings = "SELECT * FROM pc_admin_settings WHERE admin_ID='$administrator_ID' LIMIT 1";
			$query_administratorSettings = $mysqli->query($sql_administratorSettings);
			if($query_administratorSettings === FALSE){
				
			}else{
				$count_administratorSettings = $query_administratorSettings->num_rows;
				if($count_administratorSettings > 0){
					$row_administratorSettings = $query_administratorSettings->fetch_assoc(); 
					$administrator_language = $row_administratorSettings['setting_language'];
                    $administrator_security = $row_administratorSettings['setting_login_validation'];
					if($administrator_security == 'Yes'){
						$administrator_security = '<option value="Yes">' . $lang['admin.form.select.option.yes'] . '</option>';
					}else{
						$administrator_security = '<option value="No">' . $lang['admin.form.select.option.no'] . '</option>';
					}
                    $administrator_theme = $row_administratorSettings['setting_theme'];
	              	if($administrator_theme == 'light-blue'){
	                    $administrator_theme = '<option value="light-blue">' . $lang['admin.form.select.option.theme.lightblue'] . '</option>';
                    }else if($administrator_theme == 'blue-sea'){
	                    $administrator_theme = '<option value="blue-sea">' . $lang['admin.form.select.option.theme.bluesea'] . '</option>';
                    }else if($administrator_theme == 'green-tea'){
	                    $administrator_theme = '<option value="green-tea">' . $lang['admin.form.select.option.theme.greentea'] . '</option>';
                    }else if($administrator_theme == 'summer-yellow'){
	                    $administrator_theme = '<option value="summer-yellow">' . $lang['admin.form.select.option.theme.summeryellow'] . '</option>';
                    }else{
	                    $administrator_theme = '<option value="red-fire">' . $lang['admin.form.select.option.theme.redfire'] . '</option>';
                    }
				}
			}
			// END ADMIN INFO
			// START UPDATE ADMIN
			$post_admin_username = '';
$post_admin_email = '';
$post_admin_password = '';
$post_admin_phone = '';
$post_admin_power = '';
$post_admin_language = '';
$post_admin_validation = '';
$post_admin_theme = '';
if(isset($_POST['admin_username'])){
	$post_admin_username = $_POST['admin_username'];
    $post_admin_email = $_POST['admin_email'];
    $post_admin_password = $_POST['admin_password'];
    $post_admin_phone = $_POST['admin_phone'];
    $post_admin_power = $_POST['admin_power'];
	$post_admin_language = $_POST['admin_language'];
    $post_admin_validation = $_POST['admin_validation'];
    $post_admin_theme = $_POST['admin_theme'];
	
	$x = 0;
	
	
	// Username | Count 1
	if($post_admin_username != '' && $post_admin_username != ' '){
		if(strlen($post_admin_username) > 4 && strlen($post_admin_username) < 31){
			$post_admin_username_copy = preg_replace('#[^A-Za-z0-9]#i', '', $post_admin_username);
		    if($post_admin_username == $post_admin_username_copy){
			$post_admin_username = preg_replace('#[^A-Za-z0-9]#i', '', $post_admin_username);
			$post_admin_username = $mysqli->real_escape_string($post_admin_username);
			// Username Check
			$check_username = false;
			$sql_checkUsername = "SELECT admin_ID FROM pc_admin WHERE admin_username<>'$administrator_username' AND admin_username='$post_admin_username'";
			$query_checkUsername = $mysqli->query($sql_checkUsername);
			if($query_checkUsername === FALSE){
				$check_username = false;
			}else{
				$count_checkUsername = $query_checkUsername->num_rows;
				if($count_checkUsername > 0){
					$check_username = true;
				}else{
					$check_username = false;
				}
			}
			if($check_username == false){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.taken']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.char']  . '</div>';
		}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.len']  . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.username.empty']  . '</div>';
	}
	
	
	// Email | Count 2
	if($x == 1){
		if($post_admin_email != '' && $post_admin_email != ' '){
			if(strlen($post_admin_email) < 256){
				// Email Check
			$post_admin_email = filter_var($post_admin_email, FILTER_SANITIZE_EMAIL);  
            if(filter_var($post_admin_email, FILTER_VALIDATE_EMAIL)){
	            $post_admin_email = $mysqli->real_escape_string($post_admin_email);
				$check_email = false;
				$sql_checkEmail = "SELECT admin_ID FROM pc_admin WHERE admin_email<>'$administrator_email' AND admin_email='$post_admin_email'";
				$query_checkEmail = $mysqli->query($sql_checkEmail);
				if($query_checkEmail === FALSE){
					$check_email = false;
				}else{
					$count_checkEmail = $query_checkEmail->num_rows;
					if($count_checkEmail > 0){
						$check_email = true;
					}else{
						$check_email = false;
					}
				}
				if($check_email == false){
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.taken']  . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.wrong']  . '</div>';
			}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.email.empty']  . '</div>';
		}
	}
	
	
	// Password | Count 3
	if($x == 2){
	    if($post_admin_password != '' && $post_admin_password != ' '){
		    if(strlen($post_admin_password) > 5 && strlen($post_admin_password) < 51){
				$post_admin_password = md5($post_admin_password);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.password.len']  . '</div>';
			}
	    }else{
			$post_admin_password = $administrator_password;
			$x = $x + 1;
		}
	}
	
	
	// Phone | Count 4
	if($x == 3){
		if($post_admin_phone != '' && $post_admin_phone != ' '){
			if(strlen($post_admin_phone) < 31){
				$post_admin_phone_copy = preg_replace('#[^0-9]#i', '', $post_admin_phone);
		        if($post_admin_phone == $post_admin_phone_copy){
			        $x = $x + 1;						
		        }else{
			        $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.phone.char']  . '</div>';								
		        }
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.phone.len']  . '</div>';
			}
		}else{
			$post_admin_phone = '';
			$x = $x + 1;
		}
	}
	
	
	// Power | Count 5
	if($x == 4){
		if($post_admin_power == 'viewer' || $post_admin_power == 'moderator' || $post_admin_power == 'editor' || $post_admin_power == 'admin'){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.power.wrong']  . '</div>';
		}
	}
	
	
	// Language | Count 6
	if($x == 5){
		if($post_admin_language == 'en_US'){
			$x = $x + 1;
		}else{
			$post_admin_language == 'en_US';
			$x = $x + 1;
		}
	}
	
	
	// Validation | Count 7
	if($x == 6){
		if($post_admin_validation == 'Yes' || $post_admin_validation == 'No'){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.validation.wrong']  . '</div>';
		}
	}
	
	
	// Validation | Count 8
	if($x == 7){
		$theme_boolean = false;
		$admin_theme_array = array(
	        'Light Blue' => 'light-blue',
			'Blue Sea' => 'blue-sea',
	        'Summer Yellow' => 'summer-yellow',
	        'Green Tea' => 'green-tea',
	        'Red Fire' => 'red-fire'
        );
		foreach($admin_theme_array as $k => $v){
            if(preg_match("/$v/", $post_admin_theme)){
				$post_admin_theme = $v;
				$theme_boolean = true;
                break;
            }
	    }
		if($theme_boolean == true){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newadministrator.alert.theme.wrong']  . '</div>';
		}
	}
	
	
	// Final
	if($x == 8){
		
		
		$post_admin_email = $mysqli->real_escape_string($post_admin_email);
		
		// Update Admin
		$sql_updateAdmin = "UPDATE pc_admin SET admin_email='$post_admin_email', admin_username='$post_admin_username', admin_password='$post_admin_password', admin_phone='$post_admin_phone', admin_power='$post_admin_power' WHERE admin_ID='$administrator_ID' LIMIT 1";
		$query_updateAdmin = $mysqli->query($sql_updateAdmin);
		
		// Update Settings
		$sql_updateSettings = "UPDATE pc_admin_settings SET setting_login_validation='$post_admin_validation', setting_theme='$post_admin_theme', setting_update=now() WHERE admin_ID='$administrator_ID' LIMIT 1";
		$query_updateSettings = $mysqli->query($sql_updateSettings);
		
		if($query_updateAdmin === FALSE || $query_updateSettings === FALSE){
			$message = '<div class="alert alert-wrong" role="alert">' . $lang['admin.editadministrator.alert.crash']  . '</div>';
		}else{
		    header("location: " . $GLOBALS['url'] . "/control_panel/administrators-editAdmin?id=" . $administrator_ID . "&update=success");
			exit();
		}
		
	}
}
			// END UPDATE ADMIN
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/administrators");
	        exit();	
		}
	}
}else{
	header("location: " . $GLOBALS['url'] . "/control_panel/administrators");
	exit();
}


// Update
if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editadministrator.alert.success'] . '</div>';
	}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.editadministrator.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<!-- START DELETE ADMIN MODAL -->
<div class="modal fade" id="deleteAdmin" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.button.deleteadmin']; ?></h4>
            </div>
            <div class="modal-body">
                <p><?php echo $lang['alert.editadministrator.remove.confirm']; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <a href="<?php echo $GLOBALS['url']; ?>/control_panel/administrators-editAdmin?id=<?php echo $administrator_ID; ?>&action=delete"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deleteadmin']; ?></button></a>
            </div>
        </div>
    </div>
</div>
<!-- END DELETE ADMIN MODAL -->
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.editadministrator.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/administrators"><i class="fa fa-briefcase" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $lang['admin.administrators.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $administrator_username; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/administrators-editAdmin?id=<?php echo $administrator_ID; ?>" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.username']; ?></label>
						    <input type="text" class="form-control" name="admin_username" maxlength="30" autocomplete="off" value="<?php echo $administrator_username; ?>">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.email']; ?></label>
						    <input type="email" class="form-control" name="admin_email" maxlength="255" autocomplete="off" value="<?php echo $administrator_email; ?>">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.password']; ?></label>
						    <input type="password" class="form-control" name="admin_password" maxlength="50" autocomplete="off">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.phone']; ?></label>
						    <input type="tel" class="form-control" name="admin_phone" maxlength="30" autocomplete="off" value="<?php echo $administrator_phone; ?>">  
                            <br>
						</div>
                        <div class="form-group">
							<label><?php echo $lang['admin.form.label.power']; ?></label>
						    <select name="admin_power" class="form-control">
                                <?php echo $administrator_power; ?>
                                <option value="viewer"><?php echo $lang['admin.table.th.viewer']; ?> (<?php echo $lang['admin.form.select.option.viewer.det']; ?>)</option>
                                <option value="moderator"><?php echo $lang['admin.table.th.moderator']; ?> (<?php echo $lang['admin.form.select.option.moderator.det']; ?>)</option>
                                <option value="editor"><?php echo $lang['admin.table.th.editor']; ?> (<?php echo $lang['admin.form.select.option.editor.det']; ?>)</option>
                                <option value="admin"><?php echo $lang['admin.table.th.admin']; ?> (<?php echo $lang['admin.form.select.option.admin.det']; ?>)</option>
                            </select> 
						</div>
			        </div>
                </div>
		    </div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-wrench"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newadministrator.text.adminsettings']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <input type="hidden" name="admin_language" value="en_US">
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.securitycode']; ?></label>
                                    <select class="form-control"  name="admin_validation">
                                        <?php echo $administrator_security; ?>
                                        <option value="No"><?php echo $lang['admin.form.select.option.no']; ?></option>
										<option value="Yes"><?php echo $lang['admin.form.select.option.yes']; ?></option>	
									</select>
                                    <br>
                                </div>
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.theme']; ?></label>
                                    <select class="form-control" id="inputTheme" name="admin_theme">
                                        <?php echo $administrator_theme; ?>
										<option value="light-blue"><?php echo $lang['admin.form.select.option.theme.lightblue']; ?></option>
										<option value="blue-sea"><?php echo $lang['admin.form.select.option.theme.bluesea']; ?></option>
										<option value="green-tea"><?php echo $lang['admin.form.select.option.theme.greentea']; ?></option>
										<option value="summer-yellow"><?php echo $lang['admin.form.select.option.theme.summeryellow']; ?></option>
										<option value="red-fire"><?php echo $lang['admin.form.select.option.theme.redfire']; ?></option>
									</select>
                                </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.editadministrator.text.admininfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <?php echo $administrator_last_session; ?>
                        <?php echo $administrator_last_IP; ?>
                        <?php echo $administrator_last_log; ?>
                        <?php echo $administrator_date; ?>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
        <a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteAdmin"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deleteadmin']; ?></a>
        <br>
        <br>
        </form>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>