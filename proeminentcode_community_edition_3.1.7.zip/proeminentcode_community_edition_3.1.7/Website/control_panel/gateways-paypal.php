<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $config['BASE_URL']. "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// Variables
$gateway_ID = '';
$gateway_type = '';
$gateway_name = '';
$gateway_email = '';
$gateway_sandbox = '';
$gateway_status = '';
$gateway_update = '';
$gateway_date = '';
if(isset($_GET['id'])){	
	$gateway_ID = $_GET['id'];
	$gateway_ID = preg_replace('#[^0-9]#i', '', $gateway_ID);
	$sql_gatewayInfo = "SELECT * FROM pc_gateways WHERE gateway_ID='$gateway_ID' AND gateway_configured='1' LIMIT 1";
	$query_gatewayInfo = $mysqli->query($sql_gatewayInfo);
	if($query_gatewayInfo === FALSE){
		header("location: " . $GLOBALS['url'] . "/control_panel/gateways");
	    exit();	
	}else{
		$count_gatewayInfo = $query_gatewayInfo->num_rows;
		if($count_gatewayInfo > 0){
			// START GATEWAY INFO
			$row_gatewayInfo = $query_gatewayInfo->fetch_assoc();
			$gateway_type = $row_gatewayInfo['gateway_type'];
            $gateway_name = $row_gatewayInfo['gateway_name'];
            $gateway_email = $row_gatewayInfo['gateway_email'];
			$gateway_sandbox = $row_gatewayInfo['gateway_sandbox'];
			if($gateway_sandbox == 1){
				$gateway_sandbox = '<option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>';
			}else{
				$gateway_sandbox = '<option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>';
			}
            $gateway_status = $row_gatewayInfo['gateway_status'];
			if($gateway_status == 1){
				$gateway_status = '<option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>';
			}else{
				$gateway_status = '<option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>';
			}
            $gateway_update = $row_gatewayInfo['gateway_update'];
			if($gateway_update != '' && $gateway_update != ' '){
				$gateway_update = date_function($gateway_update, 'datetime');
			    $gateway_update = '
				    <div class="form-group">
                        <label>' . $lang['admin.table.th.update'] . '</label>
                        <br>
						' . $gateway_update. '
				    </div>
				';	
			}
			$gateway_date = date_function($row_gatewayInfo['gateway_date'], 'datetime');
			// END GATEWAY INFO
			// START GATEWAY UPDATE
			$pp_email = '';
			$pp_sandbox = '';
			$pp_status = '';	
			if(isset($_POST['pp_email'])){
				if($admin_power != 'viewer'){
					
					// Values
				    $pp_email = $_POST['pp_email'];
					$pp_sandbox = $_POST['pp_sandbox'];
					$pp_status = $_POST['pp_status'];	
					
					$x = 0;
					
					
					// PP Email | Count 1
					if($pp_email != '' && $pp_email != ''){
						if(strlen($pp_email) < 256){
							$pp_email = filter_var($pp_email, FILTER_SANITIZE_EMAIL);
		                    if(filter_var($pp_email, FILTER_VALIDATE_EMAIL)){
						        $pp_email = $mysqli->real_escape_string($pp_email);
						        $x = $x + 1;
							}else{
								$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.gateways.PayPal.alert.email.wrong'] . '</div>';
							}
						}else{
							$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.gateways.PayPal.alert.email.len'] . '</div>';
						}
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.gateways.PayPal.alert.email.empty'] . '</div>';
					}
					
					
					// Sandbox | Count 3
					if($x == 1){
						if($pp_sandbox == 1 || $pp_sandbox == 0){
							$x = $x + 1;
						}else{
							$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.gateways.2Checkout.alert.sandbox.wrong'] . '</div>';
						}
					}
					
					
					// Status | Count 4
					if($x == 2){
						if($pp_status == 1 || $pp_status == 0){
							$x = $x + 1;
						}else{
							$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.gateways.2Checkout.alert.status.wrong'] . '</div>';
						}
					}
					
					
					// Final
					if($x == 3){
						$sql_updateGateway = "UPDATE pc_gateways SET gateway_email='$pp_email', gateway_sandbox='$pp_sandbox', gateway_status='$pp_status', gateway_update=now() WHERE gateway_ID='$gateway_ID' LIMIT 1";
						$query_updateGateway = $mysqli->query($sql_updateGateway);
						if($query_updateGateway === FALSE){
							$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.paymentgateways.alert.crash'] . '</div>';
						}else{
							header("location: " . $GLOBALS['url'] . "/control_panel/gateways-paypal?id=" . $gateway_ID . "&update=success");
			                exit();
						}
					}
					
				}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END GATEWAY UPDATE
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/gateways");
	        exit();	
		}
	}
}else{
	header("location: " . $GLOBALS['url'] . "/control_panel/gateways");
	exit();	
}


// Updates
if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.paymentgateways.alert.success'] . '</div>';
	}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $gateway_name; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $gateway_name; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/gateways"><i class="fa fa-usd"></i>&nbsp;&nbsp;<?php echo $lang['admin.paymentgateways.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $gateway_name; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/gateways-paypal?id=<?php echo $gateway_ID; ?>" method="post">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b><?php echo $gateway_name; ?></b></h3>
			       </div>
                   <div class="panel-body">
                       <div class="form-group">
						    <label><?php echo $lang['admin.form.label.paypalemail']; ?></label>
					        <input type="email" name="pp_email" class="form-control" maxlength="255" value="<?php echo $gateway_email; ?>" autocomplete="off">
                            <br>
					    </div>
						<div class="form-group">
						    <label><?php echo $lang['admin.form.label.sandbox']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.gateway.sandbox']; ?>"></i></label>
					        <select class="form-control" name="pp_sandbox">
							    <?php echo $gateway_sandbox; ?>
								<option value="1"><?php echo $lang['admin.form.select.option.enabled']; ?></option>
								<option value="0"><?php echo $lang['admin.form.select.option.disabled']; ?></option>
							</select>
                            <br>
					    </div>
						<div class="form-group">
						    <label><?php echo $lang['admin.form.label.status']; ?></label>
					        <select class="form-control" name="pp_status">
							    <?php echo $gateway_status; ?>
								<option value="1"><?php echo $lang['admin.form.select.option.enabled']; ?></option>
								<option value="0"><?php echo $lang['admin.form.select.option.disabled']; ?></option>
							</select>
						</div>
                   </div>
                </div>
			</div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-signal"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.gateways.text.gatewaystatistics']; ?></b></h3>
			       </div>
                   <div class="panel-body">
                       <a href="https://www.paypal.com" target="_blank"><img src="<?php echo $GLOBALS['url']; ?>/assets/images/gateways/paypal_gateway.png" width="100%"></a>
                       <hr>
                       <?php echo $gateway_update; ?>
                       <div class="form-group">
                           <label><?php echo $lang['admin.table.th.date']; ?></label>
                           <br>
                           <?php echo $gateway_date; ?>
                        </div>
                   </div>
               </div>
            </div>
		</div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
            <br>
            <br>
        </form>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>