<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// Change Password
if(isset($_POST['current_pass'])){
	if($admin_power != 'viewer'){
	// Variables
	$current_pass = $_POST['current_pass'];
	$new_password = $_POST['new_password'];
	$confirm_password = $_POST['confirm_password'];
	
	// Current Password
	if($current_pass != '' && $current_pass != ' '){
		// New Password
		if($new_password != '' && $new_password != ' '){
			// Confirm Password
			if($confirm_password != '' && $confirm_password != ' '){	
				// Check current password
				$current_pass = md5($current_pass);
				if($current_pass == $session_pass){
					// Match password
					if($new_password == $confirm_password){
						// Check len
						if(strlen($new_password) > 6 && strlen($new_password ) < 100){
							$new_password = md5($new_password);
							$sql_updatePass = "UPDATE pc_admin SET admin_password='$new_password' WHERE admin_ID='$session_id' LIMIT 1";
							$query_updatePass = $mysqli->query($sql_updatePass);
							if($query_updatePass === FALSE){
								$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.changepass.crash'] . '</div>';
							}else{							
								$message = '<div class="alert alert-success" role="alert">' . $lang['alert.updates.success']  . '</div>';
							}
						}else{
							$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.changepass.password.len'] . '</div>';
						}
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.changepass.dont.match'] . '</div>';
					}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.changepass.wrong.password'] . '</div>';
				}		
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.changepass.empty.newpasword'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.changepass.empty.newpasword'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.changepass.empty.currentpass'] . '</div>';
	}
	}else{
		$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower']  . '</div>';
	}
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.changepassword.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
        <?php include_once("tmp/header.php"); ?>
        <?php include_once("tmp/aside.php"); ?>
	    <div id="page-content-wrapper">
            <?php echo $message; ?>
			<h1><?php echo $lang['admin.settings.title']; ?></h1>
			<ol class="breadcrumb">
                <li><a href="<?php echo $GLOBALS['url'] ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
                <li class="active"><i class="fa fa-user"></i>&nbsp;&nbsp;<?php echo $lang['admin.myaccount.title']; ?></li>
                <li class="active"><i class="fa fa-refresh"></i>&nbsp;&nbsp;<?php echo $lang['admin.changepassword.title']; ?></li>
            </ol>
            <?php include_once("tmp/tmp-quickActions.php"); ?>
			<div class="panel panel-default">
                <div class="panel-heading heading-white">
				    <h3 class="panel-title"><i class="fa fa-refresh"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.changepassword.title']; ?></b></h3>
				</div>
                <form action="<?php echo $GLOBALS['url'] ?>/control_panel/admin-changePass" method="post">
                <div class="panel-body">
				    <div class="row">
                        <div class="col-md-6">
								<div class="form-group">
                                    <label><?php echo $lang['admin.form.label.currentpassword']; ?></label>
                                    <input type="password" name="current_pass" class="form-control" autocomplete="off" maxlength="50">
                                </div>
								<div class="form-group">
                                    <label><?php echo $lang['admin.form.label.newpassword']; ?></label>
                                    <input type="password" name="new_password" class="form-control" autocomplete="off" maxlength="50">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $lang['admin.form.label.confirmpassword']; ?></label>
                                    <input type="password" name="confirm_password" class="form-control" autocomplete="off" maxlength="50">
                                </div>
                        </div>
                        <div class="col-md-6"></div>
                    </div>
				</div>
		    </div>
            <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
            <br>
            <br>
			</form>
            <?php include_once("tmp/footer.php"); ?>
		</div>
    </div>				
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>