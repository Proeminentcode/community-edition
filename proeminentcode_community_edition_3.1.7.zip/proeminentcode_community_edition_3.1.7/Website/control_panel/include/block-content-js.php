<?php

// Restrict Access
if(_VALID != 'Yes'){
	include_once("../../../404.php");
    exit();
}

?>
<script src="<?php echo $GLOBALS['url']; ?>/control_panel/include/summernote/summernote.js"></script>
<script>
	    $(document).ready(function() {
            $('#descriptioneditor').summernote({
                height: 250,
	            callbacks: {
        onImageUpload : function(files, editor, welEditable) {

             for(var i = files.length - 1; i >= 0; i--) {
                     sendFile(files[i], this);
            }
        }
    }
            });
            function sendFile(file, el) {
var form_data = new FormData();
form_data.append('file', file);
$.ajax({
    data: form_data,
    type: "POST",
    url: 'saveimage.php',
    cache: false,
    contentType: false,
    processData: false,
    success: function(url) {
        $(el).summernote('editor.insertImage', url);
    }
});
}
<?php

$array_searchFilter = array("'", '\\', '`');
$array_replaceFilter = array("&#039", "&#092", "&#096");
$block_textHTML_content = str_replace($array_searchFilter, $array_replaceFilter, $block_textHTML_content);
$block_textHTML_content = trim(preg_replace('/\s\s+/', ' ', $block_textHTML_content));
$block_textHTML_content = html_entity_decode($block_textHTML_content);

?>
var markupStr = '<?php echo $block_textHTML_content; ?>';
$('#descriptioneditor').summernote('code', markupStr);
        });
    </script>
    <script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#post_tumbnail').html($('#post_tumbnail').val());
			};
			$('#uploadButton0').on('click', function(){
				$('#post_tumbnail').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>