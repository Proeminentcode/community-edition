<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.help.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
        <?php include_once("tmp/header.php"); ?>
        <?php include_once("tmp/aside.php"); ?>
	    <div id="page-content-wrapper">
            <?php echo $message; ?>
			<h1><?php echo $lang['admin.help.title']; ?></h1>
			<ol class="breadcrumb">
                <li><a href="<?php echo $GLOBALS['url'] ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
                <li class="active"><i class="fa fa-question-circle"></i>&nbsp;&nbsp;<?php echo $lang['admin.help.title']; ?></li>
            </ol>
            <?php include_once("tmp/tmp-quickActions.php"); ?>
			<div class="panel panel-default">
                <div class="panel-heading heading-white">
				    <h3 class="panel-title"><i class="fa fa-question-circle"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.help.title']; ?></b></h3>
				</div>
                <div class="panel-body">
                    <br>
                    
				</div>
		    </div>
            <?php include_once("tmp/footer.php"); ?>
		</div>
    </div>				
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>