<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// VARIABLES
$coupon_ID = '';
$coupon_code = '';
$coupon_type = '';
$coupon_discount = '';
$coupon_times = '';
$coupon_used = '';
$coupon_status = '';
$coupon_expire = '';
$coupon_update = '';
$coupon_date = '';
if(isset($_GET['id'])){
	$coupon_ID = $_GET['id'];
	$coupon_ID = preg_replace('#[^0-9]#i', '', $coupon_ID);
	$sql_couponInfo = "SELECT * FROM pc_coupons WHERE coupon_ID='$coupon_ID' LIMIT 1";
	$query_couponInfo = $mysqli->query($sql_couponInfo);
	if($query_couponInfo === FALSE){
		header("location:  " . $GLOBALS['url']. "/control_panel/coupons");
	    exit();	
	}else{
		$count_couponInfo = $query_couponInfo->num_rows;
		if($count_couponInfo > 0){
			// START DELETE COUPON
			if(isset($_GET['action']) == 'delete'){
				if($admin_power != 'viewer'){
				    $sql_deleteCoupon = "DELETE FROM pc_coupons WHERE coupon_ID='$coupon_ID'";
					$query_deleteCoupon = $mysqli->query($sql_deleteCoupon);
					if($query_deleteCoupon === FALSE){
						$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcoupon.alert.remove.crash'] . '</div>';
					}else{
						header("location:  " . $GLOBALS['url'] . "/control_panel/coupons?remove=deleted");
                        exit();
					}
				}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END DELETE COUPON
			// START COUPON INFO
			$row_couponInfo = $query_couponInfo->fetch_assoc();
			$coupon_code = $row_couponInfo['coupon_code'];
            $coupon_type =  $row_couponInfo['coupon_type'];
			if($coupon_type == 'p'){
				$coupon_type = '<option value="p">' . $lang['admin.form.select.option.percent'] . '</option>';
			}else{
				$coupon_type = '<option value="a">' . $lang['admin.form.select.option.amount'] . '</option>';
			}
            $coupon_discount =  $row_couponInfo['coupon_discount'];
            $coupon_times =  $row_couponInfo['coupon_times'];
            $coupon_used =  $row_couponInfo['coupon_used'];
            $coupon_status =  $row_couponInfo['coupon_status'];
			if($coupon_status == '1'){
				$coupon_status = '<option value="1">' . $lang['admin.form.select.option.public'] . '</option>';
			}else{
				$coupon_status = '<option value="0">' . $lang['admin.form.select.option.unpublished'] . '</option>';
			}
            $coupon_expire =  $row_couponInfo['coupon_expire'];
            $coupon_update =  $row_couponInfo['coupon_update'];
			if($coupon_update != '' && $coupon_update != ' '){
				$coupon_update = date_function($coupon_update, 'datetime');	
				$coupon_update = '
				    <div class="form-group">
                                <label>' . $lang['admin.table.th.update'] . '</label>
                                <br>
								' . $coupon_update . '
                    </div>
				';							
			}
            $coupon_date =  $row_couponInfo['coupon_date'];
			$coupon_date = date_function($coupon_date, 'datetime');
			// END COUPON INFO
			// START UPDATE COUPON
			if(isset($_POST['coupon_code'])){
				if($admin_power != 'viewer'){
				$post_coupon_code = '';
$post_coupon_type = '';
$post_coupon_discount = '';
$post_coupon_times = '';
$post_coupon_expire = '';
$post_coupon_status = '';
	$x = 0;
	$post_coupon_code = $_POST['coupon_code'];
    $post_coupon_type = $_POST['coupon_type'];
    $post_coupon_discount = $_POST['coupon_discount'];
    $post_coupon_times = $_POST['coupon_times'];
	$post_coupon_expire = $_POST['coupon_expire'];
    $post_coupon_status = $_POST['coupon_status'];
	
	// Coupon Code | Count 1
	if($post_coupon_code != '' && $post_coupon_code != ' '){
		if(strlen($post_coupon_code) < 51){
			$post_coupon_code_copy = preg_replace('#[^A-Za-z0-9]#', '', $post_coupon_code);
			if($post_coupon_code == $post_coupon_code_copy){
				$post_coupon_code_copy = $mysqli->real_escape_string($post_coupon_code_copy);
				$coupon_check = false;
				$sql_checkCode = "SELECT coupon_ID FROM pc_coupons WHERE coupon_code='$post_coupon_code_copy' AND coupon_ID<>'$coupon_ID'";
				$query_checkCode = $mysqli->query($sql_checkCode);
				if($query_checkCode === FALSE){
					$coupon_check = false;
				}else{
					$count_checkCode = $query_checkCode->num_rows;
					if($count_checkCode > 0){
						$coupon_check = true;
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.taken'] . '</div>';
					}else{
					    $coupon_check = false;	
					}
				}
				if($coupon_check == false){
					$post_coupon_code = $mysqli->real_escape_string($post_coupon_code);
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.taken'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.empty'] . '</div>';
	}
	
	
	// Coupon Type | Count 2
	if($post_coupon_type == 'a' || $post_coupon_type == 'p'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupontype.wrong'] . '</div>';
	}
	
	
	// Coupon Discount | Count 3
	if($post_coupon_discount != '' && $post_coupon_discount != ' '){
		if(strlen($post_coupon_discount) < 21){
			$post_coupon_discount_copy = preg_replace('#[^0-9.]#i', '', $post_coupon_discount);
			if($post_coupon_discount == $post_coupon_discount_copy){
				$post_coupon_discount = $mysqli->real_escape_string($post_coupon_discount);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupondiscount.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupondiscount.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupondiscount.empty'] . '</div>';
	}
	
	
	// Coupon Discount | Count 4
	if(strlen($post_coupon_times) < 21){
		if($post_coupon_times != '' && $post_coupon_times != ' '){
			if(ctype_digit($post_coupon_times)){
				$post_coupon_times = $mysqli->real_escape_string($post_coupon_times);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupontype.char'] . '</div>';
			}
		}else{
			$post_coupon_times = '';
		    $x = $x + 1;
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupontype.len'] . '</div>';
	}
	
	
	// Coupon Expire | Count 5
	if($post_coupon_expire != '' && $post_coupon_expire != ' '){
		if(strlen($post_coupon_expire) < 11){
			$post_coupon_expire_copy = strip_tags($post_coupon_expire);
			$post_coupon_expire_copy = stripslashes($post_coupon_expire_copy);
			if($post_coupon_expire == $post_coupon_expire_copy){
				$post_coupon_expire_copy = preg_replace('#[^0-9.]#i', '', $post_coupon_expire_copy);
				if(strlen($post_coupon_expire_copy) == 8){
					if(ctype_digit($post_coupon_expire_copy)){
						$post_coupon_expire = str_replace('/', '-', $post_coupon_expire);
						$x = $x + 1;
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.char'] . '</div>';
					}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.char'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.len'] . '</div>';
		}
	}else{
		$post_coupon_expire = '';
		$x = $x + 1;
	}
	
	
	// Coupon Discount | Count 6
	if($post_coupon_status == '1' || $post_coupon_status == '0'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponstatus.wrong'] . '</div>';
	}
	
	
	// Add Coupon
	if($x == 6){
		$sql_newCoupon = "UPDATE pc_coupons SET coupon_code='$post_coupon_code', coupon_type='$post_coupon_type', coupon_discount='$post_coupon_discount', coupon_times='$post_coupon_times', coupon_status='$post_coupon_status', coupon_expire='$post_coupon_expire', coupon_update=now() WHERE coupon_ID='$coupon_ID' LIMIT 1";
		$query_newCoupon = $mysqli->query($sql_newCoupon);
		if($query_newCoupon === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcoupon.alert.crash'] . '</div>';
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/coupons-editCoupon?id=" . $coupon_ID . "&update=success");
			exit();
		}
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}
			// END UPDATE COUPON
		}else{
			header("location:  " . $GLOBALS['url']. "/control_panel/coupons");
	        exit();	
		}
	}
}else{
	header("location:  " . $GLOBALS['url']. "/control_panel/coupons");
	exit();	
}


// STATUS UPDATE
if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcoupon.alert.update.success'] . '</div>';
	}
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.editcoupon.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<!-- START DELETE PRODUCT MODAL -->
<div class="modal fade" id="deleteCoupon" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.button.deletecoupon']; ?></h4>
            </div>
            <div class="modal-body">
                <p><?php echo $lang['alert.editcoupon.remove.confirm']; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <a href="<?php echo $GLOBALS['url']; ?>/control_panel/coupons-editCoupon?id=<?php echo $coupon_ID; ?>&action=delete"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletecoupon']; ?></button></a>
            </div>
        </div>
    </div>
</div>
<!-- END DELETE PRODUCT MODAL -->
<div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.editcoupon.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
             <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/coupons"><i class="fa fa-tag"></i>&nbsp;&nbsp;<?php echo $lang['admin.coupons.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $coupon_code; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/coupons-editCoupon?id=<?php echo $coupon_ID; ?>" method="post">
            <div class="row">
                <div class="col-md-8">
		    <div class="panel panel-default">
                <div class="panel-heading heading-white">
                <h3 class="panel-title"><i class="fa fa-tag"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.editcoupon.title']; ?></b></h3>
                </div>
                <div class="panel-body">
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.couponname']; ?></label>
						<input type="text" class="form-control" name="coupon_code" maxlength="255" autocomplete="off" value="<?php echo $coupon_code; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.type']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.coupontype']; ?>"></i></label>
						<select name="coupon_type" class="form-control">
                            <?php echo $coupon_type; ?>
                            <option value="p"><?php echo $lang['admin.form.select.option.percent']; ?></option>
                            <option value="a"><?php echo $lang['admin.form.select.option.amount']; ?></option>
                        </select>
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.discount']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.coupondiscount']; ?>"></i></label>
						<input type="text" class="form-control" name="coupon_discount" maxlength="20" autocomplete="off" value="<?php echo $coupon_discount; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.times']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.coupontimes']; ?>"></i></label>
						<input type="text" class="form-control" name="coupon_times" maxlength="20" autocomplete="off" value="<?php echo $coupon_times; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.dateexpire']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.couponexpire']; ?>"></i></label>
						<input type="date" class="form-control" name="coupon_expire" value="<?php echo $coupon_expire; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.status']; ?></label>
						<select name="coupon_status" class="form-control">
                            <?php echo $coupon_status; ?>
                            <option value="1"><?php echo $lang['admin.form.select.option.public']; ?></option>
                            <option value="0"><?php echo $lang['admin.form.select.option.unpublished']; ?></option>
                        </select>
					</div>
                </div>
            </div>
            
                </div>
                <div class="col-md-4">
                    <!-- START STATISTICS -->
                    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
					        <h3 class="panel-title"><i class="fa fa-signal"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.editcoupon.text.couponstatistics']; ?></b></h3>
					    </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label><?php echo $lang['admin.table.th.used']; ?></label>
                                <br>
                                <?php echo $coupon_used; ?>
                            </div>
                            <?php echo $coupon_update; ?>
                            <div class="form-group">
                                <label><?php echo $lang['admin.table.th.date']; ?></label>
                                <br>
                                <?php echo $coupon_date; ?>
                            </div>
                        </div>
                    </div>
                    <!-- END STATISTICS -->
                </div>
            </div>
            <button type="submit" class="btn <?php echo $admin_theme_btn; ?>" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
            <a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteCoupon"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletecoupon']; ?></a>
            <br>
            <br>
        </form>
	    <?php include_once("tmp/footer.php"); ?>
	</div>    
</div>					
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>