<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// VARIABLES
$post_coupon_code = '';
$post_coupon_type = '';
$post_coupon_discount = '';
$post_coupon_times = '';
$post_coupon_expire = '';
$post_coupon_status = '';
if(isset($_POST['coupon_code'])){
	if($admin_power != 'viewer'){
	$x = 0;
	$post_coupon_code = $_POST['coupon_code'];
    $post_coupon_type = $_POST['coupon_type'];
    $post_coupon_discount = $_POST['coupon_discount'];
    $post_coupon_times = $_POST['coupon_times'];
	$post_coupon_expire = $_POST['coupon_expire'];
    $post_coupon_status = $_POST['coupon_status'];
	
	// Coupon Code | Count 1
	if($post_coupon_code != '' && $post_coupon_code != ' '){
		if(strlen($post_coupon_code) < 51){
			$post_coupon_code_copy = preg_replace('#[^A-Za-z0-9]#', '', $post_coupon_code);
			$post_coupon_code_copy = stripslashes($post_coupon_code_copy);
			if($post_coupon_code == $post_coupon_code_copy){
				$post_coupon_code_copy = $mysqli->real_escape_string($post_coupon_code_copy);
				$coupon_check = false;
				$sql_checkCode = "SELECT coupon_ID FROM pc_coupons WHERE coupon_code='$post_coupon_code_copy'";
				$query_checkCode = $mysqli->query($sql_checkCode);
				if($query_checkCode === FALSE){
					$coupon_check = false;
				}else{
					$count_checkCode = $query_checkCode->num_rows;
					if($count_checkCode > 0){
						$coupon_check = true;
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.taken'] . '</div>';
					}else{
					    $coupon_check = false;	
					}
				}
				if($coupon_check == false){
					$post_coupon_code = $mysqli->real_escape_string($post_coupon_code);
					$x = $x + 1;
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.taken'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponcode.empty'] . '</div>';
	}
	
	
	// Coupon Type | Count 2
	if($post_coupon_type == 'a' || $post_coupon_type == 'p'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupontype.wrong'] . '</div>';
	}
	
	
	// Coupon Discount | Count 3
	if($post_coupon_discount != '' && $post_coupon_discount != ' '){
		if(strlen($post_coupon_discount) < 21){
			$post_coupon_discount_copy = preg_replace('#[^0-9.]#i', '', $post_coupon_discount);
			if($post_coupon_discount == $post_coupon_discount_copy){
				$post_coupon_discount = $mysqli->real_escape_string($post_coupon_discount);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupondiscount.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupondiscount.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupondiscount.empty'] . '</div>';
	}
	
	
	// Coupon Discount | Count 4
	if(strlen($post_coupon_times) < 21){
		if($post_coupon_times != '' && $post_coupon_times != ' '){
			if(ctype_digit($post_coupon_times)){
				$post_coupon_times = $mysqli->real_escape_string($post_coupon_times);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupontype.char'] . '</div>';
			}
		}else{
			$post_coupon_times = '';
		    $x = $x + 1;
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.coupontype.len'] . '</div>';
	}
	
	
	// Coupon Expire | Count 5
	if($post_coupon_expire != '' && $post_coupon_expire != ' '){
		if(strlen($post_coupon_expire) < 11){
			$post_coupon_expire_copy = strip_tags($post_coupon_expire);
			$post_coupon_expire_copy = stripslashes($post_coupon_expire_copy);
			if($post_coupon_expire == $post_coupon_expire_copy){
				$post_coupon_expire_copy = preg_replace('#[^0-9.]#i', '', $post_coupon_expire_copy);
				if(strlen($post_coupon_expire_copy) == 8){
					if(ctype_digit($post_coupon_expire_copy)){
						$post_coupon_expire = str_replace('/', '-', $post_coupon_expire);
						$x = $x + 1;
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.char'] . '</div>';
					}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.char'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.char'] . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponexpire.len'] . '</div>';
		}
	}else{
		$post_coupon_expire = '';
		$x = $x + 1;
	}
	
	
	// Coupon Discount | Count 6
	if($post_coupon_status == '1' || $post_coupon_status == '0'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcoupon.alert.couponstatus.wrong'] . '</div>';
	}
	
	
	// Add Coupon
	if($x == 6){
		$sql_newCoupon = "INSERT INTO pc_coupons(coupon_code, coupon_type, coupon_discount, coupon_times, coupon_status, coupon_expire, coupon_date) VALUES('$post_coupon_code','$post_coupon_type','$post_coupon_discount','$post_coupon_times','$post_coupon_status','$post_coupon_expire',now())";
		$query_newCoupon = $mysqli->query($sql_newCoupon);
		if($query_newCoupon === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.newcoupon.alert.crash'] . '</div>';
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/coupons?status=success");
			exit();
		}
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}

?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.newcoupon.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.newcoupon.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
             <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/coupons"><i class="fa fa-tag"></i>&nbsp;&nbsp;<?php echo $lang['admin.coupons.title']; ?></a></li>
            <li class="active"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.newcoupon.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/coupons-newCoupon" method="post">
            <div class="row">
                <div class="col-md-12">
		    <div class="panel panel-default">
                <div class="panel-heading heading-white">
                <h3 class="panel-title"><i class="fa fa-tag"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newcoupon.title']; ?></b></h3>
                </div>
                <div class="panel-body">
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.couponname']; ?></label>
						<input type="text" class="form-control" name="coupon_code" maxlength="255" autocomplete="off" value="<?php echo $post_coupon_code; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.type']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.coupontype']; ?>"></i></label>
						<select name="coupon_type" class="form-control">
                            <option value="p"><?php echo $lang['admin.form.select.option.percent']; ?></option>
                            <option value="a"><?php echo $lang['admin.form.select.option.amount']; ?></option>
                        </select>
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.discount']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.coupondiscount']; ?>"></i></label>
						<input type="text" class="form-control" name="coupon_discount" maxlength="20" autocomplete="off" value="<?php echo $post_coupon_discount; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.times']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.coupontimes']; ?>"></i></label>
						<input type="text" class="form-control" name="coupon_times" maxlength="20" autocomplete="off" value="<?php echo $post_coupon_times; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.dateexpire']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.couponexpire']; ?>"></i></label>
						<input type="date" class="form-control" name="coupon_expire" value="<?php echo $post_coupon_expire; ?>">  
					</div>
                    <div class="form-group">
						<label><?php echo $lang['admin.form.label.status']; ?></label>
						<select name="coupon_status" class="form-control">
                            <option value="1"><?php echo $lang['admin.form.select.option.public']; ?></option>
                            <option value="0"><?php echo $lang['admin.form.select.option.unpublished']; ?></option>
                        </select>
					</div>
                </div>
            </div>
            <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.addcoupon']; ?></button>
            <br>
            <br>
                </div>
            </div>
        </form>
	    <?php include_once("tmp/footer.php"); ?>
	</div>    
</div>					
<?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>