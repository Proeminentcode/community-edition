<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
    header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


$block_ID = '';
$page_content = '';


$V_block_title = '';
$V_block_show = '';
$V_block_type = '';
$V_block_var_1 = '';
$V_block_var_2 = '';
$V_block_var_3 = '';
$V_block_var_4 = '';
$V_block_var_5 = '';
$V_block_content = '';
$V_block_status = '';
$V_block_update = '';
$V_block_date = '';
$type = $_GET['type'];
if($type != 'textHTML' && $type != 'posts' &&  $type != 'products' &&  $type != 'categories' &&  $type != 'brands' &&  $type != 'contactForm'){
	header("location: " . $GLOBALS['url'] . "/control_panel/blocks");
	exit();	
}


if(isset($_GET['id'])){	
	$block_ID = $_GET['id'];
	$block_ID = preg_replace('#[^0-9]#i', '', $block_ID);
	$sql_blockInfo = "SELECT * FROM pc_pages_blocks WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1";
	$query_blockInfo = $mysqli->query($sql_blockInfo);
	if($query_blockInfo === FALSE){
		header("location: " . $GLOBALS['url'] . "/control_panel/blocks");
	    exit();	
	}else{
		$count_blockInfo = $query_blockInfo->num_rows;
		$V_block_title = '';
		if($count_blockInfo > 0){
			// DELETE BLOCK
			if(isset($_GET['remove']) == 'yes'){
				    if($admin_power != 'viewer'){
					    $sql_blockRemove = "DELETE FROM pc_pages_blocks WHERE block_ID='$block_ID' LIMIT 1";
					    $query_blockRemove = $mysqli->query($sql_blockRemove);
					    if($query_blockRemove === FALSE){
						    $message = '<div class="alert alert-danger" role="alert">' . $lang['alert.editblock.alert.remove.crash'] . '</div>';
					    }else{
						    header("location: " . $GLOBALS['url'] . "/control_panel/blocks?status=deleted");
	                        exit();	
					    }
				    }else{
		                $message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
	                }
			    
			}
			$row_blockInfo = $query_blockInfo->fetch_assoc();
			// Get Values
			$V_block_title = $row_blockInfo['block_title'];
            $V_block_show = $row_blockInfo['block_show'];
			if($V_block_show == 1){
				$V_block_show = ' checked';
			}else{
			    $V_block_show = '';	
			}
            $V_block_type = $row_blockInfo['block_type'];
            $V_block_var_1 = $row_blockInfo['block_var_1'];
            $V_block_var_2 = $row_blockInfo['block_var_2'];
            $V_block_var_3 = $row_blockInfo['block_var_3'];
            $V_block_var_4 = $row_blockInfo['block_var_4'];
            $V_block_var_5 = $row_blockInfo['block_var_5'];
            $V_block_content = $row_blockInfo['block_content'];
			// Decrypt Site Url
			$V_block_content = pc_dynamic_site_url_decrypt($V_block_content);
			$content_insurance = $V_block_content;
            $V_block_status = $row_blockInfo['block_status'];
			if($V_block_status == 1){
				$V_block_status = '<option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>';
			}else{
				$V_block_status = '<option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>';
			}
            $V_block_update = $row_blockInfo['block_update'];
            $V_block_date = $row_blockInfo['block_date'];
			if($type == 'textHTML'){	
	            // Text/HTML
	            $block_type = $lang['admin.blocks.text.texthtml'];
	
	            // Post Variable
	            $block_textHTML_title = '';
	            $block_textHTML_show = '';
	            $block_textHTML_content = '';
	            $block_textHTML_status = '';
	
	            // Post Block
	            if(isset($_POST['block_textHTML_title'])){
		            if($admin_power != 'viewer'){
		            // Variables
		            $block_textHTML_title = $_POST['block_textHTML_title'];
		            // Show Title
		            if(isset($_POST['block_textHTML_show']) != ''){
		                $block_textHTML_show = 1;	
		            }else{
			            $block_textHTML_show = 0;
		            }
	                $block_textHTML_content = $_POST['block_textHTML_content'];
	                $block_textHTML_status = $_POST['block_textHTML_status'];
		
		            $x = 0;
		
		            // Title | Count 1
		            if($block_textHTML_title != '' && $block_textHTML_title != ' '){
			if(strlen($block_textHTML_title) < 101){
				$block_textHTML_title = htmlentities($block_textHTML_title, ENT_QUOTES); 
				$block_textHTML_title = $mysqli->real_escape_string($block_textHTML_title);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.empty']  . '</div>';
		}
		
		            // Content | Count 2
		            if($x == 1){
			if(strlen($block_textHTML_content) <= 4294967295){
                $x = $x + 1;
			}else{
				$block_textHTML_content = '';
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.content.len'] . '</div>';
			}
		}
		
		            // Status | Count 3
		            if($block_textHTML_status == 1 || $block_textHTML_status == 0){
			$x = $x + 1;
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.status.wrong'] . '</div>';
		}
		
		            // Final
		            if($x == 3){
			
			            // Insurance for Content
			            if($block_textHTML_content == '' || $block_textHTML_content == ' '){
			    $block_textHTML_content = $content_insurance;
				$block_textHTML_content = $mysqli->real_escape_string($block_textHTML_content);
		    }else{
				$block_textHTML_content = htmlentities($block_textHTML_content, ENT_QUOTES);
				$block_textHTML_content = $mysqli->real_escape_string($block_textHTML_content);
			}
			
			
			// Crypt Site Url
			$block_textHTML_content = pc_dynamic_site_url_crypt($block_textHTML_content);
			
			
			            // Add Block
			            $sql_block_textHTML = "UPDATE pc_pages_blocks SET block_title='$block_textHTML_title', block_show='$block_textHTML_show', block_content='$block_textHTML_content', block_status='$block_textHTML_status', block_update=now() WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1";
			            $query_block_textHTML = $mysqli->query($sql_block_textHTML);
			            if($query_block_textHTML === FALSE){
				            $message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editblock.textHTML.alert.update.crash'] . '</div>';
							// Decrypt Site Url
			                $block_textHTML_content = pc_dynamic_site_url_decrypt($block_textHTML_content);
			            }else{
				            header("location: " . $GLOBALS['url'] . "/control_panel/blocks-editBlock?id=" . $block_ID . "&type=textHTML&update=success");
			                exit();
			            }
		            }
					}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
	            }	
	
	
	            // Page Content
				$page_content = '
				    <form action="' . $GLOBALS['url']. '/control_panel/blocks-editBlock?id=' . $block_ID . '&type=textHTML" method="post">
				    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
				            <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b>' . $block_type . '</b></h3>
			            </div>
                        <div class="panel-body">
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.blocktitle'] . '</label>
							    <input type="text" name="block_textHTML_title" class="form-control" maxlength="100" placeholder="" value="' . $V_block_title . '" autocomplete="off">
						    </div>  
							<div class="form-group">
							    <label for="rememberme" style="font-weight: normal;">
								    <input name="block_textHTML_show" type="checkbox" value="show" ' . $V_block_show . '>&nbsp;&nbsp;' . $lang['admin.form.label.showtitle'] . '
								</label>
								<br>
								<br>
						    </div>
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.content'] . '</label>
							    <textarea id="descriptioneditor" class="form-control" name="block_textHTML_content" rows="15" style="resize: none;" placeholder=""></textarea>
								<br>
						    </div>
					        <div class="form-group">
						        <label>' . $lang['admin.form.label.status'] . '</label>
							    <select name="block_textHTML_status" class="form-control">
								    ' . $V_block_status . '
                                    <option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>
                                </select>
					        </div>   
			            </div>
		            </div>
					<button type="submit" class="btn ' . $admin_theme_btn . '" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.button.savechanges'] . '</button>
					<a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBlock"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblock'] . '</a>
                    <br>
                    <br>
					</form>
				';
            }else if($type == 'posts'){
				// Posts
	            $block_type = $lang['admin.blocks.text.posts'];
				
				// Show Thumbnails
				if($V_block_var_1 == 1){
					$V_block_var_1 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_1 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				// Show Info
				if($V_block_var_2 == 1){
					$V_block_var_2 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_2 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}	
				// Order By
				if($V_block_var_4 == 'titleAsc'){
				    $V_block_var_4 = '<option value="titleAsc">' . $lang['admin.form.select.option.titleascending'] . '</option>';
			    }else if($V_block_var_4 == 'titleDesc'){
				    $V_block_var_4 = '<option value="titleDesc">' . $lang['admin.form.select.option.titledescending'] . '</option>';
			    }else if($V_block_var_4 == 'viewsAsc'){
				    $V_block_var_4 = '<option value="viewsAsc">' . $lang['admin.form.select.option.viewsascending'] . '</option>';
			    }else if($V_block_var_4 == 'viewsDesc'){
				    $V_block_var_4 = '<option value="viewsDesc">' . $lang['admin.form.select.option.viewsdescending'] . '</option>';
			    }else if($V_block_var_4 == 'addedAsc'){
				    $V_block_var_4 = '<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] . '</option>';
			    }else if($V_block_var_4 == 'addedDesc'){
				    $V_block_var_4 = '<option value="addedDesc">' . $lang['admin.form.select.option.addeddescending'] . '</option>';
			    }else if($V_block_var_4 == 'rand'){
				    $V_block_var_4 = '<option value="rand">' . $lang['admin.form.select.option.random'] . '</option>';
			    }else{
			 	    $V_block_var_4 = '';
			    }                
				// Show Pagination
				if($V_block_var_5 == 1){
					$V_block_var_5 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_5 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				
					
	            
	
	// Post Variable
	$block_posts_title = '';
	$block_posts_show = '';
	$block_posts_thumb = '';
	$block_posts_info = '';
	$block_posts_number = '';
	$block_posts_orderby = '';
	$block_posts_pagination = '';
	$block_posts_status = '';
	
	// Post Block
	if(isset($_POST['block_posts_title'])){
		if($admin_power != 'viewer'){
		// Variables
		$block_posts_title = $_POST['block_posts_title'];
		// Show Title
		if(isset($_POST['block_posts_show']) != ''){
		    $block_posts_show = 1;	
		}else{
			$block_posts_show = 0;
		}
	    $block_posts_thumb = $_POST['block_posts_thumb'];
	    $block_posts_info = $_POST['block_posts_info'];
		$block_posts_number = $_POST['block_posts_number'];
	    $block_posts_orderby = $_POST['block_posts_orderby'];
		$block_posts_pagination = $_POST['block_posts_pagination'];
	    $block_posts_status = $_POST['block_posts_status'];
		
		$x = 0;
		
		
		// Title | Count 1
		if($block_posts_title != '' && $block_posts_title != ' '){
			if(strlen($block_posts_title) < 101){
				$block_posts_title = htmlentities($block_posts_title, ENT_QUOTES); 
				$block_posts_title = $mysqli->real_escape_string($block_posts_title);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.empty']  . '</div>';
		}
		
		
		// Thumbnails | Count 2
		if($x == 1){
			if($block_posts_thumb == 1 || $block_posts_thumb == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.thumb.status']  . '</div>';
			}
		}
		
		
		// Show Info | Count 3
		if($x == 2){
			if($block_posts_info == 1 || $block_posts_info == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.info.status']  . '</div>';
			}
		}
		
		
		// Number | Count 4
		if($x == 3){
			if($block_posts_number != '' && $block_posts_number != ' '){
				$block_posts_number_copy = preg_replace('#[^0-9]#i', '', $block_posts_number); 
				if($block_posts_number == $block_posts_number_copy){
					if(strlen($block_posts_number) < 8){
						$block_posts_number = preg_replace('#[^0-9]#i', '', $block_posts_number);
				        $x = $x + 1;
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.number.len']  . '</div>';
					}
			    }else{
				    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.number.wrong']  . '</div>';
			    }
			}else{
				$block_posts_number = '';
				$x = $x + 1;
			}
		}
		
		
		// Order By | Count 5
		if($x == 4){
		    if($block_posts_orderby == 'titleAsc'){
				$x = $x + 1;
			}else if($block_posts_orderby == 'titleDesc'){
				$x = $x + 1;
			}else if($block_posts_orderby == 'viewsAsc'){
				$x = $x + 1;
			}else if($block_posts_orderby == 'viewsDesc'){
				$x = $x + 1;
			}else if($block_posts_orderby == 'addedAsc'){
				$x = $x + 1;
			}else if($block_posts_orderby == 'addedDesc'){
				$x = $x + 1;
			}else if($block_posts_orderby == 'rand'){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.orderby.wrong']  . '</div>';
			}
		}
		
		
		// Pagination | Count 6
		if($x == 5){
			if($block_posts_pagination == 1 || $block_posts_pagination == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.pagination.status']  . '</div>';
			}
		}
		
		
		// Status | Count 7
		if($x == 6){
			if($block_posts_status == 1 || $block_posts_status == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.status.wrong']  . '</div>';
			}
		}
		
		
		// Final
		if($x == 7){
			// Update Block
			
			$sql_block_posts = "UPDATE pc_pages_blocks SET block_title='$block_posts_title', block_show='$block_posts_show', block_var_1='$block_posts_thumb', block_var_2='$block_posts_info', block_var_3='$block_posts_number', block_var_4='$block_posts_orderby', block_var_5='$block_posts_pagination', block_status='$block_posts_status', block_update=now() WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1";
			$query_block_posts = $mysqli->query($sql_block_posts);
			if($query_block_posts === FALSE){
				$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editblock.textHTML.alert.update.crash'] . '</div>';
			}else{
				header("location: " . $GLOBALS['url'] . "/control_panel/blocks-editBlock?id=" . $block_ID . "&type=posts&update=success");
			    exit();
			}
		}
		}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
	}
	
	            
				// Page Content
				$page_content = '
				    <form action="' . $GLOBALS['url']. '/control_panel/blocks-editBlock?id=' . $block_ID . '&type=posts" method="post">
				    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
				            <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b>' . $block_type . '</b></h3>
			            </div>
                        <div class="panel-body">
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.blocktitle'] . '</label>
							    <input type="text" name="block_posts_title" class="form-control" maxlength="100" placeholder="" value="' . $V_block_title . '" autocomplete="off">
						    </div>  
							<div class="form-group">
							    <label for="rememberme" style="font-weight: normal;">
								<input name="block_posts_show" type="checkbox" value="show" ' . $V_block_show . '>&nbsp;&nbsp;' . $lang['admin.form.label.showtitle'] . '
								</label>
								<br>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showthumbnails'] . '</label>
							     <select name="block_posts_thumb" class="form-control">
								    ' . $V_block_var_1 . '
								    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                </select>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showinfo'] . '</label>
							     <select name="block_posts_info" class="form-control">
								    ' . $V_block_var_2 . '
								    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                </select>
								<br>
						    </div>
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.postsnumber'] . '&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="' . $lang['admin.form.placeholder.blocks.posts.number'] . '"></i></label>
							    <input type="text" name="block_posts_number" class="form-control" maxlength="7" placeholder="" value="' . $V_block_var_3 . '" autocomplete="off">
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.orderby'] . '</label>
							    <select name="block_posts_orderby" class="form-control">
								    ' . $V_block_var_4 . '
                                    <option value="titleAsc">' . $lang['admin.form.select.option.titleascending'] . '</option>
                                    <option value="titleDesc">' . $lang['admin.form.select.option.titledescending'] . '</option>
                                    <option value="viewsAsc">' . $lang['admin.form.select.option.viewsascending'] . '</option>
                                    <option value="viewsDesc">' . $lang['admin.form.select.option.viewsdescending'] . '</option>
                                    <option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] . '</option>
                                    <option value="addedDesc">' . $lang['admin.form.select.option.addeddescending'] . '</option>
                                    <option value="rand">' . $lang['admin.form.select.option.random'] . '</option>
                                </select>
								<br>
						    </div>
							<input type="hidden" name="block_posts_pagination" value="0">
					        <div class="form-group">
						        <label>' . $lang['admin.form.label.status'] . '</label>
							    <select name="block_posts_status" class="form-control">
								    ' . $V_block_status . '
                                    <option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>
                                </select>
					        </div>   
			            </div>
		            </div>
					<button type="submit" class="btn ' . $admin_theme_btn . '" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.button.savechanges'] . '</button>
					<a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBlock"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblock'] . '</a>
                    <br>
                    <br>
					</form>
				';
            }else if($type == 'products'){	
	            // Products
	            $block_type = $lang['admin.blocks.text.products'];
				
				
				// Show Thumbnails
				if($V_block_var_1 == 1){
					$V_block_var_1 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_1 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				// Order By
				if($V_block_var_3 == 'nameAsc'){
				    $V_block_var_3 = '<option value="nameAsc">' . $lang['admin.form.select.option.nameascending'] . '</option>';
			    }else if($V_block_var_3 == 'nameDesc'){
				    $V_block_var_3 = '<option value="nameDesc">' . $lang['admin.form.select.option.namedescending'] . '</option>';
			    }else if($V_block_var_3 == 'priceAsc'){
				    $V_block_var_3 = '<option value="priceAsc">' . $lang['admin.form.select.option.priceascending'] . '</option>';
			    }else if($V_block_var_3 == 'priceDesc'){
				    $V_block_var_3 = '<option value="priceDesc">' . $lang['admin.form.select.option.pricedescending'] . '</option>';
			    }else if($V_block_var_3 == 'addedAsc'){
				    $V_block_var_3 = '<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] .'</option>';
			    }else if($V_block_var_3 == 'addedDesc'){
				    $V_block_var_3 = '<option value="addedDesc">' . $lang['admin.form.select.option.addedescending'] .'</option>';
			    }else if($V_block_var_3 == 'rand'){
				    $V_block_var_3 = '<option value="rand">' . $lang['admin.form.select.option.random'] .'</option>';
			    }else{
				    $V_block_var_3 = '';
			    }                
				// Show Pagination
				if($V_block_var_4 == 1){
					$V_block_var_4 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_4 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				
	
	            // Post Variable
	            $block_products_title = '';
	$block_products_show = '';
	$block_products_thumb = '';
	$block_products_number = '';
	$block_products_orderby = '';
	$block_products_pagination = '';
	$block_products_status = '';
	
	            // Post Block
	            if(isset($_POST['block_products_title'])){
		if($admin_power != 'viewer'){
		// Variables
		$block_products_title = $_POST['block_products_title'];
		// Show Title
		if(isset($_POST['block_products_show']) != ''){
		    $block_products_show = 1;	
		}else{
			$block_products_show = 0;
		}
	    $block_products_thumb = $_POST['block_products_thumb'];
	    $block_products_number = $_POST['block_products_number'];
		$block_products_orderby = $_POST['block_products_orderby'];
	    $block_products_pagination = $_POST['block_products_pagination'];
	    $block_products_status = $_POST['block_products_status'];
		
		$x = 0;
		
		// Title | Count 1
		if($block_products_title != '' && $block_products_title != ' '){
			if(strlen($block_products_title) < 101){
				$block_products_title = htmlentities($block_products_title, ENT_QUOTES); 
				$block_products_title = $mysqli->real_escape_string($block_products_title);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.empty']  . '</div>';
		}
		
		
		// Thumbnails | Count 2
		if($x == 1){
			if($block_products_thumb == 1 || $block_products_thumb == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.thumb.status']  . '</div>';
			}
		}
		
		
		// Order By | Count 3
		if($x == 2){
		    if($block_products_orderby == 'nameAsc'){
				$x = $x + 1;
			}else if($block_products_orderby == 'nameDesc'){
				$x = $x + 1;
			}else if($block_products_orderby == 'priceAsc'){
				$x = $x + 1;
			}else if($block_products_orderby == 'priceDesc'){
				$x = $x + 1;
			}else if($block_products_orderby == 'addedAsc'){
				$x = $x + 1;
			}else if($block_products_orderby == 'addedDesc'){
				$x = $x + 1;
			}else if($block_products_orderby == 'rand'){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.orderby.wrong']  . '</div>';
			}
		}
		
		
		// Pagination | Count 4
		if($x == 3){
			if($block_products_pagination == 1 || $block_products_pagination == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.pagination.status']  . '</div>';
			}
		}
		
		
		// Status | Count 5
		if($x == 4){
			if($block_products_status == 1 || $block_products_status == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.status.wrong']  . '</div>';
			}
		}
		
		
		// Final
		if($x == 5){
			// Update Block
			$sql_block_posts = "UPDATE pc_pages_blocks SET block_title='$block_products_title', block_show='$block_products_show', block_var_1='$block_products_thumb', block_var_2='$block_products_number', block_var_3='$block_products_orderby', block_var_4='$block_products_pagination', block_status='$block_products_status', block_update=now() WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1";
			$query_block_posts = $mysqli->query($sql_block_posts);
			if($query_block_posts === FALSE){
				$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editblock.textHTML.alert.update.crash'] . '</div>';
			}else{
				header("location: " . $GLOBALS['url'] . "/control_panel/blocks-editBlock?id=" . $block_ID . "&type=products&update=success");
			    exit();
			}
		}
		}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
	}	
	
	            // Page Content
	            $page_content = '
				    <form action="' . $GLOBALS['url']. '/control_panel/blocks-editBlock?id=' . $block_ID . '&type=products" method="post">
				    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
				            <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b>' . $block_type . '</b></h3>
			            </div>
                        <div class="panel-body">
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.blocktitle'] . '</label>
							    <input type="text" name="block_products_title" class="form-control" maxlength="100" placeholder="" value="' . $V_block_title . '" autocomplete="off">
						    </div>  
							<div class="form-group">
							    <label for="rememberme" style="font-weight: normal;">
								<input name="block_products_show" type="checkbox" value="show" ' . $block_products_show . '>&nbsp;&nbsp;' . $lang['admin.form.label.showtitle'] . '
								</label>
								<br>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showthumbnails'] . '</label>
							     <select name="block_products_thumb" class="form-control">
								    ' . $V_block_var_1 . '
								    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                </select>
								<br>
						    </div>
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.productsnumber'] . '&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="' . $lang['admin.form.tooltip.block.productsnum'] . '"></i></label>
							    <input type="text" name="block_products_number" class="form-control" maxlength="7" placeholder="" value="' . $V_block_var_2 . '" autocomplete="off">
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.orderby'] . '</label>
							    <select name="block_products_orderby" class="form-control">
								    ' . $V_block_var_3 . '
                                    <option value="nameAsc">' . $lang['admin.form.select.option.nameascending'] . '</option>
                                    <option value="nameDesc">' . $lang['admin.form.select.option.namedescending'] . '</option>
                                    <option value="priceAsc">' . $lang['admin.form.select.option.priceascending'] . '</option>
                                    <option value="priceDesc">' . $lang['admin.form.select.option.pricedescending'] . '</option>
									<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] .'</option>
                                    <option value="addedDesc">' . $lang['admin.form.select.option.addedescending'] .'</option>               
                                    <option value="rand">' . $lang['admin.form.select.option.random'] .'</option>
                                </select>
								<br>
						    </div>
							<input type="hidden" name="block_products_pagination" value="0">
					        <div class="form-group">
						        <label>' . $lang['admin.form.label.status'] . '</label>
							    <select name="block_products_status" class="form-control">
								    ' . $V_block_status . '
                                    <option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>
                                </select>
					        </div>   
			            </div>
		            </div>
					<button type="submit" class="btn ' . $admin_theme_btn . '" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.button.savechanges'] . '</button>
					<a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBlock"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblock'] . '</a>
                    <br>
                    <br>
					</form>
				';
            }else if($type == 'categories'){
				// Categories
	            $block_type = $lang['admin.blocks.text.categories'];
				// Show Thumbnails
				if($V_block_var_1 == 1){
					$V_block_var_1 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_1 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				// Order By
				if($V_block_var_2 == 'nameAsc'){
				     $V_block_var_2 = '<option value="nameAsc">' . $lang['admin.form.select.option.nameascending'] . '</option>';
			     }else if($V_block_var_2 == 'nameDesc'){
				     $V_block_var_2 = '<option value="nameDesc">' . $lang['admin.form.select.option.namedescending'] . '</option>';
			     }else if($V_block_var_2 == 'addedAsc'){
				     $V_block_var_2 = '<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] .'</option>';
			     }else if($V_block_var_2 == 'addedDesc'){
				    $V_block_var_2 = '<option value="addedDesc">' . $lang['admin.form.select.option.addedescending'] .'</option>';
			     }else if($V_block_var_2 == 'rand'){
				    $V_block_var_2 = '<option value="rand">' . $lang['admin.form.select.option.random'] .'</option>';
			     }else{
				     $V_block_var_2 = '';
			    }                
				// Show Count
				if($V_block_var_3 == 1){
					$V_block_var_3 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_3 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				
	            
	
	// Categories Variable
	$block_categories_title = '';
	$block_categories_show = '';
	$block_categories_thumb = '';
	$block_categories_orderby = '';
	$block_categories_count = '';
	$block_categories_status = '';
	
	// Post Block
	if(isset($_POST['block_categories_title'])){
		if($admin_power != 'viewer'){
		// Variables
		$block_categories_title = $_POST['block_categories_title'];
		// Show Title
		if(isset($_POST['block_categories_show']) != ''){
		    $block_categories_show = 1;	
		}else{
			$block_categories_show = 0;
		}
	    $block_categories_thumb = $_POST['block_categories_thumb'];
	    $block_categories_orderby = $_POST['block_categories_orderby'];
		$block_categories_count = $_POST['block_categories_count'];
	    $block_categories_status = $_POST['block_categories_status'];
		
		$x = 0;
		
		// Title | Count 1
		if($block_categories_title != '' && $block_categories_title != ' '){
			if(strlen($block_categories_title) < 101){
				$block_categories_title = htmlentities($block_categories_title, ENT_QUOTES); 
				$block_categories_title = $mysqli->real_escape_string($block_categories_title);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.empty']  . '</div>';
		}
		
		
		// Thumbnails | Count 2
		if($x == 1){
			if($block_categories_thumb == 1 || $block_categories_thumb == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.thumb.status']  . '</div>';
			}
		}
		
		
		// Order By | Count 3
		if($x == 2){
		    if($block_categories_orderby == 'nameAsc'){
				$x = $x + 1;
			}else if($block_categories_orderby == 'nameDesc'){
				$x = $x + 1;
			}else if($block_categories_orderby == 'addedAsc'){
				$x = $x + 1;
			}else if($block_categories_orderby == 'addedDesc'){
				$x = $x + 1;
			}else if($block_categories_orderby == 'rand'){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.orderby.wrong']  . '</div>';
			}
		}
		
		
		// Count | Count 4
		if($x == 3){
			if($block_categories_count == 1 || $block_categories_count == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.pagination.status']  . '</div>';
			}
		}
		
		
		// Status | Count 5
		if($x == 4){
			if($block_categories_status == 1 || $block_categories_status == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.status.wrong']  . '</div>';
			}
		}
		
		
		// Final
		if($x == 5){
			// Update Block
			$sql_block_posts = "UPDATE pc_pages_blocks SET block_title='$block_categories_title', block_show='$block_categories_show', block_var_1='$block_categories_thumb', block_var_2='$block_categories_orderby', block_var_3='$block_categories_count', block_update=now() WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1";
			$query_block_posts = $mysqli->query($sql_block_posts);
			if($query_block_posts === FALSE){
				$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editblock.textHTML.alert.update.crash'] . '</div>';
			}else{
				header("location: " . $GLOBALS['url'] . "/control_panel/blocks-editBlock?id=" . $block_ID . "&type=categories&update=success");
			    exit();
			}
		}
		}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
	}
	
                // Page Content
	            $page_content = '
				    <form action="' . $GLOBALS['url']. '/control_panel/blocks-editBlock?id=' . $block_ID . '&type=categories" method="post">
				    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
				            <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b>' . $block_type . '</b></h3>
			            </div>
                        <div class="panel-body">
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.blocktitle'] . '</label>
							    <input type="text" name="block_categories_title" class="form-control" maxlength="100" placeholder="" value="' . $V_block_title . '" autocomplete="off">
						    </div>  
							<div class="form-group">
							    <label for="rememberme" style="font-weight: normal;">
								<input name="block_categories_show" type="checkbox" value="show" ' . $V_block_show . '>&nbsp;&nbsp;' . $lang['admin.form.label.showtitle'] . '
								</label>
								<br>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showthumbnails'] . '</label>
							     <select name="block_categories_thumb" class="form-control">
								    ' . $V_block_var_1 .'
								    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                </select>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.orderby'] . '</label>
							    <select name="block_categories_orderby" class="form-control">
								    ' . $V_block_var_2 . '
                                    <option value="nameAsc">' . $lang['admin.form.select.option.nameascending'] . '</option>
                                    <option value="nameDesc">' . $lang['admin.form.select.option.namedescending'] . '</option>
									<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] .'</option>
                                    <option value="addedDesc">' . $lang['admin.form.select.option.addedescending'] .'</option>               
                                    <option value="rand">' . $lang['admin.form.select.option.random'] .'</option>
                                </select>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showcategoriescount'] . '</label>
							     <select name="block_categories_count" class="form-control">
								    ' . $V_block_var_3 . '
								    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                </select>
								<br>
						    </div>
					        <div class="form-group">
						        <label>' . $lang['admin.form.label.status'] . '</label>
							    <select name="block_categories_status" class="form-control">
								    ' . $V_block_status . '
                                    <option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>
                                </select>
					        </div>   
			            </div>
		            </div>
					<button type="submit" class="btn ' . $admin_theme_btn . '" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.button.savechanges'] . '</button>
					<a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBlock"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblock'] . '</a>
                    <br>
                    <br>
					</form>
				';	
            }else if($type == 'brands'){
				// Brands
	            $block_type = $lang['admin.blocks.text.brands'];
				// Show Thumbnails
				if($V_block_var_1 == 1){
					$V_block_var_1 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_1 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
				// Order By
				if($V_block_var_2 == 'nameAsc'){
				     $V_block_var_2 = '<option value="nameAsc">' . $lang['admin.form.select.option.nameascending'] . '</option>';
			     }else if($V_block_var_2 == 'nameDesc'){
				     $V_block_var_2 = '<option value="nameDesc">' . $lang['admin.form.select.option.namedescending'] . '</option>';
			     }else if($V_block_var_2 == 'addedAsc'){
				     $V_block_var_2 = '<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] .'</option>';
			     }else if($V_block_var_2 == 'addedDesc'){
				    $V_block_var_2 = '<option value="addedDesc">' . $lang['admin.form.select.option.addedescending'] .'</option>';
			     }else if($V_block_var_2 == 'rand'){
				    $V_block_var_2 = '<option value="rand">' . $lang['admin.form.select.option.random'] .'</option>';
			     }else{
				     $V_block_var_2 = '';
			    }                
				// Show Count
				if($V_block_var_3 == 1){
					$V_block_var_3 = '<option value="1">' . $lang['admin.form.select.option.yes'] . '</option>';
				}else{
					$V_block_var_3 = '<option value="0">' . $lang['admin.form.select.option.no'] . '</option>';
				}
	            
	
	// Brands Variable
	$block_brands_title = '';
	$block_brands_show = '';
	$block_brands_thumb = '';
	$block_brands_orderby = '';
	$block_brands_count = '';
	$block_brands_status = '';
	
	// Post Block
	if(isset($_POST['block_brands_title'])){
		if($admin_power != 'viewer'){
		// Variables
		$block_brands_title = $_POST['block_brands_title'];
		// Show Title
		if(isset($_POST['block_brands_show']) != ''){
		    $block_brands_show = 1;	
		}else{
			$block_brands_show = 0;
		}
	    $block_brands_thumb = $_POST['block_brands_thumb'];
	    $block_brands_orderby = $_POST['block_brands_orderby'];
		$block_brands_count = $_POST['block_brands_count'];
	    $block_brands_status = $_POST['block_brands_status'];
		
		$x = 0;
		
		// Title | Count 1
		if($block_brands_title != '' && $block_brands_title != ' '){
			if(strlen($block_brands_title) < 101){
				$block_brands_title = htmlentities($block_brands_title, ENT_QUOTES); 
				$block_brands_title = $mysqli->real_escape_string($block_brands_title);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.empty']  . '</div>';
		}
		
		
		// Thumbnails | Count 2
		if($x == 1){
			if($block_brands_thumb == 1 || $block_brands_thumb == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.thumb.status']  . '</div>';
			}
		}
		
		
		// Order By | Count 3
		if($x == 2){
		    if($block_brands_orderby == 'nameAsc'){
				$x = $x + 1;
			}else if($block_brands_orderby == 'nameDesc'){
				$x = $x + 1;
			}else if($block_brands_orderby == 'addedAsc'){
				$x = $x + 1;
			}else if($block_brands_orderby == 'addedDesc'){
				$x = $x + 1;
			}else if($block_brands_orderby == 'rand'){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.orderby.wrong']  . '</div>';
			}
		}
		
		
		// Count | Count 4
		if($x == 3){
			if($block_brands_count == 1 || $block_brands_count == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.pagination.status']  . '</div>';
			}
		}
		
		
		// Status | Count 5
		if($x == 4){
			if($block_brands_status == 1 || $block_brands_status == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.status.wrong']  . '</div>';
			}
		}
		
		
		// Final
		if($x == 5){
			// Update Block
			$sql_block_posts = "UPDATE pc_pages_blocks SET block_title='$block_brands_title', block_show='$block_brands_show', block_var_1='$block_brands_thumb', block_var_2='$block_brands_orderby', block_var_3='$block_brands_count', block_status='$block_brands_status', block_update=now() WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1";
			$query_block_posts = $mysqli->query($sql_block_posts);
			if($query_block_posts === FALSE){
				$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editblock.textHTML.alert.update.crash'] . '</div>';
			}else{
				header("location: " . $GLOBALS['url'] . "/control_panel/blocks-editBlock?id=" . $block_ID . "&type=brands&update=success");
			    exit();
			}
		}
		}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
	}
	
	            // Page Content
				$page_content = '
				    <form action="' . $GLOBALS['url']. '/control_panel/blocks-editBlock?id=' . $block_ID . '&type=brands" method="post">
				    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
				            <h3 class="panel-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<b>' . $block_type . '</b></h3>
			            </div>
                        <div class="panel-body">
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.blocktitle'] . '</label>
							    <input type="text" name="block_brands_title" class="form-control" maxlength="100" placeholder="" value="' . $V_block_title . '" autocomplete="off">
						    </div>  
							<div class="form-group">
							    <label for="rememberme" style="font-weight: normal;">
								<input name="block_brands_show" type="checkbox" value="show" ' . $V_block_show . '>&nbsp;&nbsp;' . $lang['admin.form.label.showtitle'] . '
								</label>
								<br>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showthumbnails'] . '</label>
							     <select name="block_brands_thumb" class="form-control">
								    ' . $V_block_var_1 . '
								    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                </select>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.orderby'] . '</label>
							    <select name="block_brands_orderby" class="form-control">
								    ' . $V_block_var_2 . '
                                    <option value="nameAsc">' . $lang['admin.form.select.option.nameascending'] . '</option>
                                    <option value="nameDesc">' . $lang['admin.form.select.option.namedescending'] . '</option>
									<option value="addedAsc">' . $lang['admin.form.select.option.addedascending'] .'</option>
                                    <option value="addedDesc">' . $lang['admin.form.select.option.addedescending'] .'</option>               
                                    <option value="rand">' . $lang['admin.form.select.option.random'] .'</option>
                                </select>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.showbrandscount'] . '</label>
							     <select name="block_brands_count" class="form-control">
								    ' . $V_block_var_3 . '
								    <option value="0">' . $lang['admin.form.select.option.no'] . '</option>
                                    <option value="1">' . $lang['admin.form.select.option.yes'] . '</option>
                                </select>
								<br>
						    </div>
					        <div class="form-group">    
						        <label>' . $lang['admin.form.label.status'] . '</label>
							    <select name="block_brands_status" class="form-control">
								    ' . $V_block_status . '
                                    <option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>
                                </select>
					        </div>   
			            </div>
		            </div>
					<button type="submit" class="btn ' . $admin_theme_btn . '" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.button.savechanges'] . '</button>
					<a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBlock"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblock'] . '</a>
                    <br>
                    <br>
					</form>
				';
            }else if($type == 'contactForm'){
				// Contact Form
				$block_type = $lang['admin.blocks.text.contactform'];
				
				
				
				
				// Update Block
				// Brands Variable
	$block_contactForm_title = '';
	$block_contactForm_show = '';
	$block_contactForm_receiver = '';
	$block_contactForm_status = '';
	
	             // Post Block
	            if(isset($_POST['block_contactForm_title'])){
					if($admin_power != 'viewer'){
		// Variables
		$block_contactForm_title = $_POST['block_contactForm_title'];
		// Show Title
		if(isset($_POST['block_contactForm_show']) != ''){
		    $block_contactForm_show = 1;	
		}else{
			$block_contactForm_show = 0;
		}
	    $block_contactForm_receiver = $_POST['block_contactForm_receiver'];
	    $block_contactForm_status = $_POST['block_contactForm_status'];
		
		$x = 0;
		
		// Title | Count 1
		if($block_contactForm_title != '' && $block_contactForm_title != ' '){
			if(strlen($block_contactForm_title) < 101){
				$block_contactForm_title = htmlentities($block_contactForm_title, ENT_QUOTES); 
				$block_contactForm_title = $mysqli->real_escape_string($block_contactForm_title);
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.len']  . '</div>';
			}
		}else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.textHTML.alert.title.empty']  . '</div>';
		}
		
		
		// Receiver | Count 2
		if($x == 1){
			if($block_contactForm_receiver != '' && $block_contactForm_receiver != ' '){
				if(strlen($block_contactForm_receiver) < 256){
				    $block_contactForm_receiver = filter_var($block_contactForm_receiver, FILTER_SANITIZE_EMAIL);
		            if(filter_var($block_contactForm_receiver, FILTER_VALIDATE_EMAIL)){
						$x = $x + 1;
						$block_contactForm_receiver = $mysqli->real_escape_string($block_contactForm_receiver);
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.contactform.alert.receiver.wrong'] . '</div>';
					}
			    }else{
				    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.contactform.alert.receiver.len'] . '</div>';
			    }
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.contactform.alert.receiver.empty']  . '</div>';
			}
		}
		
		
		// Status | Count 3
		if($x == 2){
			if($block_contactForm_status == 1 || $block_contactForm_status == 0){
				$x = $x + 1;
			}else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newblock.posts.alert.status.wrong']  . '</div>';
			}
		}
		
		
		// Final
		if($x == 3){
			// Add Block
			$sql_block_contact = "UPDATE pc_pages_blocks SET block_title='$block_contactForm_title', block_show='$block_contactForm_show', block_var_1='$block_contactForm_receiver', block_status='$block_contactForm_status', block_update=now() WHERE block_ID='$block_ID' AND block_type='$type' LIMIT 1 ";
			$query_block_contact = $mysqli->query($sql_block_contact);
			if($query_block_contact === FALSE){
				$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editblock.textHTML.alert.update.crash'] . '</div>';
			}else{
				header("location: " . $GLOBALS['url'] . "/control_panel/blocks-editBlock?id=" . $block_ID . "&type=contactForm&update=success");
			    exit();
			}
		}
		
		}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
	            }		
				
				// Page Content
				$page_content = '
				    <form action="' . $GLOBALS['url']. '/control_panel/blocks-editBlock?id=' . $block_ID . '&type=contactForm" method="post">
				    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
				            <h3 class="panel-title"><i class="fa fa-plus"></i>&nbsp;&nbsp;<b>' . $block_type . '</b></h3>
			            </div>
                        <div class="panel-body">
                            <div class="form-group">
							    <label>' . $lang['admin.form.label.blocktitle'] . '</label>
							    <input type="text" name="block_contactForm_title" class="form-control" maxlength="100" placeholder="" value="' . $V_block_title . '" autocomplete="off">
						    </div>  
							<div class="form-group">
							    <label for="rememberme" style="font-weight: normal;">
								<input name="block_contactForm_show" type="checkbox" value="show" ' . $V_block_show . '>&nbsp;&nbsp;' . $lang['admin.form.label.showtitle'] . '
								</label>
								<br>
								<br>
						    </div>
							<div class="form-group">
							    <label>' . $lang['admin.form.label.receiveremail'] . '&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="' . $lang['admin.form.tooltip.receiveremail'] . '"></i></label>
							    <input type="email" name="block_contactForm_receiver" class="form-control" maxlength="255" placeholder="" value="' . $V_block_var_1 . '" autocomplete="off">
								<br>
						    </div>
					        <div class="form-group">
						        <label>' . $lang['admin.form.label.status'] . '</label>
							    <select name="block_contactForm_status" class="form-control">
								    ' . $V_block_status . '
                                    <option value="1">' . $lang['admin.form.select.option.enabled'] . '</option>
                                    <option value="0">' . $lang['admin.form.select.option.disabled'] . '</option>
                                </select>
					        </div>   
			            </div>
		            </div>
					<button type="submit" class="btn ' . $admin_theme_btn . '" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.button.savechanges'] . '</button>
					<a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBlock"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deleteblock'] . '</a>
                    <br>
                    <br>
					</form>
				';
			}else{
	            header("location:  " . $GLOBALS['url']. "/control_panel/blocks");
	            exit();		
            }
		}else{
			header("location: " . $GLOBALS['url'] . "/control_panel/blocks");
	        exit();	
		}
	}
}else{
	header("location: " . $GLOBALS['url'] . "/control_panel/blocks");
	exit();	
}




// Updates
if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editblock.textHTML.alert.update.success'] . '</div>';
	}
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.editblock.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<!-- START DELETE BLOCK MODAL -->
<div class="modal fade" id="deleteBlock" tabindex="-1" role="dialog">
    <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><?php echo $lang['admin.form.button.deleteblock']; ?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo $lang['admin.editblock.alert.remove.confirm']; ?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
        <a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks-editBlock?id=<?php echo $block_ID; ?>&type=<?php echo $type; ?>&remove=yes"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deleteblock']; ?></button></a>
      </div>
    </div>
  </div>
</div>
<!-- END DELETE BLOCK MODAL -->
<div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.editblock.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url'] ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/blocks"><i class="fa fa-cube"></i>&nbsp;&nbsp;<?php echo $lang['admin.blocks.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $V_block_title; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <?php echo $page_content; ?>
		<?php include_once("tmp/footer.php"); ?>
	</div>    
</div>					
<?php include_once("tmp/tmp-footer-links.php"); ?>
<?php

if($type == 'textHTML'){
	 include_once("include/block-content-js-edit.php");
}

?>
</body>
</html>