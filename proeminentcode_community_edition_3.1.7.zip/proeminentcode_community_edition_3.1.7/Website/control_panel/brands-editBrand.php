<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// VARIABLES
$brand_ID = '';
$brand_name = '';
$brand_url = '';
$brand_content = '';
$brand_thumbnail_image = '';
$brand_thumbnail_source = '';
$brand_banner_image = '';
$brand_banner_source = '';
$brand_sidebar = '';
$brand_sidebar_ID = '';
$brand_status = '';
$brand_update = '';
$brand_date = '';
if(isset($_GET['id'])){
	$brand_ID = $_GET['id'];
	$brand_ID = preg_replace('#[^0-9]#i', '', $brand_ID);
	$sql_brandInfo = "SELECT * FROM pc_products_brands WHERE brand_ID='$brand_ID' LIMIT 1";
	$query_brandInfo = $mysqli->query($sql_brandInfo);
	if($query_brandInfo === FALSE){
		header("location:  " . $GLOBALS['url']. "/control_panel/brands");
	    exit();	
	}else{
		$count_brandInfo = $query_brandInfo->num_rows;
		if($count_brandInfo > 0){
			// START ACTIONS
			$action = '';
			if(isset($_GET['action'])){
				$action = $_GET['action'];
				// START REMOVE THUMB
			    if($action == 'thumbnail'){
				    if($admin_power != 'viewer'){
				        $sql_removeThumb = "UPDATE pc_products_brands SET brand_thumbnail='' WHERE brand_ID='$brand_ID' LIMIT 1";
				        $query_removeThumb = $mysqli->query($sql_removeThumb);
				        if($query_removeThumb === FALSE){
					        $message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editbrand.alert.brandtumbnail.crash'] . '</div>';
				        }else{
					        header("location: " . $GLOBALS['url'] . "/control_panel/brands-editBrand?id=$brand_ID&update=thumb");
					        exit();
				        }
				    }else{
				        $message = '<div class="alert alert-danger" role="alert">' . $lang['admin.settings.alert.shop.power.5'] . '</div>';
			        }
			    }
			    // END REMOVE THUMB
			    // START REMOVE BANNER
			    if($action == 'banner'){
				    if($admin_power != 'viewer'){
				        $sql_removeThumb = "UPDATE pc_products_brands SET brand_banner='' WHERE brand_ID='$brand_ID' LIMIT 1";
				        $query_removeThumb = $mysqli->query($sql_removeThumb);
				        if($query_removeThumb === FALSE){
					        $message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editbrand.alert.brandbanner.crash'] . '</div>';
				        }else{
					        header("location: " . $GLOBALS['url'] . "/control_panel/brands-editBrand?id=$brand_ID&update=banner");
					        exit();
				        }
				    }else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			    }
				// END REMOVE BANNER
				// START DELETE BRAND
			    if($action == 'delete'){
				if($admin_power != 'viewer'){
					$sql_productRemove = "DELETE FROM pc_products_brands WHERE brand_ID='$brand_ID' LIMIT 1";
					$query_productRemove = $mysqli->query($sql_productRemove);
					if($query_productRemove === FALSE){
						$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editbrand.alert.branddelete.crash'] . '</div>';
					}else{
						header("location:  " . $GLOBALS['url'] . "/control_panel/brands?status=deleted");
                        exit();
					}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.settings.alert.shop.power.5'] . '</div>';
				}
			    }
			    // END DELETE BRAND
			}
			// END ACTIONS
			// START BRAND INO
			$row_brandInfo = $query_brandInfo->fetch_assoc();	
			$brand_name = $row_brandInfo['brand_name'];
            $brand_url = $row_brandInfo['brand_url'];
            $brand_content = $row_brandInfo['brand_content'];
			// Decrypt Site Url
			$brand_content = pc_dynamic_site_url_decrypt($brand_content);
			$brand_sidebar = pc_get_sidebar_display_option($row_brandInfo['brand_sidebar'], $lang['admin.form.select.option.left'], $lang['admin.form.select.option.right'], $lang['admin.form.select.option.none']);;
			$brand_sidebar_ID = pc_get_sidebar_name_option($row_brandInfo['brand_sidebar_ID']);
			
			$content_insurance = $brand_content;
			$brand_thumbnail_source = $row_brandInfo['brand_thumbnail'];
			if($brand_thumbnail_source != '' && $brand_thumbnail_source != ' '){
				if(file_exists("../" . $brand_thumbnail_source)){
					$brand_thumbnail_image = '<div style="max-width: 200px;"><img src="' . $GLOBALS['url'] . '/' . $brand_thumbnail_source . '" width="100%"></div>';
				}
			}else{
				$brand_thumbnail_image = '';
			}
            $brand_banner_source = $row_brandInfo['brand_banner'];
			if($brand_banner_source != '' && $brand_banner_source != ' '){
				if(file_exists("../" . $brand_banner_source)){
					$brand_banner_image = '<div style="max-width: 200px;"><img src="' . $GLOBALS['url'] . '/' . $brand_banner_source . '" width="100%"></div>';
				}
			}else{
				$brand_banner_image = '';
			}
            $brand_status = $row_brandInfo['brand_status'];
			if($brand_status == 'p'){
				$brand_status = '<option value="p">' . $lang['admin.form.select.option.public'] . '</option>';
			}else{
				$brand_status = '<option value="u">' . $lang['admin.form.select.option.unpublished'] . '</option>';
			}
			$brand_products = 0;
			$sql_used = "SELECT * FROM pc_products WHERE product_brand='$brand_ID'";
											$query_used = $mysqli->query($sql_used);
									 		if($query_used === FALSE){
												$brand_products = 0;
											}else{
												$brand_products = $query_used->num_rows;
				
										}
			$brand_update = $row_brandInfo['brand_update'];
			if($brand_update != '' && $brand_update != ' '){
				$brand_update = date_function($brand_update, 'datetime');	
				$brand_update = '
				    <div class="form-group">
                                <label>' . $lang['admin.table.th.update'] . '</label>
                                <br>
								' . $brand_update . '
                    </div>
				';							
			}
			$brand_date = date_function($row_brandInfo['brand_date'], 'datetime');
			
			// END BRAND INO
			// START BRAND URL UPDATE
			$edit_product_url = '';
			if(isset($_POST['brand_url'])){
				if($admin_power != 'viewer'){
				$edit_product_url = $_POST['brand_url'];
				if($edit_product_url != ' ' && $edit_product_url != ''){
				if(strlen($edit_product_url) < 256){
				    $edit_product_url_Copy = $edit_product_url;
					if($edit_product_url_Copy == $edit_product_url){
				        $edit_product_url = strtolower($edit_product_url);
		                $edit_product_url = preg_replace('#[^A-Za-z0-9- ]#i', '', $edit_product_url);
		                $edit_product_url = str_replace(' ', '-', $edit_product_url);
		                $edit_product_url = $mysqli->real_escape_string($edit_product_url);
		                $url_product_check = false;
						$sql_check_productLink = "SELECT brand_ID FROM pc_products_brands WHERE brand_url='$edit_product_url' AND brand_ID<>'$brand_ID' LIMIT 1";
						$query_check_productLink = $mysqli->query($sql_check_productLink);
						if($query_check_productLink === FALSE){
							$url_product_check = false;
						}else{
							$count_check_productLink = $query_check_productLink->num_rows;
							if($count_check_productLink > 0 ){
								$url_product_check = true;
							}else{
								$url_product_check = false;
							}
						}
						if($url_product_check == false){
							$sql_updateLink = "UPDATE pc_products_brands SET brand_url='$edit_product_url' WHERE brand_ID='$brand_ID' LIMIT 1";
							
							$query_updateLink = $mysqli->query($sql_updateLink);
							if($query_updateLink === FALSE){
								$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editbrand.alert.brandurl.crash'] . '</div>';
							}else{
								header("location: " . $GLOBALS['url'] . "/control_panel/brands-editBrand?id=$brand_ID&update=link");
			                exit();
							}
						}else{
							$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editbrand.alert.brandurl.vali'] . '</div>';
						}
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editproduct.alert.brandurl.char'] . '</div>';
					}
			    }else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editbrand.alert.brandurl.len'] . '</div>';
				}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editbrand.alert.brandurl.empty'] . '</div>';
				}
				}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END BRAND URL UPDATE
			// START UPDATE BRAND
			$post_brand_name = '';
            $post_brand_url = '';
            $post_brand_content = '';
            $post_brand_status = '';
            $brand_thumbnail = '';
            $brand_banner = '';
			$post_brand_sidebar = '';
            $post_brand_sidebar_ID = '';
            if(isset($_POST['brand_name'])){
				if($admin_power != 'viewer'){
	            // Get Variables
	            $x = 0;
	            $post_brand_name = $_POST['brand_name'];
                $post_brand_content = $_POST['brand_content'];
                $post_brand_status = $_POST['brand_status'];
				$post_brand_sidebar = $_POST['brand_sidebar'];
            $post_brand_sidebar_ID = $_POST['brand_sidebar_ID'];
	            // Brand Name | Count 1
	            if($post_brand_name != '' && $post_brand_name != ' '){
		            if(strlen($post_brand_name) < 101){
			            $post_brand_name_copy = $post_brand_name;
			            $post_brand_name_copy = strip_tags($post_brand_name_copy);
			            $post_brand_name_copy = stripslashes($post_brand_name_copy);
			            if($post_brand_name == $post_brand_name_copy){
				            $post_brand_name = $mysqli->real_escape_string($post_brand_name);
				            $post_brand_name = str_replace("'", "&#39;", $post_brand_name);
				            $x = $x + 1; 
			            }else{
				            $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandname.charproblem'] . '</div>';
			            }
	                }else{
			            $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandname.len'] . '</div>';
		            }
	            }else{
		            $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandname.empty'] . '</div>';
	            }
	            // Brand Content | Count 2
	            if(strlen($post_brand_content) < 4294967296){
		            $x = $x + 1;
	            }else{
		            $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandcontent.len'] . '</div>';
	            }
	            // Brand Status | Count 3
	            if($post_brand_status == 'p' || $post_brand_status == 'u'){
		            $x = $x + 1;
	            }else{    
	               	$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandstatus.wrong'] . '</div>';
	            }
	            // Brand Thumb | Count 4
	            $tumb = false;
	            if($_FILES['brand_thumbnail']['tmp_name'] != ""){
		            if($_FILES['brand_thumbnail']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		                $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.filesize'] . '</div>';
                        unlink($_FILES['brand_thumbnail']['tmp_name']); 
                    }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['brand_thumbnail']['name'])){
		                $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.filename'] . '</div>';
                        unlink($_FILES['brand_thumbnail']['tmp_name']); 	
                    }else{
			            // Find extension
			            $tumbnail_extension = '';
			            $tumbnail_type = '';
			            if(preg_match("/\.(gif)$/i", $_FILES['brand_thumbnail']['name'])){
				            $tumbnail_extension = '.gif';
				            $tumbnail_type = 'GIF Image';
			            }else if(preg_match("/\.(jpg)$/i", $_FILES['brand_thumbnail']['name'])){
		                    $tumbnail_extension = ".jpg";
		                    $tumbnail_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['brand_thumbnail']['name'])){
		        $tumbnail_extension = ".png";
		        $tumbnail_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['brand_thumbnail']['name'])){
		        $tumbnail_extension = ".jpeg";
		        $tumbnail_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.filename'] . '</div>';
			}
			$tumb_name = $_FILES['brand_thumbnail']['name'];
			if(strlen($tumb_name) > 1000){
				$tumb_name = substr($tumb_name, 0, 950);
			}
			
			$tumb_name = strip_tags($tumb_name);
			$tumb_name = stripslashes($tumb_name);
			$tumb_name = str_replace('-', '_', $tumb_name);
			$tumb_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $tumb_name);
			$tumb_name = str_replace(' ', '-', $tumb_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $tumb_name)){
				$tumb_name = $tumb_name . $tumbnail_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$tumb_name_copy = str_replace($extension_Array, $extension_Array_replace, $tumb_name);
				while($file_checky == true){
					$tumb_name = $tumb_name_copy . "_" . $c . $tumbnail_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["brand_thumbnail"]["size"];
			if(move_uploaded_file($_FILES['brand_thumbnail']['tmp_name'], "../uploads/media/$media_path/$tumb_name")){
	            $tumb_name = $mysqli->real_escape_string($tumb_name);
				$sql_addTumbMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$tumb_name ','$tumb_name','$tumbnail_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$tumb = true;
				$brand_thumbnail_source = "uploads/media/$media_path/$tumb_name";
	            $brand_thumbnail_source = $mysqli->real_escape_string($brand_thumbnail_source);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.branthumb.crash'] . '</div>';
			}
			
		}		
	}else{
		$x = $x + 1;
	}
	            // Brand Banner | Count 5
	            $banner = false;
	if($_FILES['brand_banner']['tmp_name'] != ""){
		if($_FILES['brand_banner']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.filesize'] . '</div>';
            unlink($_FILES['brand_banner']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['brand_banner']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.filename'] . '</div>';
            unlink($_FILES['brand_banner']['tmp_name']); 	
        }else{
			
			// Find extension
			$banner_extension = '';
			$banner_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['brand_banner']['name'])){
				$banner_extension = '.gif';
				$banner_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['brand_banner']['name'])){
		        $banner_extension = ".jpg";
		        $banner_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['brand_banner']['name'])){
		        $banner_extension = ".png";
		        $banner_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['brand_banner']['name'])){
		        $banner_extension = ".jpeg";
		        $banner_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.filename'] . '</div>';
			}
			$banner_name = $_FILES['brand_banner']['name'];
			if(strlen($banner_name) > 1000){
				$banner_name = substr($banner_name, 0, 950);
			}
			
			$banner_name = strip_tags($banner_name);
			$banner_name = stripslashes($banner_name);
			$banner_name = str_replace('-', '_', $banner_name);
			$banner_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $banner_name);
			$banner_name = str_replace(' ', '-', $banner_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $banner_name)){
				$banner_name = $banner_name . $banner_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$banner_name_copy = str_replace($extension_Array, $extension_Array_replace, $banner_name);
				while($file_checky == true){
					$banner_name = $banner_name_copy . "_" . $c . $banner_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["brand_banner"]["size"];
			if(move_uploaded_file($_FILES['brand_banner']['tmp_name'], "../uploads/media/$media_path/$banner_name")){
	            $banner_name = $mysqli->real_escape_string($banner_name);
				$sql_addBannerMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$banner_name ','$banner_name','$banner_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$banner = true;
				$brand_banner_source = "uploads/media/$media_path/$banner_name";
	            $brand_banner_source = $mysqli->real_escape_string($brand_banner_source);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newbrand.alert.brandbanner.crash'] . '</div>';
			}
			
		}	
	}else{
		$x = $x + 1;
	}
	// Brand Sidebar | count 6
	if($post_brand_sidebar == 'left' || $post_brand_sidebar == 'right' || $post_brand_sidebar == 'none'){
			    $x = $x + 1;
		    }else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newpage.alert.sidebar.display.wrong'] . '</div>';
		    }
	
	
	// Brand Sidebar ID | Count 7
	if($post_brand_sidebar_ID != '' && $post_brand_sidebar_ID != ' '){
			    $check_sideName = pc_check_product_sidebarName($post_brand_sidebar_ID);
			    if($check_sideName == true){
				    $x = $x + 1;
				    $post_brand_sidebar_ID = preg_replace('#[^0-9]#i', '', $post_brand_sidebar_ID);
			    }else{
				    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newpage.alert.sidebar.name.wrong'] . '</div>';
			    }
		    }else{
			    $x = $x + 1;
			    $post_brand_sidebar_ID = '';
    }
	
	
	// Insurance for Content
	if($post_brand_content == '' || $post_brand_content == ' '){
	    $post_brand_content = $content_insurance;
		$post_brand_content = $mysqli->real_escape_string($post_brand_content);
	}else{
		$post_brand_content = htmlentities($post_brand_content, ENT_QUOTES);
		$post_brand_content = $mysqli->real_escape_string($post_brand_content);
	}
	
	
	if($x == 7){
		
		// Crypt Site Url
		$post_brand_content = pc_dynamic_site_url_crypt($post_brand_content);
		
		// Brand URL
		$post_brand_url = strtolower($post_brand_name);
		$post_brand_url = preg_replace('#[^A-Za-z0-9- ]#i', '', $post_brand_url);
		$post_brand_url = str_replace(' ', '-', $post_brand_url);
		$post_brand_url = $mysqli->real_escape_string($post_brand_url);
		$post_brand_url_check = false;
		$sql_brandURL = "SELECT * FROM pc_products_brands WHERE brand_url='$post_brand_url' AND brand_ID<>'$brand_ID' LIMIT 1";
		$query_brandURL = $mysqli->query($sql_brandURL);
		if($query_brandURL === FALSE){
			//
		}else{
			$count_brandURL = $query_brandURL->num_rows;
			if($count_brandURL > 0 ){
				$post_brand_url_check = true;
			}
		}
		
		if($post_brand_url_check == true){
			$cp = 2;
			$check_url = true;
			while($check_url == true){
				
				$post_brand_url_copy = $post_brand_url . "-" . $cp;
				$post_brand_url_copy = $mysqli->real_escape_string($post_brand_url_copy);
				$sql_brandURL = "SELECT brand_name FROM pc_products_brands WHERE brand_url='$post_brand_url_copy' AND brand_ID<>'$brand_ID' LIMIT 1";
		        $query_brandURL = $mysqli->query($sql_brandURL);
		        if($query_brandURL === FALSE){
			        $check_url = false;
		        }else{
					$count_brandURL = $query_brandURL->num_rows;
			        if($count_brandURL > 0){
				        $check_url = true;
			        }else{
						$check_url = false;
					}
				}
				$cp = $cp + 1;
			}
			$post_brand_url = $post_brand_url_copy;
		}
		
		$sql_addBrand = "UPDATE pc_products_brands SET brand_name='$post_brand_name', brand_url='$post_brand_url', brand_content='$post_brand_content', brand_thumbnail='$brand_thumbnail_source', brand_banner='$brand_banner_source', brand_status='$post_brand_status', brand_sidebar='$post_brand_sidebar', brand_sidebar_ID='$post_brand_sidebar_ID', brand_update=now() WHERE brand_ID='$brand_ID' LIMIT 1";
		$query_addBrand = $mysqli->query($sql_addBrand);
		if($query_addBrand === FALSE){
			// Crash
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editbrand.alert.update.crash'] . '</div>';
			// Decrypt Site Url
			$post_brand_content = pc_dynamic_site_url_decrypt($post_brand_content);
		}else{
			// Ok
			if($brand_thumbnail != '' && $brand_thumbnail != ' '){
			    $mysqli->query($sql_addTumbMedia);
			}
			            if($brand_banner != '' && $brand_banner != ' '){
			                $mysqli->query($sql_addBannerMedia);
			            }
			            header("location: " . $GLOBALS['url'] . "/control_panel/brands-editBrand?id=" . $brand_ID . "&update=success");
			            exit();
		            }
 	            }
            }else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END UPDATE BRAND
		}else{
			header("location:  " . $GLOBALS['url'] . "/control_panel/brands");
	        exit();
		}
	}
}else{
	header("location:  " . $GLOBALS['url'] . "/control_panel/brands");
	exit();	
}



// STATUS UPDATE
if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editbrand.alert.update.success'] . '</div>';
	}
	if($update_var == 'link'){
	    $message = '<div class="alert alert-success" role="alert">' . $lang['admin.editbrand.alert.brandurl.success'] . '</div>';	
	}
	if($update_var == 'thumb'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editbrand.alert.brandtumbnail.success'] . '</div>';	
	}
	if($update_var == 'banner'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editbrand.alert.brandbanner.success'] . '</div>';	
	}
}

// SIDEBARS LISTS
$sidebar_list = '';
$sql_sidebars = "SELECT sidebar_ID, sidebar_name FROM pc_sidebars ORDER BY sidebar_name";
$query_sidebars = $mysqli->query($sql_sidebars);
$count_sidebars = $query_sidebars->num_rows;
if($count_sidebars > 0){
	while($row_sidebars = $query_sidebars->fetch_assoc()){
		$sidebar_ID = $row_sidebars["sidebar_ID"];
		$sidebar_name = $row_sidebars["sidebar_name"];
		$sidebar_row = '<option value="' . $sidebar_ID . '">' . $sidebar_name . '</option>';
		$sidebar_list .= $sidebar_row;
	}
}else{
	//
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.editbrand.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<!-- START DELETE PRODUCT MODAL -->
<div class="modal fade" id="deleteBrand" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.button.deletebrand']; ?></h4>
            </div>
            <div class="modal-body">
                <p><?php echo $lang['alert.editbrand.remove.confirm']; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <a href="<?php echo $GLOBALS['url']; ?>/control_panel/brands-editBrand?id=<?php echo $brand_ID; ?>&action=delete"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletebrand']; ?></button></a>
            </div>
        </div>
    </div>
</div>
<!-- END DELETE PRODUCT MODAL -->
<!-- START EDIT PRODUCT LINK MODAL -->
<div class="modal fade" id="editProductLink" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/brands-editBrand?id=<?php echo $brand_ID; ?>" method="post" enctype="multipart/form-data">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.label.brandlink']; ?></h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label><?php echo $lang['admin.form.label.seolink']; ?></label>
                    <input type="text" name="brand_url" class="form-control" maxlength="255" value="<?php echo $brand_url; ?>" autocomplete="off">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.save']; ?></button>
            </div>
        </div>
        </form>
    </div>
</div>
<!-- END EDIT PRODUCT LINK MODAL -->
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.editbrand.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
			<li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/brands"><i class="fa fa-diamond" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $lang['admin.brands.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $brand_name; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/brands-editBrand?id=<?php echo $brand_ID; ?>" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
							<div class="form-group">
								<label><?php echo $lang['admin.form.label.brandname']; ?></label>
						        <input type="text" class="form-control" name="brand_name" maxlength="100" autocomplete="off" value="<?php echo $brand_name; ?>">  
							</div>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.productlink']; ?></label>
						        <input type="text" class="form-control"  maxlength="1000" autocomplete="off" value="<?php echo $GLOBALS['url']; ?>/brand/<?php echo $brand_url; ?>" readonly> 
                            </div>
                            <a href="<?php echo $GLOBALS['url']; ?>/brand/<?php echo $brand_url; ?>" target="_blank"><?php echo $lang['admin.form.button.viewbrand']; ?></a>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="#" data-toggle="modal" data-target="#editProductLink"><?php echo $lang['admin.form.button.editlink']; ?></a>
                            <br>
                            <br>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.content']; ?></label>
                                <textarea id="descriptioneditor" class="form-control" name="brand_content"></textarea>
                            </div>
                            <div class="form-group">
								<label><?php echo $lang['admin.form.label.status']; ?></label>
						        <select name="brand_status" class="form-control">
                                    <?php echo $brand_status; ?>
                                    <option value="p"><?php echo $lang['admin.form.select.option.public']; ?></option>
                                    <option value="u"><?php echo $lang['admin.form.select.option.unpublished']; ?></option>
                                </select>
							</div>
						
					</div>
			    </div>
            </div>
            <div class="col-sm-5 col-md-4">
                <!-- START STATISTICS -->
                    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
					        <h3 class="panel-title"><i class="fa fa-signal"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.editbrand.text.brandstatistics']; ?></b></h3>
					    </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label><?php echo $lang['admin.table.th.products']; ?></label>
                                <br>
                                <?php echo $brand_products; ?>
                            </div>
                            <?php echo $brand_update; ?>
                            <div class="form-group">
                                <label><?php echo $lang['admin.table.th.date']; ?></label>
                                <br>
                                <?php echo $brand_date; ?>
                            </div>
                        </div>
                    </div>    
                    <!-- END STATISTICS -->
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-picture-o"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.images']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.tumbnail']; ?></label>
                            <input class="displayNone" multiple id="brand_thumbnail" type="file" size="4" name="brand_thumbnail" style="display: none;"><br>
							<button type="button" id="uploadButton0" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                        <?php echo $brand_thumbnail_image; ?>
                        <?php
								    if($brand_thumbnail_source != '' && $brand_thumbnail_source != ' '){
										echo '<br><br><a href="' . $GLOBALS['url'] . '/control_panel/brands-editBrand?id=' . $brand_ID . '&action=thumbnail">' . $lang['admin.form.button.removetumbnail'] . '</a><br><br>';
									}
								?>
                        
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.banner']; ?></label>
                            <input class="displayNone" multiple id="brand_banner" type="file" size="4" name="brand_banner" style="display: none;"><br>
							<button type="button" id="uploadButton2" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                        <?php echo $brand_banner_image; ?>
                        <?php
								    if($brand_banner_source != '' && $brand_banner_source != ' '){
										echo '<br><br><a href="' . $GLOBALS['url'] . '/control_panel/brands-editBrand?id=' . $brand_ID . '&action=banner">' . $lang['admin.form.button.removebanner'] . '</a>';
									}
						?>
                    </div>
                </div>
                <!-- START LAYOUT -->
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
					    <h3 class="panel-title"><i class="fa fa-paint-brush"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.layout']; ?></b></h3>
					</div>
                    <div class="panel-body" style="background: #f5f5f5;">
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarposition']; ?></label>
						        <select class="form-control" name="brand_sidebar"> 
                                    <?php echo $brand_sidebar; ?>
								    <option value="right"><?php echo $lang['admin.form.select.option.right']; ?></option>
									<option value="left"><?php echo $lang['admin.form.select.option.left']; ?></option>
                                    <option value="none"><?php echo $lang['admin.form.select.option.none']; ?></option>
								</select>
                            </div>
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarname']; ?></label>
						        <select class="form-control" name="brand_sidebar_ID">  
                                    <?php echo $brand_sidebar_ID; ?>
							        <?php echo $sidebar_list; ?>
								</select>
                            </div>
                    </div>
                </div>
                <!-- END LAYOUT -->
            </div>
        </div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
        <a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteBrand"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletebrand']; ?></a>
        </form>
        <br>
        <br>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
    <script src="<?php echo $GLOBALS['url']; ?>/control_panel/include/summernote/summernote.js"></script>
     <script>
	    $(document).ready(function() {
            $('#descriptioneditor').summernote({
                height: 400,
	            callbacks: {
        onImageUpload : function(files, editor, welEditable) {

             for(var i = files.length - 1; i >= 0; i--) {
                     sendFile(files[i], this);
            }
        }
    }
            });
            function sendFile(file, el) {
var form_data = new FormData();
form_data.append('file', file);
$.ajax({
    data: form_data,
    type: "POST",
    url: 'saveimage.php',
    cache: false,
    contentType: false,
    processData: false,
    success: function(url) {
        $(el).summernote('editor.insertImage', url);
    }
});
}
<?php

$array_searchFilter = array("'", '\\', '`');
$array_replaceFilter = array("&#039", "&#092", "&#096");
$brand_content = str_replace($array_searchFilter, $array_replaceFilter, $brand_content);
$brand_content = trim(preg_replace('/\s\s+/', ' ', $brand_content));
$brand_content = html_entity_decode($brand_content);

?>
var markupStr = '<?php echo $brand_content; ?>';
$('#descriptioneditor').summernote('code', markupStr);
        });
    </script>
<script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#brand_thumbnail').html($('#brand_thumbnail').val());
			};
			$('#uploadButton0').on('click', function(){
				$('#brand_thumbnail').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
    <script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#brand_banner').html($('#brand_banner').val());
			};
			$('#uploadButton2').on('click', function(){
				$('#brand_banner').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
</body>
</html>