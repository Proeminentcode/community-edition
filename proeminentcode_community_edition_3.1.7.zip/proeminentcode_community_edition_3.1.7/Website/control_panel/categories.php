<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");




$page_rows = 25;
if(isset($_GET['n'])){
	if($_GET['n'] == '50'){
		$page_rows = 50;
	}else if($_GET['n'] == '100'){
		$page_rows = 100;
	}else if($_GET['n'] == '250'){
		$page_rows = 250;
	}else{
		$page_rows = 25;
	}
}else{
	$page_rows = 25;
}




// Delete Rows
if(isset($_POST['checkbox'])){
	if($admin_power != 'viewer'){
        $cnt = array();
        $cnt = count($_POST['checkbox']);
		if($cnt < $page_rows){
			for($i=0;$i<$cnt;$i++){
                $del_id = $_POST['checkbox'][$i];
		        $del_id = $mysqli->real_escape_string($del_id);
                $sql_deleteRow = "DELETE FROM pc_products_categories WHERE category_ID='$del_id'";
                $query_deleteRow = $mysqli->query($sql_deleteRow);
            }
		}else{
			for($i=0;$i<$page_rows;$i++){
                $del_id = $_POST['checkbox'][$i];
		        $del_id = $mysqli->real_escape_string($del_id);
                $sql_deleteRow = "DELETE FROM pc_products_categories WHERE category_ID='$del_id'";
                $query_deleteRow = $mysqli->query($sql_deleteRow);
            }
		}
        
	    if($cnt > 0){
		    $message = '<div class="alert alert-success" role="alert">' . $cnt . ' '. $lang['admin.categories.alert.action.delete.success'] . '</div>';
	    }else{
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.categories.alert.action.delete.nobrands'] . '</div>';
	    }
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}


$products_list = '';
$pagination_list = '';
$count_members = 0;
$paginationCtrls = '';
$post_username = '';
$count_countMembers = 0;
$pagenum = '';
$last = '';
if(isset($_POST['post_value']) != ''){
	$post_username = $_POST['post_value'];
	if(strlen($post_username) > 0){
		$post_username = $mysqli->real_escape_string($_POST['post_value']);
	    $sql_members = "SELECT * FROM pc_products_categories WHERE category_ID='$post_username' OR category_name='$post_username' ORDER BY category_date DESC";
		$sql_membersPagination = "SELECT COUNT(category_ID) FROM pc_products_categories WHERE category_ID='$post_username' OR category_name='$post_username' ORDER BY category_date DESC";
        $query_membersPagination = $mysqli->query($sql_membersPagination);
        $row_membersPagination = $query_membersPagination->fetch_row();
        $num_rows = $row_membersPagination[0];
	}else{
		
		$sql_membersPagination = "SELECT COUNT(category_ID) FROM pc_products_categories";
        $query_membersPagination = $mysqli->query($sql_membersPagination);
        $row_membersPagination = $query_membersPagination->fetch_row();
        $num_rows = $row_membersPagination[0];
		$last = ceil($num_rows/$page_rows);
        if($last < 1){
            $last = 1;
        }
        $pagenum = 1;
        if(isset($_GET['pn'])){
	        $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
        }
        if($pagenum < 1){ 
            $pagenum = 1; 
        }else if($pagenum > $last){ 
            $pagenum = $last; 
        }
        $limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;
	    $sql_members = "SELECT * FROM pc_products_categories ORDER BY category_date DESC $limit";
	}
}else{
	$sql_membersPagination = "SELECT COUNT(category_ID) FROM pc_products_categories";
    $query_membersPagination = $mysqli->query($sql_membersPagination);
    $row_membersPagination = $query_membersPagination->fetch_row();
    $num_rows = $row_membersPagination[0];
	$last = ceil($num_rows/$page_rows);
    if($last < 1){
        $last = 1;
    }
    $pagenum = 1;
    if(isset($_GET['pn'])){
	    $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
    }
    if($pagenum < 1){ 
        $pagenum = 1; 
    }else if($pagenum > $last){ 
        $pagenum = $last; 
    }
    $limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;
    $sql_members = "SELECT * FROM pc_products_categories ORDER BY category_date DESC $limit";
}






$query_members = $mysqli->query($sql_members);
if($query_members === FALSE){
	$members_list = '<div class="alert alert-warning" role="alert">' .  $lang['alert.categories.alert.nocategories'] . '</div>';
}else{
	// Count Everything
	$sql_countMembers = "SELECT * FROM pc_products_categories";
	$query_countMembers = $mysqli->query($sql_countMembers);
	$count_countMembers = $query_countMembers->num_rows;
	$count_members = $query_members->num_rows;
	if($count_members > 0){
		$pagination_list = "Page <b>$pagenum</b> of <b>$last</b>";
		$paginationCtrls .= '<nav><ul class="pagination pagination-sm" id="no-margins">';
        if($last != 1){
	        if($pagenum > 1){
                $previous = $pagenum - 1;
		        $paginationCtrls .= '
				    <li>
                        <a href="'.$_SERVER['PHP_SELF'].'?pn='.$previous.'&n=' . $page_rows . '" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
				';
		        for($i = $pagenum-4; $i < $pagenum; $i++){
			        if($i > 0){
		                $paginationCtrls .= '<li><a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'&n=' . $page_rows . '">'.$i.'</a></li>';
			        }
	            }
            }
	        $paginationCtrls .= '<li class="active"><a href="#">'.$pagenum.'</a></li>';
	        for($i = $pagenum+1; $i <= $last; $i++){
		        $paginationCtrls .= '<li><a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'&n=' . $page_rows . '">'.$i.'</a></li>';
		        if($i >= $pagenum+4){
			       break;
		        }
	        }
            if($pagenum != $last){
                $next = $pagenum + 1;
                $paginationCtrls .= '
				    <li>
                        <a href="'.$_SERVER['PHP_SELF'].'?pn='.$next.'&n=' . $page_rows . '" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
				';
            }
			$paginationCtrls .= '</ul></nav>';
        }
		$products_list .= '
		<form action="' . $GLOBALS['url'] . '/control_panel/categories" method="post">
		<button type="submit" class="btn btn-default  btn-sm"><i class="fa fa-trash"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deletecategories'] . '</button>
		<br><br>
	    <div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th><input type="checkbox" name="select-all" id="select-all" style="margin-bottom: -3px;"></th>
						<th>' . $lang['admin.table.th.id'] . '</th>
						<th>' . $lang['admin.table.th.categoryname'] . '</th>
						<th>' . $lang['admin.table.th.parent'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.status'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.products'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.date'] . '</th>
					</tr>
				</thead>
				<tbody>
	    ';
	    while($row_products = $query_members->fetch_assoc()){
			$category_ID = $row_products["category_ID"];
			$category_name = $row_products["category_name"];
			$category_parent = $row_products["category_parent"];
			if($category_parent != '' && $category_parent != ' ' && $category_parent != 0){
			    $sql_findParent = "SELECT category_name FROM pc_products_categories WHERE category_ID='$category_parent' LIMIT 1";
				$query_findParent = $mysqli->query($sql_findParent);
				if($query_findParent === FALSE){
					$category_parent = '<i>' . $lang['admin.form.select.option.none'] . '</i>';
				}else{
				    $count_findParent = $query_findParent->num_rows;
					if($count_findParent > 0){
						$row_findParent = $query_findParent->fetch_assoc();
						$category_parent = $row_findParent['category_name'];
					}else{
						$category_parent = '<i>' . $lang['admin.form.select.option.none'] . '</i>';
					}
				}
			}else{
				$category_parent = '<i>' . $lang['admin.form.select.option.none'] . '</i>';
			}
			$category_status = $row_products["category_status"];
			if($category_status == 'p'){
				$category_status = '<span class="label label-success">' . $lang['admin.form.select.option.public'] . '</span>';
			}else{
				$category_status = '<span class="label label-warning">' . $lang['admin.form.select.option.unpublished'] . '</span>';
			}
			$category_products = 0;
			$sql_used = "SELECT product_category FROM pc_products";
			$query_used = $mysqli->query($sql_used);
			if($query_used === FALSE){
				$category_products = 0;
			}else{
				$count_used = $query_used->num_rows;
				if($count_used > 0){
				    while($row_used = $query_used->fetch_assoc()){
						$product_category = $row_used['product_category'];
						$product_category_items = explode(",", $product_category);
						foreach($product_category_items as $i =>$key){
							if($category_ID == $key){
								$category_products = $category_products + 1;
							}
						}
					}
				}else{
					$category_products = 0;
				}
			}
			                                $category_date = $row_products['category_date'];
			                                $products_list .= '
			                                    <tr>
												    <td><input type="checkbox" name="checkbox[]" value="' . $category_ID . '"></td>
                                                    <td>#' . $category_ID .'</td>
													<td><a href="' . $GLOBALS['url'] . '/control_panel/categories-editCategory?id=' . $category_ID . '">' . $category_name .'</a></td>
													<td>' . $category_parent . '</td>
													
                                                    <td style="text-align: center;">' . $category_status . '</td>
													<td style="text-align: center;">' . $category_products . '</td>
													<td style="text-align: center;">' . date_function($category_date, "date") . '</td>
                                                </tr>
			                                ';
	    }
	    $products_list .= '
	                </tbody>
			    </table>
		    </div>
			</form>
	    ';
	}else{
		$products_list = '<div class="alert alert-warning" role="alert">' .  $lang['alert.categories.alert.nocategories'] . '</div>';
	}
}


// New Category Added
if(isset($_GET['status']) == 'success'){
	$message = '<div class="alert alert-success" role="alert">' . $lang['admin.newcategory.alert.success'] . '</div>';
}

// Category Deleted
if(isset($_GET['status']) == 'deleted'){
	$message = '<div class="alert alert-success" role="alert">' . $lang['admin.categories.alert.categorydelete.success'] . '</div>';
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.categories.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.categories.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li class="active"><i class="fa fa-th-large"></i>&nbsp;&nbsp;<?php echo $lang['admin.categories.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
		<div class="panel panel-default">
            <div class="panel-heading heading-white">
			    <h3 class="panel-title"><i class="fa fa-th-large"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.categories.title']; ?></b></h3>
			</div>
            <div class="panel-body">
			    <a href="<?php echo $GLOBALS['url']; ?>/control_panel/categories-newCategory"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.newcategory']; ?></button></a>
				<br/>
				<br/>
				<div class="row">
					<div class="col-xs-6">
						<h3 style="margin-top: 2px;margin-bottom: 0px;"><?php echo $num_rows; ?>&nbsp;<?php echo $lang['admin.categories.title']; ?></h3>
					</div>
                    <div class="col-xs-6" style="text-align: right;">
					    <form class="form-inline" action="<?php echo $GLOBALS['url']; ?>/control_panel/categories" method="post">
						    <div class="form-group">
                                <input type="text" class="form-control input-sm" placeholder="<?php echo $lang['admin.form.placeholder.search'] ; ?>" name="post_value" value="<?php echo $post_username; ?>">
                            </div>
							<button type="submit" class="btn <?php echo $admin_theme_btn; ?> btn-sm"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.search']; ?></button>
						</form>
				    </div>
				</div>
				<hr>
	            <?php echo $products_list; ?>
                                 <br/>
                                 <?php
								     if($num_rows > 0){
										 echo '
                                             <div class="row">
                                                 <div class="col-xs-6">
                                                     <div style="width: 200px;">
                                                         <form class="form-inline" action="' . $GLOBALS['url'] . '/control_panel/categories" method="get">
														     <div class="form-group">
                                                                 <select class="form-control input-sm" name="n">
                                                                 <option value="' . $page_rows . '">' . $page_rows . '</option>
                                                                 <option value="25">25</option>
                                                                 <option value="50">50</option>
                                                                 <option value="100">100</option>
                                                                 <option value="250">250</option>
                                                                 </select>
															 </div>
															 <button type="submit" class="btn ' . $admin_theme_btn . ' btn-sm">' . $lang['admin.form.button.show'] . '</button>
                                                         </form>
                                                     </div>
                                                 </div>
                                                 <div class="col-xs-6" style="text-align: right">
                                                     ';
												if($num_rows > $page_rows){
												    echo $paginationCtrls;
									            } 
												echo '
                                                 </div>
                                             </div>
								         ';
                                     }
                                 ?>
						    </div>
						</div>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>