<?php



define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


// GET CATEGORIES LIST
$categories_ordered = '';
$sql_getCategories = "SELECT * FROM pc_products_categories WHERE category_parent='0' ORDER BY category_name ASC";
$query_getCategories = $mysqli->query($sql_getCategories);
if($query_getCategories === FALSE){
	$categories_ordered = '<option>' . $lang['admin.categories.text.nocategories'] . '</option>';
}else{
	$count_getCategories = $query_getCategories->num_rows;
	if($count_getCategories > 0){
		while($row_getCategories = $query_getCategories->fetch_assoc()){
			$main_category_ID = $row_getCategories['category_ID'];
			$main_category_name = $row_getCategories['category_name'];
			$main_category_parent = $row_getCategories['category_parent'];
			$categories_ordered .= '<option value="' . $main_category_ID . '">' . $main_category_name . '</option>';	
			if($main_category_parent == '' || $main_category_parent == ' ' || $main_category_parent == 0){
			    /*$sql_getSubcategories = "SELECT * FROM pc_products_categories WHERE category_parent='$main_category_ID' ORDER BY category_name ASC";
				$query_getSubcategories = $mysqli->query($sql_getSubcategories);
				if($query_getSubcategories === FALSE){
					// do nothing
				}else{
					$count_getSubcategories = $query_getSubcategories->num_rows;
					if($count_getSubcategories > 0){
						while($row_getSubcategories = $query_getSubcategories->fetch_assoc()){
							$subcategory_ID = $row_getSubcategories['category_ID'];
							$subcategory_name = $row_getSubcategories['category_name'];
							$subcategory_category_parent = $row_getSubcategories['category_parent'];
							$categories_ordered .= '<option value="' . $subcategory_ID . '">- ' . $subcategory_name . '</option>';
							if($subcategory_category_parent == '' || $subcategory_category_parent == ' ' || $subcategory_category_parent == 0){
								$sql_getSubcategories = "SELECT * FROM pc_products_categories WHERE category_parent='$subcategory_ID' ORDER BY category_name ASC";
								$query_getSubcategories = $mysqli->query($sql_getSubcategories);
								if($query_getSubcategories === FALSE){
					                // do nothing
				                }else{
					                $count_getSubcategories = $query_getSubcategories->num_rows;
					                if($count_getSubcategories > 0){
										while($row_getSubcategories = $query_getSubcategories->fetch_assoc()){
							                $subcategory_ID = $row_getSubcategories['category_ID'];
							                $subcategory_name = $row_getSubcategories['category_name'];
							                $subcategory_category_parent = $row_getSubcategories['category_parent'];
							                $categories_ordered .= '<option value="' . $subcategory_ID . '">- - ' . $subcategory_name . '</option>';
										}
									}else{
										
									}
				                }
							}
						}
					}else{
					    // do nothing
					}
				}*/
				$categories_ordered .= pc_categories_childrens_option($main_category_ID);
			}
		}
	}else{
		$categories_ordered = '<option>' . $lang['admin.categories.text.nocategories'] . '</option>';
	}
}


$post_category_name = '';
$post_category_url = '';
$post_category_content = '';
$post_category_status = '';
$post_category_parent = '';
$category_thumbnail = '';
$category_banner = '';
$post_category_sidebar = '';
$post_category_sidebar_ID = '';
if(isset($_POST['category_name'])){
	if($admin_power != 'viewer'){
	// Get Variables
	$x = 0;
	$post_category_name = $_POST['category_name'];
    $post_category_content = $_POST['category_content'];
    $post_category_status = $_POST['category_status'];
	$post_category_parent = $_POST['category_parent'];
	$post_category_sidebar = $_POST['category_sidebar'];
    $post_category_sidebar_ID = $_POST['category_sidebar_ID'];
	
	// Category Name | Count 1
	if($post_category_name != '' && $post_category_name != ' '){
		if(strlen($post_category_name) < 101){
			$post_category_name_copy = $post_category_name;
			$post_category_name_copy = strip_tags($post_category_name_copy);
			$post_category_name_copy = stripslashes($post_category_name_copy);
			if($post_category_name == $post_category_name_copy){
				$post_category_name = $mysqli->real_escape_string($post_category_name);
				$post_category_name = str_replace("'", "&#39;", $post_category_name);
				$x = $x + 1; 
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categoryname.charproblem'] . '</div>';
			}
	    }else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categoryname.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categoryname.empty'] . '</div>';
	}
	
	
	// Category Parent | Count 2
	if($post_category_parent != '' && $post_category_parent != ' '){
		$post_category_parent = preg_replace('#[^0-9]#i', '', $post_category_parent);
		$post_category_parent = $mysqli->real_escape_string($post_category_parent);
		$sql_checkCategoryAv = "SELECT * FROM pc_products_categories WHERE category_ID='$post_category_parent' LIMIT 1";
		$query_checkCategoryAv = $mysqli->query($sql_checkCategoryAv);
		if($query_checkCategoryAv === FALSE){
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.parentcategory.wrong'] . '</div>';
		}else{
			$count_checkCategoryAv = $query_checkCategoryAv->num_rows;
			if($count_checkCategoryAv > 0){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.parentcategory.wrong'] . '</div>';
			}
		}
	}else{
		$x = $x + 1;
		$post_category_parent = 0;
	}
	
	
	// Category Content | Count 3
	if(strlen($post_category_content) < 4294967296){
		$post_category_content = htmlentities($post_category_content, ENT_QUOTES);
		$post_category_content = $mysqli->real_escape_string($post_category_content);
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorycontent.len'] . '</div>';
	}
	
	
	// Category Status | Count 4
	if($post_category_status == 'p' || $post_category_status == 'u'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorystatus.wrong'] . '</div>';
	}
	
	
	// Category Thumb | Count 5
	$tumb = false;
	if($_FILES['category_thumbnail']['tmp_name'] != ""){
		if($_FILES['category_thumbnail']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.filesize'] . '</div>';
            unlink($_FILES['category_thumbnail']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['category_thumbnail']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.filename'] . '</div>';
            unlink($_FILES['category_thumbnail']['tmp_name']); 	
        }else{
			
			// Find extension
			$tumbnail_extension = '';
			$tumbnail_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['category_thumbnail']['name'])){
				$tumbnail_extension = '.gif';
				$tumbnail_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['category_thumbnail']['name'])){
		        $tumbnail_extension = ".jpg";
		        $tumbnail_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['category_thumbnail']['name'])){
		        $tumbnail_extension = ".png";
		        $tumbnail_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['category_thumbnail']['name'])){
		        $tumbnail_extension = ".jpeg";
		        $tumbnail_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.filename'] . '</div>';
			}
			$tumb_name = $_FILES['category_thumbnail']['name'];
			if(strlen($tumb_name) > 1000){
				$tumb_name = substr($tumb_name, 0, 950);
			}
			
			$tumb_name = strip_tags($tumb_name);
			$tumb_name = stripslashes($tumb_name);
			$tumb_name = str_replace('-', '_', $tumb_name);
			$tumb_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $tumb_name);
			$tumb_name = str_replace(' ', '-', $tumb_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $tumb_name)){
				$tumb_name = $tumb_name . $tumbnail_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$tumb_name_copy = str_replace($extension_Array, $extension_Array_replace, $tumb_name);
				while($file_checky == true){
					$tumb_name = $tumb_name_copy . "_" . $c . $tumbnail_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["category_thumbnail"]["size"];
			if(move_uploaded_file($_FILES['category_thumbnail']['tmp_name'], "../uploads/media/$media_path/$tumb_name")){
	            $tumb_name = $mysqli->real_escape_string($tumb_name);
				$sql_addTumbMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$tumb_name ','$tumb_name','$tumbnail_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$tumb = true;
				$category_thumbnail = "uploads/media/$media_path/$tumb_name";
	            $category_thumbnail = $mysqli->real_escape_string($category_thumbnail);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.crash'] . '</div>';
			}
			
		}		
	}else{
		$x = $x + 1;
	}
	
	
	// Category Banner | Count 6
	$banner = false;
	if($_FILES['category_banner']['tmp_name'] != ""){
		if($_FILES['category_banner']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorytbanner.filesize'] . '</div>';
            unlink($_FILES['category_banner']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['category_banner']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorybanner.filename'] . '</div>';
            unlink($_FILES['brand_banner']['tmp_name']); 	
        }else{
			
			// Find extension
			$banner_extension = '';
			$banner_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['category_banner']['name'])){
				$banner_extension = '.gif';
				$banner_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['category_banner']['name'])){
		        $banner_extension = ".jpg";
		        $banner_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['category_banner']['name'])){
		        $banner_extension = ".png";
		        $banner_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['category_banner']['name'])){
		        $banner_extension = ".jpeg";
		        $banner_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorybanner.filename'] . '</div>';
			}
			$banner_name = $_FILES['category_banner']['name'];
			if(strlen($banner_name) > 1000){
				$banner_name = substr($banner_name, 0, 950);
			}
			
			$banner_name = strip_tags($banner_name);
			$banner_name = stripslashes($banner_name);
			$banner_name = str_replace('-', '_', $banner_name);
			$banner_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $banner_name);
			$banner_name = str_replace(' ', '-', $banner_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $banner_name)){
				$banner_name = $banner_name . $banner_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$banner_name_copy = str_replace($extension_Array, $extension_Array_replace, $banner_name);
				while($file_checky == true){
					$banner_name = $banner_name_copy . "_" . $c . $banner_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["category_banner"]["size"];
			if(move_uploaded_file($_FILES['category_banner']['tmp_name'], "../uploads/media/$media_path/$banner_name")){
	            $banner_name = $mysqli->real_escape_string($banner_name);
				$sql_addBannerMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$banner_name ','$banner_name','$banner_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$banner = true;
				$category_banner = "uploads/media/$media_path/$banner_name";
	            $category_banner = $mysqli->real_escape_string($category_banner);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorybanner.crash'] . '</div>';
			}
			
		}	
	}else{
		$x = $x + 1;
	}
	
	
	// Category Sidebar | Count 7
	if($post_category_sidebar == 'left' || $post_category_sidebar == 'right' || $post_category_sidebar == 'none'){
			    $x = $x + 1;
		    }else{
			    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newpage.alert.sidebar.display.wrong'] . '</div>';
		    }
	
	
	// Category Sidebar ID | Count 8
	if($post_category_sidebar_ID != '' && $post_category_sidebar_ID != ' '){
			    $check_sideName = pc_check_product_sidebarName($post_category_sidebar_ID);
			    if($check_sideName == true){
				    $x = $x + 1;
				    $post_category_sidebar_ID = preg_replace('#[^0-9]#i', '', $post_category_sidebar_ID);
			    }else{
				    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newpage.alert.sidebar.name.wrong'] . '</div>';
			    }
		    }else{
			    $x = $x + 1;
			    $post_category_sidebar_ID = '';
    }
	
	
	if($x == 8){

		// Crypt Site Url
		$post_category_content = pc_dynamic_site_url_crypt($post_category_content);
		
		// Category URL
		$post_category_url = strtolower($post_category_name);
		$post_category_url = preg_replace('#[^A-Za-z0-9- ]#i', '', $post_category_url);
		$post_category_url = str_replace(' ', '-', $post_category_url);
		$post_category_url = $mysqli->real_escape_string($post_category_url);
		$post_category_url_check = false;
		$sql_categoryURL = "SELECT * FROM pc_products_categories WHERE category_url='$post_category_url'";
		$query_categoryURL = $mysqli->query($sql_categoryURL);
		if($query_categoryURL === FALSE){
			//
		}else{
			$count_categoryURL = $query_categoryURL->num_rows;
			if($count_categoryURL > 0 ){
				$post_category_url_check = true;
			}
		}
		if($post_category_url_check == true){
			$cp = 2;
			$check_url = true;
			while($check_url == true){
				
				$post_category_url_copy = $post_category_url . "-" . $cp;
				$post_category_url_copy = $mysqli->real_escape_string($post_category_url_copy);
				$sql_categoryURL = "SELECT category_name FROM pc_products_categories WHERE category_url='$post_category_url_copy'";
		        $query_categoryURL = $mysqli->query($sql_categoryURL);
		        if($query_categoryURL === FALSE){
			        $check_url = false;
		        }else{
					$count_categoryURL = $query_categoryURL->num_rows;
			        if($count_categoryURL > 0){
				        $check_url = true;
			        }else{
						$check_url = false;
					}
				}
				$cp = $cp + 1;
			}
			$post_category_url = $post_category_url_copy;
		}
		
		
		// INSERT CATEGORY
		$sql_addCategory = "INSERT INTO pc_products_categories(category_name, category_parent, category_url, category_content, category_thumbnail, category_banner, category_sidebar, category_sidebar_ID, category_status, category_date) VALUES('$post_category_name','$post_category_parent','$post_category_url','$post_category_content','$category_thumbnail','$category_banner','$post_category_sidebar','$post_category_sidebar_ID','$post_category_status',now())";
		$query_addCategory = $mysqli->query($sql_addCategory);
		if($query_addCategory === FALSE){
			// Crash
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.newcategory.alert.crash'] . '</div>';
			// Decrypt Site Url
			$post_category_content = pc_dynamic_site_url_decrypt($post_category_content);
		}else{
			// Ok
			if($brand_thumbnail != '' && $brand_thumbnail != ' '){
			    $mysqli->query($sql_addTumbMedia);
			}
			if($brand_banner != '' && $brand_banner != ' '){
			     $mysqli->query($sql_addBannerMedia);
			}
			header("location: " . $GLOBALS['url'] . "/control_panel/categories?status=success");
			exit();
		}
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}


// SIDEBARS LISTS
$sidebar_list = '';
$sql_sidebars = "SELECT sidebar_ID, sidebar_name FROM pc_sidebars ORDER BY sidebar_name";
$query_sidebars = $mysqli->query($sql_sidebars);
$count_sidebars = $query_sidebars->num_rows;
if($count_sidebars > 0){
	while($row_sidebars = $query_sidebars->fetch_assoc()){
		$sidebar_ID = $row_sidebars["sidebar_ID"];
		$sidebar_name = $row_sidebars["sidebar_name"];
		$sidebar_row = '<option value="' . $sidebar_ID . '">' . $sidebar_name . '</option>';
		$sidebar_list .= $sidebar_row;
	}
}else{
	//
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.newcategory.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.newcategory.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
			<li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/categories"><i class="fa fa-th-large"></i>&nbsp;&nbsp;<?php echo $lang['admin.categories.title']; ?></a></li>
            <li class="active"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.newcategory.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/categories-newCategory" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
			            
							<div class="form-group">
								<label><?php echo $lang['admin.form.label.categoryname']; ?></label>
						        <input type="text" class="form-control" name="category_name" maxlength="100" autocomplete="off" value="<?php echo $post_category_name; ?>">  
							</div>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.parentcategory']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.parentcategory']; ?>"></i></label>
                                <select class="form-control" name="category_parent">
                                    <option></option>
                                    <?php echo $categories_ordered; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.content']; ?></label>
                                <textarea id="descriptioneditor" class="form-control" name="category_content"></textarea>
                            </div>
                            <div class="form-group">
								<label><?php echo $lang['admin.form.label.status']; ?></label>
						        <select name="category_status" class="form-control">
                                    <option value="p"><?php echo $lang['admin.form.select.option.public']; ?></option>
                                    <option value="u"><?php echo $lang['admin.form.select.option.unpublished']; ?></option>
                                </select>
							</div>
						
					</div>
			    </div>
            </div>
            <div class="col-sm-5 col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-picture-o"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.images']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.tumbnail']; ?></label>
                            <input class="displayNone" multiple id="category_thumbnail" type="file" size="4" name="category_thumbnail" style="display: none;"><br>
							<button type="button" id="uploadButton0" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.banner']; ?></label>
                            <input class="displayNone" multiple id="category_banner" type="file" size="4" name="category_banner" style="display: none;"><br>
							<button type="button" id="uploadButton2" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                    </div>
                </div>
                <!-- START LAYOUT -->
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
					    <h3 class="panel-title"><i class="fa fa-paint-brush"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.layout']; ?></b></h3>
					</div>
                    <div class="panel-body" style="background: #f5f5f5;">
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarposition']; ?></label>
						        <select class="form-control" name="category_sidebar">  
								    <option value="right"><?php echo $lang['admin.form.select.option.right']; ?></option>
									<option value="left"><?php echo $lang['admin.form.select.option.left']; ?></option>
                                    <option value="none"><?php echo $lang['admin.form.select.option.none']; ?></option>
								</select>
                            </div>
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarname']; ?></label>
						        <select class="form-control" name="category_sidebar_ID">  
							        <?php echo $sidebar_list; ?>
								</select>
                            </div>
                    </div>
                </div>
                <!-- END LAYOUT -->
            </div>
        </div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.addcategory']; ?></button>
        </form>
        <br>
        <br>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
    <script src="<?php echo $GLOBALS['url']; ?>/control_panel/include/summernote/summernote.js"></script>
     <script>
	    $(document).ready(function() {
            $('#descriptioneditor').summernote({
                height: 400,
	            callbacks: {
        onImageUpload : function(files, editor, welEditable) {

             for(var i = files.length - 1; i >= 0; i--) {
                     sendFile(files[i], this);
            }
        }
    }
            });
            function sendFile(file, el) {
var form_data = new FormData();
form_data.append('file', file);
$.ajax({
    data: form_data,
    type: "POST",
    url: 'saveimage.php',
    cache: false,
    contentType: false,
    processData: false,
    success: function(url) {
        $(el).summernote('editor.insertImage', url);
    }
});
}
<?php

$array_searchFilter = array("'", '\\', '`');
$array_replaceFilter = array("&#039", "&#092", "&#096");
$post_category_content = str_replace($array_searchFilter, $array_replaceFilter, $post_category_content);
$post_category_content = trim(preg_replace('/\s\s+/', ' ', $post_category_content));
$post_category_content = html_entity_decode($post_category_content);

?>
var markupStr = '<?php echo $post_category_content; ?>';
$('#descriptioneditor').summernote('code', markupStr);
        });
    </script>
<script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#category_thumbnail').html($('#category_thumbnail').val());
			};
			$('#uploadButton0').on('click', function(){
				$('#category_thumbnail').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
    <script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#category_banner').html($('#category_banner').val());
			};
			$('#uploadButton2').on('click', function(){
				$('#category_banner').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
</body>
</html>