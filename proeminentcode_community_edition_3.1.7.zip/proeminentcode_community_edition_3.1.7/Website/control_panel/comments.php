<?php


define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");


$page_rows = 25;
if(isset($_GET['n'])){
	if($_GET['n'] == '50'){
		$page_rows = 50;
	}else if($_GET['n'] == '100'){
		$page_rows = 100;
	}else if($_GET['n'] == '250'){
		$page_rows = 250;
	}else{
		$page_rows = 25;
	}
}else{
	$page_rows = 25;
}



// Delete Rows
if(isset($_POST['checkbox'])){
	if($admin_power != 'viewer'){
        $cnt = array();
        $cnt = count($_POST['checkbox']);
		if($cnt < $page_rows){
			for($i=0;$i<$cnt;$i++){
                $del_id = $_POST['checkbox'][$i];
		        $del_id = $mysqli->real_escape_string($del_id);
                $sql_deleteRow = "DELETE FROM pc_comments WHERE comment_ID='$del_id'";
                $query_deleteRow = $mysqli->query($sql_deleteRow);
            }
		}else{
			for($i=0;$i<$page_rows;$i++){
                $del_id = $_POST['checkbox'][$i];
		        $del_id = $mysqli->real_escape_string($del_id);
                $sql_deleteRow = "DELETE FROM pc_comments WHERE comment_ID='$del_id'";
                $query_deleteRow = $mysqli->query($sql_deleteRow);
            }
		}
        
	    if($cnt > 0){
		    $message = '<div class="alert alert-success" role="alert">' . $cnt . ' '. $lang['admin.comments.alert.action.delete.success'] . '</div>';
	    }else{
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.comments.alert.action.delete.nocomments'] . '</div>';
	    }
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}


// Actions
$get_action = '';
$get_id = '';
if(isset($_GET['action'])){
	if($admin_power == 'admin' || $admin_power == 'editor'){
	if(isset($_GET['id']) != ''){
		$get_action = $_GET['action'];
		$get_id = $_GET['id'];
	    // Approve
	    if($get_action == 'approve'){
		    $check_coment = pc_check_comment($get_id);
			if($check_coment == true){
				$approve = pc_delete_comment($get_id, 'approve');
				if($approve == true){
					$message = '<div class="alert alert-success" role="alert">' . $lang['admin.comments.alert.approve'] . '</div>';
				}else{
					$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.comments.alert.approve.crash'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.comments.alert.nexisting'] . '</div>';
			}
	    }
		// Pending
		if($get_action == 'unapprove'){
		    $check_coment = pc_check_comment($get_id);
			if($check_coment == true){
				$unapprove = pc_delete_comment($get_id, 'unapprove');
				if($unapprove == true){
					$message = '<div class="alert alert-success" role="alert">' . $lang['admin.comments.alert.unapprove'] . '</div>';
				}else{
					$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.comments.alert.unapprove.crash'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.comments.alert.nexisting'] . '</div>';
			}
	    }
		// Delete
		if($get_action == 'delete'){
		    $check_coment = pc_check_comment($get_id);
			if($check_coment == true){
				$delete = pc_delete_comment($get_id, 'delete');
				if($delete == true){
					$message = '<div class="alert alert-success" role="alert">' . $lang['admin.comments.alert.delete'] . '</div>';
				}else{
					$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.comments.alert.delete.crash'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.comments.alert.nexisting'] . '</div>';
			}
	    }
		// Remove
		if($get_action == 'remove'){
		    $check_coment = pc_check_comment($get_id);
			if($check_coment == true){
				$remove = pc_delete_comment($get_id, 'remove');
				if($remove == true){
					$message = '<div class="alert alert-success" role="alert">' . $lang['admin.comments.alert.remove'] . '</div>';
				}else{
					$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.comments.alert.remove.crash'] . '</div>';
				}
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.comments.alert.nexisting'] . '</div>';
			}
	    }
	}
	}else{
		$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.settings.alert.shop.power.5'] . '</div>';
	}
}




$members_list = '';
$pagination_list = '';
$count_members = 0;
$paginationCtrls = '';
$post_username = '';
$count_countMembers = 0;
$pagenum = '';
$last = '';
if(isset($_POST['post_value']) != ''){
	$post_username = $_POST['post_value'];
	if(strlen($post_username) > 0){
		$post_username = $mysqli->real_escape_string($_POST['post_value']);
	    $sql_members = "SELECT * FROM pc_comments WHERE comment_ID='$post_username' ORDER BY comment_date DESC";
		$sql_membersPagination = "SELECT COUNT(comment_ID) FROM pc_comments WHERE comment_ID='$post_username' ORDER BY comment_date DESC";
        $query_membersPagination = $mysqli->query($sql_membersPagination);
        $row_membersPagination = $query_membersPagination->fetch_row();
        $num_rows = $row_membersPagination[0];
	}else{
		
		$sql_membersPagination = "SELECT COUNT(comment_ID) FROM pc_comments";
        $query_membersPagination = $mysqli->query($sql_membersPagination);
        $row_membersPagination = $query_membersPagination->fetch_row();
        $num_rows = $row_membersPagination[0];
		$last = ceil($num_rows/$page_rows);
        if($last < 1){
            $last = 1;
        }
        $pagenum = 1;
        if(isset($_GET['pn'])){
	        $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
        }
        if($pagenum < 1){ 
            $pagenum = 1; 
        }else if($pagenum > $last){ 
            $pagenum = $last; 
        }
        $limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;
	    $sql_members = "SELECT * FROM pc_comments ORDER BY comment_date DESC $limit";
	}
}else{
	$sql_membersPagination = "SELECT COUNT(comment_ID) FROM pc_comments";
    $query_membersPagination = $mysqli->query($sql_membersPagination);
    $row_membersPagination = $query_membersPagination->fetch_row();
    $num_rows = $row_membersPagination[0];
	$last = ceil($num_rows/$page_rows);
    if($last < 1){
        $last = 1;
    }
    $pagenum = 1;
    if(isset($_GET['pn'])){
	    $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
    }
    if($pagenum < 1){ 
        $pagenum = 1; 
    }else if($pagenum > $last){ 
        $pagenum = $last; 
    }
    $limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;
    $sql_members = "SELECT * FROM pc_comments ORDER BY comment_date DESC $limit";
}






$query_members = $mysqli->query($sql_members);
if($query_members === FALSE){
	$members_list = '<div class="alert alert-warning" role="alert">' . $lang['alert.comments.nocomments'] . '</div>';
}else{
	// Count Everything
	$sql_countMembers = "SELECT * FROM pc_comments";
	$query_countMembers = $mysqli->query($sql_countMembers);
	$count_countMembers = $query_countMembers->num_rows;
	$count_members = $query_members->num_rows;
	if($count_members > 0){
		$pagination_list = "Page <b>$pagenum</b> of <b>$last</b>";
		$paginationCtrls .= '<nav><ul class="pagination pagination-sm" id="no-margins">';
        if($last != 1){
	        if($pagenum > 1){
                $previous = $pagenum - 1;
		        $paginationCtrls .= '
				    <li>
                        <a href="'.$_SERVER['PHP_SELF'].'?pn='.$previous.'&n=' . $page_rows . '" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
				';
		        for($i = $pagenum-4; $i < $pagenum; $i++){
			        if($i > 0){
		                $paginationCtrls .= '<li><a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'&n=' . $page_rows . '">'.$i.'</a></li>';
			        }
	            }
            }
	        $paginationCtrls .= '<li class="active"><a href="#">'.$pagenum.'</a></li>';
	        for($i = $pagenum+1; $i <= $last; $i++){
		        $paginationCtrls .= '<li><a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'&n=' . $page_rows . '">'.$i.'</a></li>';
		        if($i >= $pagenum+4){
			       break;
		        }
	        }
            if($pagenum != $last){
                $next = $pagenum + 1;
                $paginationCtrls .= '
				    <li>
                        <a href="'.$_SERVER['PHP_SELF'].'?pn='.$next.'&n=' . $page_rows . '" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
				';
            }
			$paginationCtrls .= '</ul></nav>';
        }
		$members_list .= '
		<form action="' . $GLOBALS['url'] . '/control_panel/comments" method="post">
		<button type="submit" class="btn btn-default  btn-sm"><i class="fa fa-trash"></i>&nbsp;&nbsp;' . $lang['admin.form.button.deletecomments'] . '</button>
		<br>
		<br>
	    <div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th><input type="checkbox" name="select-all" id="select-all" style="margin-bottom: -3px;"></th>
						<th>' . $lang['admin.table.th.id'] . '</th>
						<th style="min-width: 150px;">' . $lang['admin.form.label.posttitle'] . '</th>
						<th>' . $lang['admin.form.label.member'] . '</th>												
						<th>' . $lang['admin.form.label.comment'] . '</th>
						<th style="text-align: center;">' . $lang['admin.form.label.status'] . '</th>
						<th style="text-align: center;">' . $lang['admin.table.th.date'] .'</th>
					</tr>
				</thead>
				<tbody>
	    ';
	    while($row_members = $query_members->fetch_assoc()){
			$comment_actions = '';
			$comment_ID = $row_members['comment_ID'];
			$comment_post_ID = $row_members['comment_post_ID'];
			// Get Post Name
			
			$comment_user_ID = $row_members['comment_user_ID'];
			$comment_user_ID_copy = $comment_user_ID;
			// Get Member Name
			$comment_user_ID = pc_get_member_username($comment_user_ID);
			// Get Member Username
			$comment_content = $row_members['comment_content'];
			$comment_approved = $row_members['comment_approved'];
			$tr_style = '';
			if($comment_approved == 'a'){
				$comment_approved = $lang['admin.form.select.option.approved'];
				$status_style = 'label-success';
				$comment_actions = '<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=unapprove&id=' . $comment_ID . '" style="color: #f0ad4e;"><i class="fa fa-refresh" aria-hidden="true"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.unapprove'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments-editComment?id=' . $comment_ID . '" style="color: #5bc0de;"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.edit'] . '</a>' . '&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=delete&id=' . $comment_ID . '" style="color: #777;"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.delete'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=remove&id=' . $comment_ID . '" style="color: #d9534f;"><i class="fa fa-trash"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.remove'] . '</a>';
			}else if($comment_approved == 'p'){
				$comment_approved = $lang['admin.form.select.option.pending'];
				$status_style = 'label-warning';
				$comment_actions = '<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=approve&id=' . $comment_ID . '" style="color: #5cb85c;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.approve'] . '</a>' . '&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments-editComment?id=' . $comment_ID . '" style="color: #5bc0de;"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.edit'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=delete&id=' . $comment_ID . '" style="color: #777;"><i class="fa fa-times"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.delete'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=remove&id=' . $comment_ID . '" style="color: #d9534f;"><i class="fa fa-trash"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.remove'] . '</a>';
			}else{
				$comment_approved = $lang['admin.form.select.option.deleted'];
				$status_style = 'label-default';
				$comment_actions = '<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=approve&id=' . $comment_ID . '" style="color: #5cb85c;"><i class="fa fa-check"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.approve'] . '</a>' . '&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments-editComment?id=' . $comment_ID . '" style="color: #5bc0de;"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.edit'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=unapprove&id=' . $comment_ID . '" style="color: #f0ad4e;"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.pending'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . $GLOBALS['url'] .'/control_panel/comments?action=remove&id=' . $comment_ID . '" style="color: #d9534f;"><i class="fa fa-trash"></i>&nbsp;&nbsp;' . $lang['admin.form.select.option.remove'] . '</a>';
			}
			$comment_date = $row_members['comment_date'];
		    $members_list .= '
		        <tr>
				    <td><input type="checkbox" name="checkbox[]" value="' . $comment_ID . '"></td>
			        <td>#' . $comment_ID . '</td>				
					<td><a href="' . $GLOBALS['url'] .'/control_panel/comments-editComment?id=' . $comment_ID . '">' . pc_get_post_title($comment_post_ID) . '</a></td>
					<td><a href="' . $GLOBALS['url'] .'/control_panel/members-editMember?id=' . $comment_user_ID_copy . '"><i>' . $comment_user_ID . '</i></a></ti>
					
					<td>
					    ' . $comment_content . '
						<br>
						<br>
						' . $comment_actions . '
				    </td>
					<td style="text-align: center;"><span class="label ' . $status_style . '">' . $comment_approved . '</span></td>
					<td style="text-align: center;">' . date_function($comment_date, "date") . '</td>
				</tr>
		    ';
	    }
	    $members_list .= '
	                </tbody>
			    </table>
		    </div>
			</form>
	    ';
	}else{
		$members_list = '<div class="alert alert-warning" role="alert">' . $lang['alert.comments.nocomments'] . '</div>';
	}
}




if(isset($_GET['status']) != ''){
	$back_stauts = $_GET['status'];
	// New Comment Added
	if($back_stauts == 'success'){
	    $message = '<div class="alert alert-success" role="alert">' . $lang['admin.newcomment.alert.success'] . '</div>';
    }
	// Comment Deleted
	if($back_stauts == 'deleted'){
	    $message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcomment.alert.commentdelete.success'] . '</div>';
    }
}



?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.comments.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.comments.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
            <li class="active"><i class="fa fa-comments"></i>&nbsp;&nbsp;<?php echo $lang['admin.comments.title']; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
		<div class="panel panel-default">
            <div class="panel-heading heading-white">
			    <h3 class="panel-title"><i class="fa fa-comments"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.comments.title']; ?></b></h3>
			</div>
            <div class="panel-body">
			    <a href="<?php echo $GLOBALS['url']; ?>/control_panel/comments-newComment"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.newcomment']; ?></button></a>
				<br/>
				<br/>
				<div class="row">
					<div class="col-xs-6">
						<h3 style="margin-top: 2px;margin-bottom: 0px;"><?php echo $num_rows; ?>&nbsp;<?php echo $lang['admin.comments.title']; ?></h3>
					</div>
                    <div class="col-xs-6" style="text-align: right;">
					    <form class="form-inline" action="<?php echo $GLOBALS['url']; ?>/control_panel/comments" method="post">
						    <div class="form-group">
                                <input type="text" class="form-control input-sm" placeholder="<?php echo $lang['admin.form.placeholder.search'] ; ?>" name="post_value" value="<?php echo $post_username; ?>">
                            </div>
							<button type="submit" class="btn <?php echo $admin_theme_btn; ?> btn-sm"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.search']; ?></button>
						</form>
				    </div>
				</div>
				<hr>
                <br>
	            <?php echo $members_list; ?>
                                 <br/>
                                 <?php
								     if($num_rows > 0){
										 echo '
                                             <div class="row">
                                                 <div class="col-xs-6">
                                                     <div style="width: 200px;">
                                                         <form class="form-inline" action="' . $GLOBALS['url'] . '/control_panel/comments" method="get">
														     <div class="form-group">
                                                                 <select class="form-control input-sm" name="n">
                                                                 <option value="' . $page_rows . '">' . $page_rows . '</option>
                                                                 <option value="25">25</option>
                                                                 <option value="50">50</option>
                                                                 <option value="100">100</option>
                                                                 <option value="250">250</option>
                                                                 </select>
															 </div>
															 <button type="submit" class="btn ' . $admin_theme_btn . ' btn-sm">' . $lang['admin.form.button.show'] . '</button>
                                                         </form>
                                                     </div>
                                                 </div>
                                                 <div class="col-xs-6" style="text-align: right">
                                                     ';
												if($num_rows > $page_rows){
												    echo $paginationCtrls;
									            } 
												echo '
                                                 </div>
                                             </div>
								         ';
                                     }
                                 ?>
						    </div>
						</div>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
</body>
</html>