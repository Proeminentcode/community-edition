<?php


// DEFINE VALID
define("_VALID","Yes");


// VARIABLES
$message = '';


// CONFIG
include_once("../include/config/config.php");
include_once("../include/traffic/traffic.php");


// CHECK ADMIN STATUS
if($admin_status == true){
     header("location: " . $GLOBALS['url']. "/control_panel/home");
	exit();	
}

include_once("../include/languages/en_US.lang.php");



// AJAX CALLS THIS CODE TO EXECUTE
if(isset($_POST["email"])){
	if($_POST["email"] != ""){
	    $e = $mysqli->real_escape_string($_POST['email']);
	    $sql = $mysqli->query("SELECT admin_ID, admin_username FROM pc_admin WHERE admin_email='$e' AND admin_status='1' LIMIT 1");
	    if($sql === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.login.unexistingemail'] . '</div>';
		}else{
			$numrows = $sql->num_rows;
	        if($numrows > 0){
		        while($row = $sql->fetch_assoc()){
			        $id = $row["admin_ID"];
			        $u = $row["admin_username"];
		        }
		        $emailcut = substr($e, 0, 4);
		        $randNum = rand(10000,99999);
		        $tempPass = "$emailcut$randNum";
		        $hashTempPass = md5($tempPass);
		        $sql = $mysqli->query("UPDATE pc_admin SET admin_recover_password='$hashTempPass' WHERE admin_ID='$id' LIMIT 1");
		        $to = "$e";
		        $from = $GLOBALS['auto_email'];
		        $headers ="From: $from\n";
		        $headers .= "MIME-Version: 1.0\n";
		        $headers .= "Content-type: text/html; charset=iso-8859-1 \n";
		        $subject = $lang['email.admin.resetpassword.subject'];
		        $msg = 
			        $lang['email.admin.resetpassword.part1'] . '' . $u . '' . 
				    $lang['email.admin.resetpassword.part2'] . '' . $tempPass . '' . 
				    $lang['email.admin.resetpassword.part3'] . '<a href="' . $GLOBALS['url'] . '/control_panel/admin-lostPass?u='.$u.'&p='. $hashTempPass . '">' . '' . $GLOBALS['url'] . '/control_panel/admin-lostPass?u='.$u.'&p='. $hashTempPass . '' . '</a>' .
				    $lang['email.admin.resetpassword.part4']
			    ;
		        if(mail($to,$subject,$msg,$headers)) {
			        $message = '<div class="alert alert-success" role="alert">' . $lang['alert.login.success.resetpass'] . '</div>';
	    	    }else{
			        $message = '<div class="alert alert-danger" role="alert">' . $lang['alert.login.crash.recoveremail'] .'</div>';
		        }
            }else{
                $message = '<div class="alert alert-danger" role="alert">' . $lang['alert.login.unexistingemail'] . '</div>';
            }
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.login.noemail'] . '</div>';
	}
}

// EMAIL LINK CLICK CALLS THIS CODE TO EXECUTE
if(isset($_GET['u']) && isset($_GET['p'])){
	$u = $mysqli->real_escape_string($_GET['u']);
	$temppasshash = $mysqli->real_escape_string($_GET['p']);
	if(strlen($temppasshash) < 10){
		exit();
	}
	$sql = $mysqli->query("SELECT admin_ID FROM pc_admin WHERE 	admin_username='$u' AND 	admin_recover_password='$temppasshash' AND admin_status='1' LIMIT 1");
	if($sql === FALSE){
		$message = '<div class="alert alert-warning" role="danger">' . $lang['alert.forgotpass.invalid'] . '</div>';
	}else{
		$numrows = $sql->num_rows;
	    if($numrows == 0){
		$message = '<div class="alert alert-warning" role="danger">' . $lang['alert.forgotpass.invalid'] . '</div>';
	    }else{
		    while($row = $sql->fetch_assoc()){
		    $id = $row["admin_ID"];
		    $sql = $mysqli->query("UPDATE pc_admin SET admin_password='$temppasshash' WHERE admin_ID='$id' AND admin_username='$u' LIMIT 1");
		    $sql = $mysqli->query("UPDATE pc_admin SET admin_recover_password='' WHERE admin_username='$u' LIMIT 1");
	        header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
            exit();
		    }
        }
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $lang['admin.forgotpass.title']; ?></title>
<link href="<?php echo $GLOBALS['url'] ?>/assets/bootstrap/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/control_panel/css/dashboard.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/control_panel/css/login.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/assets/fontawesome/fontawesome-4.6.3/css/font-awesome.css" rel="stylesheet">
<script src="<?php echo $GLOBALS['url'] ?>/assets/js/jquery-3.1.0.min.js"></script>
<link rel="shortcut icon" href="<?php echo $GLOBALS['url'] ?>/control_panel/favicon.ico">
</head>
<body>
   <!-- Start Log In Container -->
    <div class="container" style="max-width: 400px;">
        <div class="log-header">
            <img src="<?php echo $GLOBALS['url'] ?>/assets/images/Proeminent_Code_140x140_blue.png" width="100" title="Proeminent Code" alt="Proeminent Code">
        </div>
        <?php echo $message; ?>
	    <div class="panel panel-default">
            <div class="panel-body">
		        <form action="<?php echo $GLOBALS['url'] ?>/control_panel/admin-lostPass" method="post">
			        <h1 style="text-align: center;"><?php echo $lang['admin.forgotpass.title']; ?></h1>
				    <br/>
                    <div class="form-group">
                        <label><?php echo $lang['admin.form.label.email']; ?></label>
                        <input type="email" name="email" class="form-control" id="security_code" autocomplete="off" maxlentgh="255">
                    </div>
                    <div class="form-group">
                        <span id="status"></span>
                    </div>
                    <button type="submit" class="btn btn-info"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.button.resetpass']; ?></button>
                </form>
		    </div>
        </div>
        <div class="bottom-login">
            <p><a href="<?php echo $GLOBALS['url']; ?>/control_panel/admin-login"><?php echo $lang['admin.forgotpass.link.backlogin']; ?></a></p>
        </div>
	</div>
    <!-- End Log In Container -->
</body>
</html>