<?php


define("_VALID","Yes");

include_once("../include/config/config.php");
include_once("../include/traffic/traffic.php");
$_SESSION['idx'] = preg_replace('#[^0-9]#', '', $_COOKIE['idy']);
$session_id = $_SESSION['idx'];


$_SESSION = array();
if(isset($_COOKIE["idy"]) && isset($_COOKIE["usery"]) && isset($_COOKIE["passy"])) {
	setcookie("idy", '', strtotime( '-5 days' ), '/', '');
    setcookie("usery", '', strtotime( '-5 days' ), '/', '');
	setcookie("passy", '', strtotime( '-5 days' ), '/', '');
	$_COOKIE["idy"] = '';
	$_COOKIE["usery"] = '';
	$_COOKIE["passy"] = '';
}


unset($_SESSION['idx']);
unset($_SESSION['userx']);
unset($_SESSION['passx']);


if(isset($_SESSION['userx'])){
	session_destroy();
	header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();
}else{
	header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();
} 

?>