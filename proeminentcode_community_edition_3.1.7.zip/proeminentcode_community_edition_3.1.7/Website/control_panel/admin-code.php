<?php


// DEFINE VALID
define("_VALID","Yes");


// VARIABLES
$message = '';


// CONFIG
include_once("../include/config/config.php");
include_once("../include/traffic/traffic.php");


// CHECK ADMIN STATUS
if($admin_status == true){
     header("location: " . $GLOBALS['url']. "/control_panel/home");
	exit();	
}


include_once("../include/languages/en_US.lang.php");



$email_security = '';
if(isset($_COOKIE['emailSecurityVF']) != ''){
    $email_security = $mysqli->real_escape_string($_COOKIE['emailSecurityVF']);
}else{
	header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}

// VALIDATE SECURITY CODE
$login_error = '';
if(isset($_POST['security_code'])){
	if($_POST['security_code'] != ""){
	    $security_code = $mysqli->real_escape_string($_POST['security_code']);
		$sql_login = "SELECT * FROM pc_admin WHERE admin_email='$email_security' AND admin_security_code='$security_code' AND admin_status='1' LIMIT 1";
	    $query_login = $mysqli->query($sql_login);
	    if($query_login === FALSE){
			$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.verification.wrong'] . '</div>';
	    }else{		    
			$count_login = $query_login->num_rows;
			if($count_login == 1){
		        $row_login = $query_login->fetch_assoc();
				$id_login = $row_login['admin_ID'];
			    $username_login = $row_login['admin_username'];
				$password_login = $row_login['admin_password'];
				$ip_address = getenv('REMOTE_ADDR');
				$ip_address = preg_replace('#[^A-Za-z0-9.]#', '', $ip_address);
				$ip_address = $mysqli->real_escape_string($ip_address);
			    $sql_securityCode = "UPDATE pc_admin SET admin_security_code='', 	admin_last_IP='$ip_address', admin_last_log=now() WHERE admin_username='$username_login' AND admin_password='$password_login' AND admin_status='1' LIMIT 1";
			    $query_securityCode = $mysqli->query($sql_securityCode);
			    if($query_securityCode === FALSE){
			         $message = '<div class="alert alert-danger" role="alert">' . $lang['alert.verification.crash'] . '</div>';
			    }else{
				
					
					$_SESSION['idx'] = $id_login;
			        $_SESSION['userx'] = $username_login;
			        $_SESSION['passx'] = $password_login;
			        setcookie("idy", $id_login, strtotime('+30 days'), "/", "", false, true);
			        setcookie("usery", $username_login, strtotime('+30 days'), "/", "", false, true);
			        setcookie("passy", $password_login, strtotime('+30 days'), "/", "", false, true);
					setcookie("emailSecurityVF", '', strtotime( '-5 days' ), '/', '');
					$_COOKIE["emailSecurityVF"] = '';
				    header("location: " . $GLOBALS['url'] . "/control_panel/home");
			        exit();			   
			    }
            }else{
				$message = '<div class="alert alert-danger" role="alert">' . $lang['alert.verification.wrong'] . '</div>';
			}	
	    }
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['alert.verification.empty'] . '</div>';
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $lang['admin.verification.title']; ?></title>
<link href="<?php echo $GLOBALS['url'] ?>/assets/bootstrap/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/control_panel/css/dashboard.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/control_panel/css/login.css" rel="stylesheet">
<link href="<?php echo $GLOBALS['url'] ?>/assets/fontawesome/fontawesome-4.6.3/css/font-awesome.css" rel="stylesheet">
<script src="<?php echo $GLOBALS['url'] ?>/assets/js/jquery-3.1.0.min.js"></script>
<link rel="shortcut icon" href="<?php echo $GLOBALS['url'] ?>/control_panel/favicon.ico">
</head>
<body>
   <!-- Start Log In Container -->
    <div class="container" style="max-width: 400px;">
        <div class="log-header">
            <img src="<?php echo $GLOBALS['url'] ?>/assets/images/Proeminent_Code_140x140_blue.png" width="100" title="Proeminent Code" alt="Proeminent Code">
        </div>
        <?php echo $message; ?>
	    <div class="panel panel-default">
            <div class="panel-body">
		        <form action="<?php echo $GLOBALS['url'] ?>/control_panel/admin-code" method="post">
			        <h1 style="text-align: center;"><?php echo $lang['admin.verification.title']; ?></h1>
				    <br/>
                    <div class="form-group">
                        <label for="username"><?php echo $lang['admin.form.label.securitycode']; ?></label>
                        <input type="text" name="security_code" class="form-control" id="security_code" autocomplete="off" maxlentgh="6">
                    </div>
                    <button type="submit" class="btn btn-info"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.button.validatecode']; ?></button>
                </form>
		    </div>
        </div>
        <div class="bottom-login">
            <p>&nbsp;</p>
        </div>
	</div>
    <!-- End Log In Container -->
</body>
</html>