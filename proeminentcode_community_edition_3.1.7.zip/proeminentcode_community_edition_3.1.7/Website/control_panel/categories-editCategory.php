<?php



define("_VALID","Yes");


$message = '';


// CONFIG
include_once("../include/config/config.php");


// CHECK ADMIN STATUS
if($admin_status == false){
     header("location: " . $GLOBALS['url'] . "/control_panel/admin-login");
	exit();	
}


// GET ADMIN SETTINGS
include_once("scripts/admin-settings.php");



// VARIABLES
$category_ID = '';
$category_name = '';
$category_parent = '';
$category_url = '';
$category_content = '';
$category_thumbnail_image = '';
$category_thumbnail_source = '';
$category_banner_image = '';
$category_banner_source = '';
$category_sidebar = '';
$category_sidebar_ID = '';
$category_status = '';
$category_update = '';
$category_date = '';
if(isset($_GET['id'])){
	$category_ID = $_GET['id'];
	$category_ID = preg_replace('#[^0-9]#i', '', $category_ID);
	$sql_categoryInfo = "SELECT * FROM pc_products_categories WHERE category_ID='$category_ID' LIMIT 1";
	$query_categoryInfo = $mysqli->query($sql_categoryInfo);
	if($query_categoryInfo === FALSE){
		header("location:  " . $GLOBALS['url']. "/control_panel/categories");
	    exit();	
	}else{
		$count_categoryInfo = $query_categoryInfo->num_rows;
		if($count_categoryInfo > 0){
			// START ACTIONS
			$action = '';
			if(isset($_GET['action'])){
				$action = $_GET['action'];
				// START REMOVE THUMB
			    if($action == 'thumbnail'){
				    if($admin_power != 'viewer'){
				        $sql_removeThumb = "UPDATE pc_products_categories SET category_thumbnail='' WHERE category_ID='$category_ID' LIMIT 1";
				        $query_removeThumb = $mysqli->query($sql_removeThumb);
				        if($query_removeThumb === FALSE){
					        $message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcategory.alert.categorytumbnail.crash'] . '</div>';
				        }else{
					        header("location: " . $GLOBALS['url'] . "/control_panel/categories-editCategory?id=$category_ID&update=thumb");
					        exit();
				        }
				    }else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			    }
			    // END REMOVE THUMB
			    // START REMOVE BANNER
			    if($action == 'banner'){
				    if($admin_power != 'viewer'){
				        $sql_removeThumb = "UPDATE pc_products_categories SET category_banner='' WHERE category_ID='$category_ID' LIMIT 1";
				        $query_removeThumb = $mysqli->query($sql_removeThumb);
				        if($query_removeThumb === FALSE){
					        $message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcategory.alert.categorybanner.crash'] . '</div>';
				        }else{
					        header("location: " . $GLOBALS['url'] . "/control_panel/categories-editCategory?id=$category_ID&update=banner");
					        exit();
				        }
				    }else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			    }
				// END REMOVE BANNER
				// START DELETE BRAND
			    if($action == 'delete'){
				if($admin_power != 'viewer'){
					$sql_productRemove = "DELETE FROM pc_products_categories WHERE category_ID='$category_ID' LIMIT 1";
					$query_productRemove = $mysqli->query($sql_productRemove);
					if($query_productRemove === FALSE){
						$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcategory.alert.categorydelete.crash'] . '</div>';
					}else{
						header("location:  " . $GLOBALS['url'] . "/control_panel/categories?status=deleted");
                        exit();
					}
				}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			    }
			    // END DELETE BRAND
			}
			// END ACTIONS
			// START CATEGORY INFO
			$row_categoryInfo = $query_categoryInfo->fetch_assoc();	
			$category_ID = $row_categoryInfo['category_ID'];
			$category_parent = $row_categoryInfo['category_parent'];
			$category_url = $row_categoryInfo['category_url'];
			if($category_parent != '' && $category_parent != ' ' && $category_parent != 0){
				$sql_getParent = "SELECT category_ID, category_name FROM pc_products_categories WHERE category_ID='$category_parent' LIMIT 1";
				$query_getParent = $mysqli->query($sql_getParent);
				if($query_getParent === FALSE){
					$category_parent = '';
				}else{
					$count_getParent = $query_getParent->num_rows;
					if($count_getParent > 0){
						$row_getParent = $query_getParent->fetch_assoc();
						$parent_ID = $row_getParent['category_ID'];
						$category_name = $row_getParent['category_name'];
						$category_parent = '<option value="' . $parent_ID . '">' . $category_name . '</option>';
					}else{
						$category_parent = '';
					}
				}
			}else{
				$category_parent = '';
			}
			$category_name = $row_categoryInfo['category_name'];
			$category_thumbnail_source = $row_categoryInfo['category_thumbnail'];
			if($category_thumbnail_source != '' && $category_thumbnail_source != ' '){
				if(file_exists("../" . $category_thumbnail_source)){
					$category_thumbnail_image = '<div style="max-width: 200px;"><img src="' . $GLOBALS['url'] . '/' . $category_thumbnail_source . '" width="100%"></div>';
				}
			}else{
				$category_thumbnail_image = '';
			} 
			$category_banner_source = $row_categoryInfo['category_banner']; 
			if($category_banner_source != '' && $category_banner_source != ' '){
				if(file_exists("../" . $category_banner_source)){
					$category_banner_image = '<div style="max-width: 200px;"><img src="' . $GLOBALS['url'] . '/' . $category_banner_source . '" width="100%"></div>';
				}
			}else{
				$category_banner_image = '';
			}
			$category_sidebar = pc_get_sidebar_display_option($row_categoryInfo['category_sidebar'], $lang['admin.form.select.option.left'], $lang['admin.form.select.option.right'], $lang['admin.form.select.option.none']);;
			$category_sidebar_ID = pc_get_sidebar_name_option($row_categoryInfo['category_sidebar_ID']);
			$category_content = $row_categoryInfo['category_content'];
			// Decrypt Site Url
			$category_content = pc_dynamic_site_url_decrypt($category_content);
			$content_insurance = $category_content;
			$category_status = $row_categoryInfo['category_status'];
			if($category_status == 'p'){
				$category_status = '<option value="p">' . $lang['admin.form.select.option.public'] . '</option>';
			}else{
				$category_status = '<option value="p">' . $lang['admin.form.select.option.unpublished'] . '</option>';
			} 
			$category_update = $row_categoryInfo['category_update'];
			if($category_update != '' && $category_update != ' '){
				$category_update = date_function($category_update, 'datetime');	
				$category_update = '
				    <div class="form-group">
                                <label>' . $lang['admin.table.th.update'] . '</label>
                                <br>
								' . $category_update . '
                    </div>
				';							
			}
			$category_date = date_function($row_categoryInfo['category_date'], 'datetime');
			$category_products = 0;
			$sql_used = "SELECT product_category FROM pc_products";
			$query_used = $mysqli->query($sql_used);
			if($query_used === FALSE){
				$category_products = 0;
			}else{
				$count_used = $query_used->num_rows;
				if($count_used > 0){
				    while($row_used = $query_used->fetch_assoc()){
						$product_category = $row_used['product_category'];
						$product_category_items = explode(",", $product_category);
						foreach($product_category_items as $i =>$key){
							if($category_ID == $key){
								$category_products = $category_products + 1;
							}
						}
					}
				}else{
					$category_products = 0;
				}
			}
			// START CATEGORY URL UPDATE
			$edit_product_url = '';
			if(isset($_POST['category_url'])){
				if($admin_power != 'viewer'){
				$edit_product_url = $_POST['category_url'];
				if($edit_product_url != ' ' && $edit_product_url != ''){
				if(strlen($edit_product_url) < 256){
				    $edit_product_url_Copy = $edit_product_url;
					if($edit_product_url_Copy == $edit_product_url){
				        $edit_product_url = strtolower($edit_product_url);
		                $edit_product_url = preg_replace('#[^A-Za-z0-9- ]#i', '', $edit_product_url);
		                $edit_product_url = str_replace(' ', '-', $edit_product_url);
		                $edit_product_url = $mysqli->real_escape_string($edit_product_url);
		                $url_product_check = false;
						$sql_check_productLink = "SELECT category_ID FROM pc_products_categories WHERE category_url='$edit_product_url' AND category_ID<>'$category_ID' LIMIT 1";
						$query_check_productLink = $mysqli->query($sql_check_productLink);
						if($query_check_productLink === FALSE){
							$url_product_check = false;
						}else{
							$count_check_productLink = $query_check_productLink->num_rows;
							if($count_check_productLink > 0 ){
								$url_product_check = true;
							}else{
								$url_product_check = false;
							}
						}
						if($url_product_check == false){
							$sql_updateLink = "UPDATE pc_products_categories SET category_url='$edit_product_url' WHERE category_ID='$category_ID' LIMIT 1";
							
							$query_updateLink = $mysqli->query($sql_updateLink);
							if($query_updateLink === FALSE){
								$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.editcategory.alert.categoryurl.crash'] . '</div>';
							}else{
								header("location: " . $GLOBALS['url'] . "/control_panel/categories-editCategory?id=$category_ID&update=link");
			                exit();
							}
						}else{
							$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editcategory.alert.categoryurl.vali'] . '</div>';
						}
					}else{
						$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editcategory.alert.categoryurl.char'] . '</div>';
					}
			    }else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editcategory.alert.categoryurl.len'] . '</div>';
				}
				}else{
					$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.editcategory.alert.categoryurl.empty'] . '</div>';
				}
				}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
			}
			// END CATEGORY URL UPDATE
			// END CATEGORY INFO
			// START UPDATE CATEGORY INFO
			$post_category_name = '';
$post_category_url = '';
$post_category_content = '';
$post_category_status = '';
$post_category_parent = '';
$category_thumbnail = '';
$category_banner = '';
$post_category_sidebar = '';
$post_category_sidebar_ID = '';
if(isset($_POST['category_name'])){
	if($admin_power != 'viewer'){
	// Get Variables
	$x = 0;
	$post_category_name = $_POST['category_name'];
    $post_category_content = $_POST['category_content'];
    $post_category_status = $_POST['category_status'];
	$post_category_parent = $_POST['category_parent'];
	$post_category_sidebar = $_POST['category_sidebar'];
    $post_category_sidebar_ID = $_POST['category_sidebar_ID'];
	// Category Name | Count 1
	if($post_category_name != '' && $post_category_name != ' '){
		if(strlen($post_category_name) < 101){
			$post_category_name_copy = $post_category_name;
			$post_category_name_copy = strip_tags($post_category_name_copy);
			$post_category_name_copy = stripslashes($post_category_name_copy);
			if($post_category_name == $post_category_name_copy){
				$post_category_name = $mysqli->real_escape_string($post_category_name);
				$post_category_name = str_replace("'", "&#39;", $post_category_name);
				$x = $x + 1; 
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categoryname.charproblem'] . '</div>';
			}
	    }else{
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categoryname.len'] . '</div>';
		}
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categoryname.empty'] . '</div>';
	}
	
	
	// Category Parent | Count 2
	if($post_category_parent != '' && $post_category_parent != ' '){
		$post_category_parent = preg_replace('#[^0-9]#i', '', $post_category_parent);
		$post_category_parent = $mysqli->real_escape_string($post_category_parent);
		$sql_checkCategoryAv = "SELECT * FROM pc_products_categories WHERE category_ID='$post_category_parent' LIMIT 1";
		$query_checkCategoryAv = $mysqli->query($sql_checkCategoryAv);
		if($query_checkCategoryAv === FALSE){
			$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.parentcategory.wrong'] . '</div>';
		}else{
			$count_checkCategoryAv = $query_checkCategoryAv->num_rows;
			if($count_checkCategoryAv > 0){
				$x = $x + 1;
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.parentcategory.wrong'] . '</div>';
			}
		}
	}else{
		$x = $x + 1;
		$post_category_parent = 0;
	}
	
	
	// Category Content | Count 3
	if(strlen($post_category_content) < 4294967296){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorycontent.len'] . '</div>';
	}
	
	
	// Category Status | Count 4
	if($post_category_status == 'p' || $post_category_status == 'u'){
		$x = $x + 1;
	}else{
		$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorystatus.wrong'] . '</div>';
	}
	
	
	// Category Thumb | Count 5
	$tumb = false;
	if($_FILES['category_thumbnail']['tmp_name'] != ""){
		if($_FILES['category_thumbnail']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.filesize'] . '</div>';
            unlink($_FILES['category_thumbnail']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['category_thumbnail']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.filename'] . '</div>';
            unlink($_FILES['category_thumbnail']['tmp_name']); 	
        }else{
			
			// Find extension
			$tumbnail_extension = '';
			$tumbnail_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['category_thumbnail']['name'])){
				$tumbnail_extension = '.gif';
				$tumbnail_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['category_thumbnail']['name'])){
		        $tumbnail_extension = ".jpg";
		        $tumbnail_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['category_thumbnail']['name'])){
		        $tumbnail_extension = ".png";
		        $tumbnail_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['category_thumbnail']['name'])){
		        $tumbnail_extension = ".jpeg";
		        $tumbnail_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.filename'] . '</div>';
			}
			$tumb_name = $_FILES['category_thumbnail']['name'];
			if(strlen($tumb_name) > 1000){
				$tumb_name = substr($tumb_name, 0, 950);
			}
			
			$tumb_name = strip_tags($tumb_name);
			$tumb_name = stripslashes($tumb_name);
			$tumb_name = str_replace('-', '_', $tumb_name);
			$tumb_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $tumb_name);
			$tumb_name = str_replace(' ', '-', $tumb_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $tumb_name)){
				$tumb_name = $tumb_name . $tumbnail_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$tumb_name_copy = str_replace($extension_Array, $extension_Array_replace, $tumb_name);
				while($file_checky == true){
					$tumb_name = $tumb_name_copy . "_" . $c . $tumbnail_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $tumb_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["category_thumbnail"]["size"];
			if(move_uploaded_file($_FILES['category_thumbnail']['tmp_name'], "../uploads/media/$media_path/$tumb_name")){
	            $tumb_name = $mysqli->real_escape_string($tumb_name);
				$sql_addTumbMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$tumb_name ','$tumb_name','$tumbnail_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$tumb = true;
				$category_thumbnail_source = "uploads/media/$media_path/$tumb_name";
	            $category_thumbnail_source = $mysqli->real_escape_string($category_thumbnail_source);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorythumb.crash'] . '</div>';
			}
			
		}		
	}else{
		$x = $x + 1;
	}
	
	
	// Brand Banner | Count 6
	$banner = false;
	if($_FILES['category_banner']['tmp_name'] != ""){
		if($_FILES['category_banner']['size'] > $GLOBALS['websiteSetting_image_size']){ 
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorytbanner.filesize'] . '</div>';
            unlink($_FILES['category_banner']['tmp_name']); 
        }else if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $_FILES['category_banner']['name'])){
		    $message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorybanner.filename'] . '</div>';
            unlink($_FILES['brand_banner']['tmp_name']); 	
        }else{
			
			// Find extension
			$banner_extension = '';
			$banner_type = '';
			if(preg_match("/\.(gif)$/i", $_FILES['category_banner']['name'])){
				$banner_extension = '.gif';
				$banner_type = 'GIF Image';
			}else if(preg_match("/\.(jpg)$/i", $_FILES['category_banner']['name'])){
		        $banner_extension = ".jpg";
		        $banner_type = 'JPG Image';
	        }else if(preg_match("/\.(png)$/i", $_FILES['category_banner']['name'])){
		        $banner_extension = ".png";
		        $banner_type = 'PNG Image';
	        }else if(preg_match("/\.(jpeg)$/i", $_FILES['category_banner']['name'])){
		        $banner_extension = ".jpeg";
		        $banner_type = 'JPEG Image';
		    }else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorybanner.filename'] . '</div>';
			}
			$banner_name = $_FILES['category_banner']['name'];
			if(strlen($banner_name) > 1000){
				$banner_name = substr($banner_name, 0, 950);
			}
			
			$banner_name = strip_tags($banner_name);
			$banner_name = stripslashes($banner_name);
			$banner_name = str_replace('-', '_', $banner_name);
			$banner_name = preg_replace('#[^A-Za-z0-9._ ]#i', '', $banner_name);
			$banner_name = str_replace(' ', '-', $banner_name);
			if(!preg_match("/\.(gif|jpg|jpeg|png)$/i", $banner_name)){
				$banner_name = $banner_name . $banner_extension;
			}
			
			$current_year = date("Y");
            $current_month = date("m");
            $current_day = date("d");
			
            // Year
            if(file_exists('../uploads/media/' . $current_year)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year", 0777);
	            $new_index = fopen("../uploads/media/$current_year/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Month
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            // Day
            if(file_exists('../uploads/media/' . $current_year . '/' . $current_month . '/' . $current_day)){
	            // ok
            }else{
	            mkdir("../uploads/media/$current_year/$current_month/$current_day", 0777);
	            $new_index = fopen("../uploads/media/$current_year/$current_month/$current_day/index.php", "w");
	            $txt = "<?php\n";
	            fwrite($new_index, $txt);
	            $txt = 'header("location: ../index.php");\n';
	            fwrite($new_index, $txt);
	            $txt = '?>\n';
	            fwrite($new_index, $txt);
	            fclose($new_index);
            }

            $media_path = "$current_year/$current_month/$current_day";
			
			if(file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
				$file_checky = true;
				$c = 2;
				$extension_Array = array('.gif', '.jpg', '.jpeg', '.png');
				$extension_Array_replace = array('', '', '', '');
				$banner_name_copy = str_replace($extension_Array, $extension_Array_replace, $banner_name);
				while($file_checky == true){
					$banner_name = $banner_name_copy . "_" . $c . $banner_extension;
					if(!file_exists("../uploads/media/" . $media_path . "/" . $banner_name)){
					    $file_checky = false;
					}else{
						$c = $c + 1;
					}
				}
			}
			
			$fileSize = $_FILES["category_banner"]["size"];
			if(move_uploaded_file($_FILES['category_banner']['tmp_name'], "../uploads/media/$media_path/$banner_name")){
	            $banner_name = $mysqli->real_escape_string($banner_name);
				$sql_addBannerMedia = "INSERT INTO pc_media(media_role, media_title, media_name, media_type, media_size, media_path,media_status, media_uploaded) VALUES('tumbnail','$banner_name ','$banner_name','$banner_type','$fileSize','$media_path','Public',now())";
				$x = $x + 1;
				$banner = true;
				$category_banner_source = "uploads/media/$media_path/$banner_name";
	            $category_banner_source = $mysqli->real_escape_string($category_banner_source);
			}else{
				$message = '<div class="alert alert-warning" role="alert">' . $lang['admin.newcategory.alert.categorybanner.crash'] . '</div>';
			}
			
		}	
	}else{
		$x = $x + 1;
	}
	
	
	if($x == 6){
		// Category URL
		$post_category_url = strtolower($post_category_name);
		$post_category_url = preg_replace('#[^A-Za-z0-9- ]#i', '', $post_category_url);
		$post_category_url = str_replace(' ', '-', $post_category_url);
		$post_category_url = $mysqli->real_escape_string($post_category_url);
		$post_category_url_check = false;
		$sql_categoryURL = "SELECT * FROM pc_products_categories WHERE category_url='$post_category_url' AND category_ID<>'$category_ID' LIMIT 1";
		$query_categoryURL = $mysqli->query($sql_categoryURL);
		if($query_categoryURL === FALSE){
			//
		}else{
			$count_categoryURL = $query_categoryURL->num_rows;
			if($count_categoryURL > 0 ){
				$post_category_url_check = true;
			}
		}
		if($post_category_url_check == true){
			$cp = 2;
			$check_url = true;
			while($check_url == true){
				
				$post_category_url_copy = $post_category_url . "-" . $cp;
				$post_category_url_copy = $mysqli->real_escape_string($post_category_url_copy);
				$sql_categoryURL = "SELECT category_name FROM pc_products_categories WHERE category_url='$post_category_url_copy' AND category_ID<>'$category_ID' LIMIT 1";
		        $query_categoryURL = $mysqli->query($sql_categoryURL);
		        if($query_categoryURL === FALSE){
			        $check_url = false;
		        }else{
					$count_categoryURL = $query_categoryURL->num_rows;
			        if($count_categoryURL > 0){
				        $check_url = true;
			        }else{
						$check_url = false;
					}
				}
				$cp = $cp + 1;
			}
			$post_category_url = $post_category_url_copy;
		}
		
		// Insurance for Content
	if($post_category_content == '' || $post_category_content == ' '){
	    $post_category_content = $content_insurance;
		$post_category_content = $mysqli->real_escape_string($post_category_content);
	}else{
		$post_category_content = htmlentities($post_category_content, ENT_QUOTES);
		$post_category_content = $mysqli->real_escape_string($post_category_content);
	}
	
	    // Crypt Site Url
		$post_category_content = pc_dynamic_site_url_crypt($post_category_content);
		
		
		// INSERT CATEGORY
		$sql_updateCategory = "UPDATE pc_products_categories SET category_parent='$post_category_parent', category_name='$post_category_name', category_url='$post_category_url', category_content='$post_category_content', category_thumbnail='$category_thumbnail_source', category_banner='$category_banner_source', category_status='$post_category_status', category_update=now(), category_sidebar='$post_category_sidebar', category_sidebar_ID='$post_category_sidebar_ID' WHERE category_ID='$category_ID' LIMIT 1";
		$query_addCategory = $mysqli->query($sql_updateCategory);
		if($query_addCategory === FALSE){
			// Crash
			$message = '<div class="alert alert-danger" role="alert">' . $lang['admin.newcategory.alert.crash'] . '</div>';
			// Decrypt Site Url
			$post_category_content = pc_dynamic_site_url_decrypt($post_category_content);
		}else{
			// Ok
			if($category_thumbnail != '' && $category_thumbnail != ' '){
			    $mysqli->query($sql_addTumbMedia);
			}
			if($category_banner != '' && $category_banner != ' '){
			     $mysqli->query($sql_addBannerMedia);
			}
			header("location: " . $GLOBALS['url'] . "/control_panel/categories-editCategory?id=" . $category_ID . "&update=success");
			exit();
		}
	}
	}else{
					$message = '<div class="alert alert-info" role="alert">' . $lang['admin.administrators.alert.nopower'] . '</div>';
				}
}
			// END UPDATE CATEGORY INFO
		}else{
			header("location:  " . $GLOBALS['url']. "/control_panel/categories");
	        exit();	
		}
	}
}else{
	header("location:  " . $GLOBALS['url']. "/control_panel/categories");
	exit();	
}

// GET CATEGORIES LIST
$categories_ordered = '';
$sql_getCategories = "SELECT * FROM pc_products_categories WHERE category_parent='0' ORDER BY category_name ASC";
$query_getCategories = $mysqli->query($sql_getCategories);
if($query_getCategories === FALSE){
	$categories_ordered = '<option>' . $lang['admin.categories.text.nocategories'] . '</option>';
}else{
	$count_getCategories = $query_getCategories->num_rows;
	if($count_getCategories > 0){
		while($row_getCategories = $query_getCategories->fetch_assoc()){
			$main_category_ID = $row_getCategories['category_ID'];
			$main_category_name = $row_getCategories['category_name'];
			$main_category_parent = $row_getCategories['category_parent'];
			$categories_ordered .= '<option value="' . $main_category_ID . '">' . $main_category_name . '</option>';	
			if($main_category_parent == '' || $main_category_parent == ' ' || $main_category_parent == 0){ 
				$categories_ordered .= pc_categories_childrens_option($main_category_ID);
			}
		}
	}else{
		$categories_ordered = '<option>' . $lang['admin.categories.text.nocategories'] . '</option>';
	}
}



// STATUS UPDATE
if(isset($_GET['update'])){
	$update_var = $_GET['update'];
	if($update_var == 'success'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcategory.alert.update.success'] . '</div>';
	}
	if($update_var == 'link'){
	    $message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcategory.alert.categoryurl.success'] . '</div>';	
	}
	if($update_var == 'thumb'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcategory.alert.categorytumbnail.success'] . '</div>';	
	}
	if($update_var == 'banner'){
		$message = '<div class="alert alert-success" role="alert">' . $lang['admin.editcategory.alert.categorybanner.success'] . '</div>';	
	}
}


// SIDEBARS LISTS
$sidebar_list = '';
$sql_sidebars = "SELECT sidebar_ID, sidebar_name FROM pc_sidebars ORDER BY sidebar_name";
$query_sidebars = $mysqli->query($sql_sidebars);
$count_sidebars = $query_sidebars->num_rows;
if($count_sidebars > 0){
	while($row_sidebars = $query_sidebars->fetch_assoc()){
		$sidebar_ID = $row_sidebars["sidebar_ID"];
		$sidebar_name = $row_sidebars["sidebar_name"];
		$sidebar_row = '<option value="' . $sidebar_ID . '">' . $sidebar_name . '</option>';
		$sidebar_list .= $sidebar_row;
	}
}else{
	//
}


?>
<?php include_once("tmp/tmp-header-meta.php"); ?>
<title><?php echo $lang['admin.editcategory.title']; ?></title>
<?php include_once("tmp/tmp-header-links.php"); ?>
</head>
<body>
<!-- START DELETE CATEGORY MODAL -->
<div class="modal fade" id="deleteCategory" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.button.deletecategory']; ?></h4>
            </div>
            <div class="modal-body">
                <p><?php echo $lang['admin.editbrand.alert.remove.confirm']; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <a href="<?php echo $GLOBALS['url']; ?>/control_panel/categories-editCategory?id=<?php echo $category_ID; ?>&action=delete"><button type="button" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletecategory']; ?></button></a>
            </div>
        </div>
    </div>
</div>
<!-- END DELETE CATEGORY MODAL -->
<!-- START EDIT CATEGORY LINK MODAL -->
<div class="modal fade" id="editCategoryLink" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/categories-editCategory?id=<?php echo $category_ID; ?>" method="post" enctype="multipart/form-data">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo $lang['admin.form.label.categorylink']; ?></h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label><?php echo $lang['admin.form.label.seolink']; ?></label>
                    <input type="text" name="category_url" class="form-control" maxlength="255" value="<?php echo $category_url; ?>" autocomplete="off">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.cancel']; ?></button>
                <button type="submit" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.save']; ?></button>
            </div>
        </div>
        </form>
    </div>
</div>
<!-- END EDIT CATEGORY LINK MODAL -->
    <div id="wrapper">
    <?php include_once("tmp/header.php"); ?>
    <?php include_once("tmp/aside.php"); ?>
	<div id="page-content-wrapper">
        <?php echo $message; ?>
		<h1><?php echo $lang['admin.editcategory.title']; ?></h1>
		<ol class="breadcrumb">
            <li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/home"><i class="fa fa-tachometer"></i>&nbsp;&nbsp;<?php echo $lang['admin.dashboard.title']; ?></a></li>
			<li><a href="<?php echo $GLOBALS['url']; ?>/control_panel/categories"><i class="fa fa-th-large"></i>&nbsp;&nbsp;<?php echo $lang['admin.categories.title']; ?></a></li>
            <li class="active"><i class="fa fa-pencil"></i>&nbsp;&nbsp;<?php echo $category_name; ?></li>
        </ol>
        <?php include_once("tmp/tmp-quickActions.php"); ?>
        <form action="<?php echo $GLOBALS['url']; ?>/control_panel/categories-editCategory?id=<?php echo $category_ID; ?>" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-sm-7 col-md-8">
		        <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-book"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.generalinfo']; ?></b></h3>
			        </div>
                    <div class="panel-body">
			            
							<div class="form-group">
								<label><?php echo $lang['admin.form.label.categoryname']; ?></label>
						        <input type="text" class="form-control" name="category_name" maxlength="100" autocomplete="off" value="<?php echo $category_name; ?>">  
							</div>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.parentcategory']; ?>&nbsp;&nbsp;<i class="fa fa-question-circle" style="color: #666666;" data-toggle="tooltip" data-placement="right" title="<?php echo $lang['admin.form.tooltip.parentcategory']; ?>"></i></label>
                                <select class="form-control" name="category_parent">
                                    <?php echo $category_parent; ?>
                                    <option></option>
                                    <?php echo $categories_ordered; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.categorylink']; ?></label>
						        <input type="text" class="form-control"  maxlength="1000" autocomplete="off" value="<?php echo $GLOBALS['url']; ?>/category/<?php echo $category_url; ?>" readonly> 
                            </div>
                            <a href="<?php echo $GLOBALS['url']; ?>/category/<?php echo $category_url; ?>" target="_blank"><?php echo $lang['admin.form.button.viewcategory']; ?></a>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="#" data-toggle="modal" data-target="#editCategoryLink"><?php echo $lang['admin.form.button.editlink']; ?></a>
                            <br>
                            <br>
                            <div class="form-group">
                                <label><?php echo $lang['admin.form.label.content']; ?></label>
                                <textarea id="descriptioneditor" class="form-control" name="category_content"></textarea>
                            </div>
                            <div class="form-group">
								<label><?php echo $lang['admin.form.label.status']; ?></label>
						        <select name="category_status" class="form-control">
                                    <?php echo $category_status; ?>
                                    <option value="p"><?php echo $lang['admin.form.select.option.public']; ?></option>
                                    <option value="u"><?php echo $lang['admin.form.select.option.unpublished']; ?></option>
                                </select>
							</div>
						
					</div>
			    </div>
            </div>
            <div class="col-sm-5 col-md-4">
                <!-- START STATISTICS -->
                    <div class="panel panel-default">
                        <div class="panel-heading heading-white">
					        <h3 class="panel-title"><i class="fa fa-signal"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.editcategory.text.categorystatistics']; ?></b></h3>
					    </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label><?php echo $lang['admin.table.th.products']; ?></label>
                                <br>
                                <?php echo $category_products; ?>
                            </div>
                            <?php echo $category_update; ?>
                            <div class="form-group">
                                <label><?php echo $lang['admin.table.th.date']; ?></label>
                                <br>
                                <?php echo $category_date; ?>
                            </div>
                        </div>
                    </div>    
                    <!-- END STATISTICS -->
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
			            <h3 class="panel-title"><i class="fa fa-picture-o"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.images']; ?></b></h3>
			        </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.tumbnail']; ?></label>
                            <input class="displayNone" multiple id="category_thumbnail" type="file" size="4" name="category_thumbnail" style="display: none;"><br>
							<button type="button" id="uploadButton0" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                        <?php echo $category_thumbnail_image; ?>
                        <?php
								    if($category_thumbnail_source != '' && $category_thumbnail_source != ' '){
										echo '<br><br><a href="' . $GLOBALS['url'] . '/control_panel/categories-editCategory?id=' . $category_ID . '&action=thumbnail">' . $lang['admin.form.button.removetumbnail'] . '</a><br><br>';
									}
						?>
                        <div class="form-group">
                            <label><?php echo $lang['admin.form.label.banner']; ?></label>
                            <input class="displayNone" multiple id="category_banner" type="file" size="4" name="category_banner" style="display: none;"><br><br>
							<button type="button" id="uploadButton2" class="btn <?php echo $admin_theme_btn; ?>"><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.chooseimage']; ?></button>
                        </div>
                        <?php echo $category_banner_image; ?>
                        <?php
								    if($category_banner_source != '' && $category_banner_source != ' '){
										echo '<br><br><a href="' . $GLOBALS['url'] . '/control_panel/categories-editCategory?id=' . $category_ID . '&action=banner">' . $lang['admin.form.button.removebanner'] . '</a>';
									}
						?>
                    </div>
                </div>
                <!-- START LAYOUT -->
                <div class="panel panel-default">
                    <div class="panel-heading heading-white">
					    <h3 class="panel-title"><i class="fa fa-paint-brush"></i>&nbsp;&nbsp;<b><?php echo $lang['admin.newproduct.text.layout']; ?></b></h3>
					</div>
                    <div class="panel-body" style="background: #f5f5f5;">
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarposition']; ?></label>
						        <select class="form-control" name="category_sidebar">  
                                    <?php echo $category_sidebar; ?>
								    <option value="right"><?php echo $lang['admin.form.select.option.right']; ?></option>
									<option value="left"><?php echo $lang['admin.form.select.option.left']; ?></option>
                                    <option value="none"><?php echo $lang['admin.form.select.option.none']; ?></option>
								</select>
                            </div>
                        <div class="form-group">
                                <label><?php echo $lang['admin.form.label.sidebarname']; ?></label>
						        <select class="form-control" name="category_sidebar_ID"> 
                                    <?php echo $category_sidebar_ID; ?> 
							        <?php echo $sidebar_list; ?>
								</select>
                            </div>
                    </div>
                </div>
                <!-- END LAYOUT -->
            </div>
        </div>
        <button type="submit" class="btn <?php echo $admin_theme_btn; ?>" style="margin-bottom: 10px;"><i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.savechanges']; ?></button>
        <a href="#" class="btn btn-default" style="margin-bottom: 10px;" data-toggle="modal" data-target="#deleteCategory"><i class="fa fa-trash"></i>&nbsp;&nbsp;<?php echo $lang['admin.form.button.deletecategory']; ?></a>
        </form>
        <br>
        <br>
		<?php include_once("tmp/footer.php"); ?>
		</div>    
	</div>					
    <?php include_once("tmp/tmp-footer-links.php"); ?>
    <script src="<?php echo $GLOBALS['url']; ?>/control_panel/include/summernote/summernote.js"></script>
     <script>
	    $(document).ready(function() {
            $('#descriptioneditor').summernote({
                height: 400,
	            callbacks: {
        onImageUpload : function(files, editor, welEditable) {

             for(var i = files.length - 1; i >= 0; i--) {
                     sendFile(files[i], this);
            }
        }
    }
            });
            function sendFile(file, el) {
var form_data = new FormData();
form_data.append('file', file);
$.ajax({
    data: form_data,
    type: "POST",
    url: 'saveimage.php',
    cache: false,
    contentType: false,
    processData: false,
    success: function(url) {
        $(el).summernote('editor.insertImage', url);
    }
});
}
<?php

$array_searchFilter = array("'", '\\', '`');
$array_replaceFilter = array("&#039", "&#092", "&#096");
$category_content = str_replace($array_searchFilter, $array_replaceFilter, $category_content);
$category_content = trim(preg_replace('/\s\s+/', ' ', $category_content));
$category_content = html_entity_decode($category_content);

?>
var markupStr = '<?php echo $category_content; ?>';
$('#descriptioneditor').summernote('code', markupStr);
        });
    </script>
<script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#category_thumbnail').html($('#category_thumbnail').val());
			};
			$('#uploadButton0').on('click', function(){
				$('#category_thumbnail').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
    <script>
	 $(document).ready(function(){
			var intervalFunc = function(){
				$('#category_banner').html($('#category_banner').val());
			};
			$('#uploadButton2').on('click', function(){
				$('#category_banner').click();
				setInterval(intervalFunc, 1);
				uploadFile();
				return false;
			});
		});
	</script>
</body>
</html>