-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Dec 20, 2016 at 11:54 AM
-- Server version: 5.6.33-cll-lve
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `proemine_product_communityEdition`
--

-- --------------------------------------------------------

--
-- Table structure for table `pc_admin`
--

CREATE TABLE IF NOT EXISTS `pc_admin` (
  `admin_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `admin_email` varchar(255) NOT NULL,
  `admin_username` varchar(30) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_recover_password` varchar(255) DEFAULT NULL,
  `admin_phone` varchar(30) DEFAULT NULL,
  `admin_security_code` varchar(6) DEFAULT NULL,
  `admin_power` enum('admin','editor','moderator','viewer') NOT NULL DEFAULT 'viewer',
  `admin_status` enum('1','0') NOT NULL DEFAULT '1',
  `admin_last_IP` varchar(100) DEFAULT NULL,
  `admin_last_log` datetime DEFAULT NULL,
  `admin_last_session` datetime DEFAULT NULL,
  `admin_last_session_IP` varchar(255) DEFAULT NULL,
  `admin_primary` enum('1','0') NOT NULL DEFAULT '1',
  `admin_date` datetime NOT NULL,
  PRIMARY KEY (`admin_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pc_admin`
--

INSERT INTO `pc_admin` (`admin_ID`, `admin_email`, `admin_username`, `admin_password`, `admin_recover_password`, `admin_phone`, `admin_security_code`, `admin_power`, `admin_status`, `admin_last_IP`, `admin_last_log`, `admin_last_session`, `admin_last_session_IP`, `admin_primary`, `admin_date`) VALUES
(1, 'contact@yourwebsite.com', 'Admin', '46eb65984383e4f91a7042d06a0184e5', '', '', '', 'admin', '1', '79.119.84.67', '2016-12-20 09:12:01', '2016-12-20 11:30:07', '79.119.84.67', '1', '2015-09-26 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_admin_settings`
--

CREATE TABLE IF NOT EXISTS `pc_admin_settings` (
  `setting_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `admin_ID` bigint(20) NOT NULL,
  `setting_language` varchar(20) NOT NULL DEFAULT 'en_US',
  `setting_login_validation` enum('Yes','No') NOT NULL DEFAULT 'No',
  `setting_theme` varchar(50) NOT NULL DEFAULT 'light-blue',
  `setting_update` datetime DEFAULT NULL,
  `setting_date` datetime NOT NULL,
  PRIMARY KEY (`setting_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pc_admin_settings`
--

INSERT INTO `pc_admin_settings` (`setting_ID`, `admin_ID`, `setting_language`, `setting_login_validation`, `setting_theme`, `setting_update`, `setting_date`) VALUES
(1, 1, 'en_US', 'No', 'light-blue', '2016-09-11 06:45:40', '2015-10-11 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_ads`
--

CREATE TABLE IF NOT EXISTS `pc_ads` (
  `ad_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ad_position` varchar(20) NOT NULL,
  `ad_banner` text,
  `ad_link` text,
  `ad_newtab` enum('1','0') NOT NULL DEFAULT '0',
  `ad_custom` text,
  `ad_status` enum('1','0') NOT NULL DEFAULT '0',
  `ad_update` datetime DEFAULT NULL,
  `ad_date` datetime NOT NULL,
  PRIMARY KEY (`ad_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pc_ads`
--

INSERT INTO `pc_ads` (`ad_ID`, `ad_position`, `ad_banner`, `ad_link`, `ad_newtab`, `ad_custom`, `ad_status`, `ad_update`, `ad_date`) VALUES
(1, 'top_banner', '', '', '0', '', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'bottom_banner', '', '', '0', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_banned`
--

CREATE TABLE IF NOT EXISTS `pc_banned` (
  `banned_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `banned_IP` varchar(39) NOT NULL,
  `banned_country` varchar(50) DEFAULT NULL,
  `banned_reason` varchar(255) DEFAULT NULL,
  `banned_update` datetime DEFAULT NULL,
  `banned_date` datetime NOT NULL,
  PRIMARY KEY (`banned_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_comments`
--

CREATE TABLE IF NOT EXISTS `pc_comments` (
  `comment_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `comment_reply_ID` varchar(20) DEFAULT NULL,
  `comment_post_ID` bigint(20) NOT NULL,
  `comment_user_ID` bigint(20) NOT NULL,
  `comment_user_IP` varchar(100) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_approved` enum('d','a','p') NOT NULL DEFAULT 'p',
  `comment_update` datetime DEFAULT NULL,
  `comment_date` datetime NOT NULL,
  PRIMARY KEY (`comment_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_coupons`
--

CREATE TABLE IF NOT EXISTS `pc_coupons` (
  `coupon_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `coupon_code` varchar(50) NOT NULL,
  `coupon_type` enum('a','p') NOT NULL DEFAULT 'p',
  `coupon_discount` varchar(20) NOT NULL,
  `coupon_times` varchar(20) DEFAULT NULL,
  `coupon_used` bigint(20) NOT NULL DEFAULT '0',
  `coupon_status` enum('1','0') NOT NULL DEFAULT '1',
  `coupon_expire` date DEFAULT NULL,
  `coupon_update` datetime DEFAULT NULL,
  `coupon_date` datetime NOT NULL,
  PRIMARY KEY (`coupon_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_errorsLogs`
--

CREATE TABLE IF NOT EXISTS `pc_errorsLogs` (
  `error_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `error_title` varchar(255) NOT NULL,
  `error_location` text NOT NULL,
  `error_SQL` text,
  `error_description` text NOT NULL,
  `error_IP` varchar(255) DEFAULT NULL,
  `error_status` enum('1','0') NOT NULL DEFAULT '0',
  `error_date` datetime NOT NULL,
  PRIMARY KEY (`error_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_gateways`
--

CREATE TABLE IF NOT EXISTS `pc_gateways` (
  `gateway_ID` int(3) NOT NULL AUTO_INCREMENT,
  `gateway_type` varchar(100) NOT NULL,
  `gateway_name` varchar(100) NOT NULL,
  `gateway_description` text,
  `gateway_email` varchar(255) DEFAULT NULL,
  `gateway_account` varchar(255) DEFAULT NULL,
  `gateway_secretWord` varchar(255) DEFAULT NULL,
  `gateway_var_1` varchar(255) DEFAULT NULL,
  `gateway_var_2` varchar(255) DEFAULT NULL,
  `gateway_var_3` varchar(255) DEFAULT NULL,
  `gateway_var_4` varchar(255) DEFAULT NULL,
  `gateway_var_5` varchar(255) DEFAULT NULL,
  `gateway_var_6` varchar(255) DEFAULT NULL,
  `gateway_sandbox` enum('1','0') NOT NULL DEFAULT '0',
  `gateway_status` enum('1','0') NOT NULL DEFAULT '1',
  `gateway_configured` enum('1','0') NOT NULL DEFAULT '0',
  `gateway_update` datetime DEFAULT NULL,
  `gateway_date` date NOT NULL,
  PRIMARY KEY (`gateway_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `pc_gateways`
--

INSERT INTO `pc_gateways` (`gateway_ID`, `gateway_type`, `gateway_name`, `gateway_description`, `gateway_email`, `gateway_account`, `gateway_secretWord`, `gateway_var_1`, `gateway_var_2`, `gateway_var_3`, `gateway_var_4`, `gateway_var_5`, `gateway_var_6`, `gateway_sandbox`, `gateway_status`, `gateway_configured`, `gateway_update`, `gateway_date`) VALUES
(1, 'paypal', 'PayPal', '', 'contact@yourwebsite.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '2016-10-20 16:04:19', '2015-08-24'),
(4, 'cashondelivery', 'Cash on Delivery', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '2016-06-02 05:21:13', '2015-08-24'),
(5, 'banktransfer', 'Bank Transfer', 'Wire transfer, bank transfer or credit transfer is a method of electronic funds transfer from one person or entity to another. A wire transfer can be made from one bank account to another bank account or through a transfer of cash at a cash office. Different wire transfer systems and operators provide a variety of options relative to the immediacy and finality of settlement and the cost, value, and volume of transactions.', NULL, NULL, NULL, 'Account Name', '#accountnumber', 'Bank Name', '#sortcode', 'IBANBANK0000000000000000', 'SWIFTCODE', '1', '1', '1', '2016-06-06 14:48:22', '2015-08-24'),
(6, '2checkout', '2Checkout', '2Checkout is a leading global payment platform that allows companies to accept online and mobile payments from buyers worldwide, with localized payment options. Capabilities include a pre-integrated payments gateway, merchant account, PCI compliance, international fraud prevention, and integration with more than 100 shopping carts. ', 'contact@yourwebsite.com', '0000000', 'PUTTHESECRETWORDHERE', NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '2016-10-20 15:19:57', '2015-10-01');

-- --------------------------------------------------------

--
-- Table structure for table `pc_languages`
--

CREATE TABLE IF NOT EXISTS `pc_languages` (
  `language_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(255) NOT NULL,
  `language_code` varchar(5) NOT NULL,
  `language_status` enum('1','0') NOT NULL DEFAULT '1',
  `language_update` datetime DEFAULT NULL,
  `language_date` datetime NOT NULL,
  PRIMARY KEY (`language_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pc_languages`
--

INSERT INTO `pc_languages` (`language_ID`, `language_name`, `language_code`, `language_status`, `language_update`, `language_date`) VALUES
(2, 'English', 'en_US', '1', NULL, '2016-05-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_languages_values`
--

CREATE TABLE IF NOT EXISTS `pc_languages_values` (
  `value_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `language_code` varchar(5) NOT NULL DEFAULT 'en_US',
  `value_name` varchar(255) NOT NULL,
  `value_content` text,
  `value_update` datetime DEFAULT NULL,
  `value_date` datetime NOT NULL,
  PRIMARY KEY (`value_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=344 ;

--
-- Dumping data for table `pc_languages_values`
--

INSERT INTO `pc_languages_values` (`value_ID`, `language_code`, `value_name`, `value_content`, `value_update`, `value_date`) VALUES
(1, 'en_US', 'website.global.login', 'Log In', NULL, '2016-05-11 00:00:00'),
(2, 'en_US', 'website.global.or', 'or', NULL, '2016-05-11 00:00:00'),
(3, 'en_US', 'website.global.signup', 'Sign Up', NULL, '2016-05-11 00:00:00'),
(4, 'en_US', 'website.post.text.toleaveacomment', 'to leave a comment.', NULL, '2016-05-11 00:00:00'),
(5, 'en_US', 'website.post.alert.nocomments', 'No comments found', NULL, '2016-05-11 00:00:00'),
(6, 'en_US', 'website.post.text.comments', 'Comments', NULL, '2016-05-11 00:00:00'),
(7, 'en_US', 'global.form.label.email', 'Email', NULL, '2016-05-12 00:00:00'),
(8, 'en_US', 'global.form.label.password', 'Password', NULL, '2016-05-12 00:00:00'),
(9, 'en_US', 'global.form.button.login', 'Log In', NULL, '2016-05-12 00:00:00'),
(10, 'en_US', 'global.form.button.forgotpass', 'Forgot Password?', NULL, '2016-05-12 00:00:00'),
(11, 'en_US', 'website.login.text.notmemberyet', 'Not a member yet? ', NULL, '2016-05-12 00:00:00'),
(12, 'en_US', 'website.login.alert.empty', 'Please enter your username and password', NULL, '2016-05-12 00:00:00'),
(13, 'en_US', 'website.login.alert.wrong', 'Wrong username or password', NULL, '2016-05-12 00:00:00'),
(14, 'en_US', 'website.login.alert.crash', 'Could not log in, please try again', NULL, '2016-05-12 00:00:00'),
(15, 'en_US', 'website.form.placeholder.leaveacomment', 'Leave a comment', NULL, '2016-05-12 00:00:00'),
(16, 'en_US', 'website.form.button.postcomment', 'Post Comment', NULL, '2016-05-12 00:00:00'),
(17, 'en_US', 'website.post.alert.emptycomment', 'Please enter a comment first', NULL, '2016-05-13 00:00:00'),
(18, 'en_US', 'website.post.alert.comment.crash', 'Could not add the comment, please try again', NULL, '2016-05-13 00:00:00'),
(19, 'en_US', 'website.post.alert.comment.success', 'Thank you! Your comment is under review', NULL, '2016-05-13 00:00:00'),
(20, 'en_US', 'website.form.placeholder.searchproduct', 'Search product', NULL, '2016-05-13 00:00:00'),
(21, 'en_US', 'website.form.label.username', 'Username', NULL, '2016-05-13 00:00:00'),
(22, 'en_US', 'website.404.title', '404 Page', NULL, '2016-05-13 00:00:00'),
(23, 'en_US', 'website.404.text.pagenotfound', 'We are sorry, that page has been removed or does not exists.', NULL, '2016-05-13 00:00:00'),
(24, 'en_US', 'website.form.button.signup', 'Sign Up', NULL, '2016-05-13 00:00:00'),
(25, 'en_US', 'website.signup.text.alreadymember', 'Already a member?', NULL, '2016-05-13 00:00:00'),
(26, 'en_US', 'website.signup.alert.username.empty', 'Please enter a username', NULL, '2016-05-13 00:00:00'),
(27, 'en_US', 'website.signup.alert.username.len', 'Your username must have minimum 6 and maximum 30 characters', NULL, '2016-05-13 00:00:00'),
(28, 'en_US', 'website.signup.alert.username.char', 'The username can contain only letters and numbers with no white spaces', NULL, '2016-05-13 00:00:00'),
(29, 'en_US', 'website.signup.alert.username.taken', 'That username is already taken', NULL, '2016-05-13 00:00:00'),
(30, 'en_US', 'website.signup.alert.email.empty', 'Please enter your email address', NULL, '2016-05-13 00:00:00'),
(31, 'en_US', 'website.signup.alert.email.len', 'The email cannot be that long', NULL, '2016-05-13 00:00:00'),
(32, 'en_US', 'website.signup.alert.email.wrong', 'Please enter a correct email address', NULL, '2016-05-13 00:00:00'),
(33, 'en_US', 'website.signup.alert.email.taken', 'That email address is taken, please other one', NULL, '2016-05-13 00:00:00'),
(34, 'en_US', 'ebsite.signup.alert.password.empty', 'Please enter a password', NULL, '2016-05-13 00:00:00'),
(35, 'en_US', 'website.signup.alert.password.lenmin', 'The password must have at least 6 characters', NULL, '2016-05-13 00:00:00'),
(36, 'en_US', 'website.signup.alert.password.lenmax', 'The password cannot be that long', NULL, '2016-05-13 00:00:00'),
(37, 'en_US', 'website.signup.alert.email.activation.crash', 'Could not send the activation email, please contact us', NULL, '2016-05-14 00:00:00'),
(38, 'en_US', 'website.signup.alert.account.crash', 'Could not create your account, please contact us', NULL, '2016-05-14 00:00:00'),
(39, 'en_US', 'website.signup.alert.account.success', 'Your account was created! Check your email inbox for the activation link', NULL, '2016-05-14 00:00:00'),
(40, 'en_US', 'website.signup.email.activation', '<!DOCTYPE html>			    \n<html>			        \n<head>			            \n<meta charset="utf-8">			        \n</head>			        \n<body style="font-family: arial;margin: 0px;padding: 0px;">			            \n<h2>Hello dear</h2>	                    \nComplete this step to activate your account<br/>                        \nClick the line below to activate your account <a href="%url%/%signupurl%/%member_id%/%member_password%/">%url%/%signupurl%/%member_id%/%member_password%/</a><br/>                        If the URL above is not an active link, please copy and paste it into your browser address bar.			        </body>			    </html>', NULL, '2016-05-14 00:00:00'),
(42, 'en_US', 'website.signup.alert.activation.failed', 'Your account could not be activated! Please email site administrator and request manual activation.', NULL, '2016-05-14 00:00:00'),
(41, 'en_US', 'website.signup.email.subject', 'Activation Link', NULL, '2016-05-14 00:00:00'),
(43, 'en_US', 'website.product.text.recommended', 'You may also like', NULL, '2016-05-15 00:00:00'),
(44, 'en_US', 'website.product.text.commentsreviews', 'Reviews', NULL, '2016-05-15 00:00:00'),
(45, 'en_US', 'website.forgotpassword.title', 'Forgot Password', NULL, '2016-05-15 00:00:00'),
(46, 'en_US', 'website.form.button.recoverpassword', 'Recover Password', NULL, '2016-05-15 00:00:00'),
(47, 'en_US', 'website.recover.email.subject', 'Password Recovery [%site%]', NULL, '2016-05-15 00:00:00'),
(48, 'en_US', 'website.recover.email.body', '<!DOCTYPE html>			    \n<html>			        \n<head>			            \n    <meta charset="utf-8">			        \n</head>			        \n<body style="font-family: arial;margin: 0px;padding: 0px;">			            \n    <h2>Hello dear</h2>\n	<br>\n	<p>You indicated that you forgot your login password.</p>\n	<p>After you click the link below your password to login will be: <b>%tempPassword%</b></p>\n	<br>\n	<a href="%url%/%lostpassurl%/%username%/%tempHashPassword%/" targe="_blank">Click here</a> now to apply the temporary password.</p>\n	<br/>\n	<p>If you do not click the link in this email, no changes will be made to your account.</p>\n</body>\n</html>', NULL, '2016-05-15 00:00:00'),
(49, 'en_US', 'website.recover.alert.emptymail', 'Please enter your email address', NULL, '2016-05-15 00:00:00'),
(50, 'en_US', 'website.recover.alert.fakemail', 'That email does not exists, please enter your email correct address', NULL, '2016-05-15 00:00:00'),
(51, 'en_US', 'website.recover.alert.crashmail', 'We could not send your password recovery mail, please try again or contact us', NULL, '2016-05-15 00:00:00'),
(52, 'en_US', 'website.recover.alert.successhmail', 'Done! Check your inbox for the next step', NULL, '2016-05-15 00:00:00'),
(53, 'en_US', 'website.cart.title', 'Cart', NULL, '2016-05-30 00:00:00'),
(54, 'en_US', 'website.search.title', 'Search Results', NULL, '2016-05-30 00:00:00'),
(55, 'en_US', 'website.search.alert.noproducts', 'No products found', NULL, '2016-05-30 00:00:00'),
(56, 'en_US', 'website.product.alert.noreviews', 'No reviews by this time', NULL, '2016-05-30 00:00:00'),
(57, 'en_US', 'website.form.button.postreview', 'Post Review', NULL, '2016-05-30 00:00:00'),
(58, 'en_US', 'website.product.alert.emptyreview', 'Please type a review first', NULL, '2016-05-30 00:00:00'),
(59, 'en_US', 'website.product.alert.toolong', 'Your review is too long, make it shorter please', NULL, '2016-05-30 00:00:00'),
(60, 'en_US', 'website.product.alert.norating', 'Please let a rating to your review', NULL, '2016-05-30 00:00:00'),
(61, 'en_US', 'website.product.alert.wrongreview', 'Your rating is not correct, please select a rating from 0 to 5', NULL, '2016-05-30 00:00:00'),
(62, 'en_US', 'website.product.alert.crash', 'Your review could not be added, please try again', NULL, '2016-05-30 00:00:00'),
(63, 'en_US', 'website.product.alert.success', 'Thank you for your review!', NULL, '2016-05-30 00:00:00'),
(64, 'en_US', 'website.product.alert.success.pending', 'Thank you! Your review is on pending', NULL, '2016-05-30 00:00:00'),
(65, 'en_US', 'website.product.text.instock', 'in stock', NULL, '2016-05-30 00:00:00'),
(66, 'en_US', 'website.product.text.yesstock', 'In stock', NULL, '2016-05-30 00:00:00'),
(67, 'en_US', 'website.product.text.nostock', 'Out of stock', NULL, '2016-05-30 00:00:00'),
(68, 'en_US', 'website.product.text.only', 'Only', NULL, '2016-05-30 00:00:00'),
(69, 'en_US', 'website.product.text.remain', 'left in stock', NULL, '2016-05-30 00:00:00'),
(70, 'en_US', 'website.form.button.addtocart', 'Add to Cart', NULL, '2016-05-30 00:00:00'),
(71, 'en_US', 'website.form.button.viewproduct', 'View Product', NULL, '2016-05-31 00:00:00'),
(72, 'en_US', 'website.form.button.show', 'Show', NULL, '2016-05-31 00:00:00'),
(73, 'en_US', 'website.search.text.products', 'Products', NULL, '2016-05-31 00:00:00'),
(74, 'en_US', 'website.search.text.stock', 'Stock', NULL, '2016-05-31 00:00:00'),
(75, 'en_US', 'website.search.text.advancesearch', 'Advance search', NULL, '2016-05-31 00:00:00'),
(76, 'en_US', 'website.search.text.pricerange', 'Price range', NULL, '2016-05-31 00:00:00'),
(77, 'en_US', 'website.search.alert.noproduct', 'No producs found', NULL, '2016-05-31 00:00:00'),
(78, 'en_US', 'website.myaccount.title', 'My Account', NULL, '2016-06-01 00:00:00'),
(79, 'en_US', 'website.myaccount.text.logout', 'Log Out', NULL, '2016-06-01 00:00:00'),
(80, 'en_US', 'website.myaccount.text.changepassword', 'Change Password', NULL, '2016-06-01 00:00:00'),
(81, 'en_US', 'website.myaccount.text.mycart', 'My Shopping Cart', NULL, '2016-06-01 00:00:00'),
(82, 'en_US', 'website.myaccount.text.wishlist', 'Wish List', NULL, '2016-06-01 00:00:00'),
(83, 'en_US', 'website.myaccount.text.accountsettings', 'Account Settings', NULL, '2016-06-01 00:00:00'),
(84, 'en_US', 'website.myaccount.text.myorders', 'My Orders', NULL, '2016-06-01 00:00:00'),
(85, 'en_US', 'website.myaccount.alert.noorders', 'You have no orders by this time', NULL, '2016-06-01 00:00:00'),
(86, 'en_US', 'website.myaccount.text.accepted', 'Accepted', NULL, '2016-06-01 00:00:00'),
(87, 'en_US', 'website.myaccount.text.pending', 'Pending', NULL, '2016-06-01 00:00:00'),
(88, 'en_US', 'website.myaccount.text.rejected', 'Rejected', NULL, '2016-06-01 00:00:00'),
(89, 'en_US', 'website.form.label.country', 'Country', NULL, '2016-06-01 00:00:00'),
(90, 'en_US', 'website.form.label.firstname', 'First Name', NULL, '2016-06-01 00:00:00'),
(91, 'en_US', 'website.form.label.lastname', 'Last Name', NULL, '2016-06-01 00:00:00'),
(92, 'en_US', 'website.form.label.companyname', 'Company Name', NULL, '2016-06-01 00:00:00'),
(93, 'en_US', 'website.form.label.address', 'Address', NULL, '2016-06-01 00:00:00'),
(94, 'en_US', 'website.form.label.city', 'City ', NULL, '2016-06-01 00:00:00'),
(95, 'en_US', 'website.form.label.state', 'State', NULL, '2016-06-01 00:00:00'),
(96, 'en_US', 'website.form.label.zip', 'Postcode / Zip', NULL, '2016-06-01 00:00:00'),
(97, 'en_US', 'website.form.label.phone', 'Phone', NULL, '2016-06-01 00:00:00'),
(98, 'en_US', 'website.form.button.update', 'Update Info', NULL, '2016-06-01 00:00:00'),
(99, 'en_US', 'website.myaccount.alert.country.char', 'That country does not exists', NULL, '2016-06-01 00:00:00'),
(100, 'en_US', 'website.myaccount.alert.country.len', 'That country name is too long', NULL, '2016-06-01 00:00:00'),
(101, 'en_US', 'website.myaccount.alert.country.empty', 'Please select a country', NULL, '2016-06-01 00:00:00'),
(102, 'en_US', 'website.myaccount.alert.firstname.char', 'The first name cannot contain special chars and HTML tags', NULL, '2016-05-13 00:00:00'),
(103, 'en_US', 'website.myaccount.alert.firstname.len', 'The first name it''s too long, please enter a shorter name', NULL, '2016-05-13 00:00:00'),
(104, 'en_US', 'website.myaccount.alert.firstname.empty', 'Please enter the first name', NULL, '2016-06-01 00:00:00'),
(105, 'en_US', 'website.myaccount.alert.lastname.char', 'The last name cannot contain special chars and HTML tags', NULL, '2016-06-01 00:00:00'),
(106, 'en_US', 'website.myaccount.alert.lastname.len', 'The last name it''s too long, please enter a shorter name', NULL, '2016-06-01 00:00:00'),
(107, 'en_US', 'website.myaccount.alert.lastname.empty', 'Please enter the last name', NULL, '2016-06-01 00:00:00'),
(108, 'en_US', 'website.myaccount.alert.companyname.len', 'The company name it''s too long, please enter a shorter name', NULL, '2016-06-01 00:00:00'),
(109, 'en_US', 'website.myaccount.alert.address.empty', 'Please enter an address', NULL, '2016-06-01 00:00:00'),
(110, 'en_US', 'website.myaccount.alert.address.len', 'The address cannot be longer than 500 characters', NULL, '2016-06-01 00:00:00'),
(111, 'en_US', 'website.myaccount.alert.city.len', 'The city name is too long', NULL, '2016-06-01 00:00:00'),
(112, 'en_US', 'website.myaccount.alert.city.empty', 'Please enter a city name', NULL, '2016-06-01 00:00:00'),
(113, 'en_US', 'website.myaccount.alert.state.len', 'The state name is too long', NULL, '2016-06-01 00:00:00'),
(114, 'en_US', 'website.myaccount.alert.zipcode.char', 'The zip code can contain only letters and numbers with no white spaces or other characters', NULL, '2016-06-01 00:00:00'),
(115, 'en_US', 'website.myaccount.alert.zipcode.len', 'The zip code cannot be longer than 32 characters', NULL, '2016-06-01 00:00:00'),
(116, 'en_US', 'website.myaccount.alert.zipcode.empty', 'Please enter a zip code(postal code)', NULL, '2016-06-01 00:00:00'),
(117, 'en_US', 'website.myaccount.alert.email.taken', 'That email address is taken, enter a different one', NULL, '2016-06-01 00:00:00'),
(118, 'en_US', 'website.myaccount.alert.email.wrong', 'That email address is wrong, enter a correct one please', NULL, '2016-06-01 00:00:00'),
(119, 'en_US', 'website.myaccount.alert.email.len', 'The email is too long to be good, please check again', NULL, '2016-06-01 00:00:00'),
(120, 'en_US', 'website.myaccount.alert.email.empty', 'Please enter an email addresss', NULL, '2016-06-01 00:00:00'),
(121, 'en_US', 'website.myaccount.alert.phone.char', 'The phone number can contain only digits from 0 to 9 and no other \r\ncharacters. Example: 04305939593', NULL, '2016-06-01 00:00:00'),
(122, 'en_US', 'website.myaccount.alert.phone.len', 'The phone number cannot be that long', NULL, '2016-06-01 00:00:00'),
(123, 'en_US', 'website.myaccount.alert.phone.empty', 'Please enter a phone number', NULL, '2016-06-01 00:00:00'),
(124, 'en_US', 'website.myaccount.alert.update.crash', 'Your account could not be updated, please try again', NULL, '2016-06-01 00:00:00'),
(125, 'en_US', 'website.myaccount.alert.update.success', 'Your account has been updated successfully', NULL, '2016-06-01 00:00:00'),
(126, 'en_US', 'website.form.label.changepassword', 'Current Password', NULL, '2016-06-01 00:00:00'),
(127, 'en_US', 'website.form.label.newpassword', 'New Password', NULL, '2016-06-01 00:00:00'),
(128, 'en_US', 'website.form.label.confirmpassword', 'Confirm Password', NULL, '2016-06-01 00:00:00'),
(129, 'en_US', 'website.form.button.changepassword', 'Change Password', NULL, '2016-06-01 00:00:00'),
(130, 'en_US', 'website.myaccount.alert.changepass.success', 'Your password has been updated', NULL, '2016-06-01 00:00:00'),
(131, 'en_US', 'website.myaccount.alert.changepass.crash', 'The password could not be updated, please try again', NULL, '2016-06-01 00:00:00'),
(132, 'en_US', 'website.myaccount.alert.changepass.nomatch', 'The two new passwords don''t match', NULL, '2016-06-01 00:00:00'),
(133, 'en_US', 'website.myaccount.alert.changepass.wrong', 'Your current password is not correct', NULL, '2016-06-01 00:00:00'),
(134, 'en_US', 'website.myaccount.alert.changepass.empty', 'Please fill the password inputs', NULL, '2016-06-01 00:00:00'),
(135, 'en_US', 'website.myaccount.alert.nowishlist', 'By this time you have no products in the wish list', NULL, '2016-06-01 00:00:00'),
(136, 'en_US', 'website.myaccount.alert.wronproduct', 'That product does not exists or no longer is available', NULL, '2016-06-01 00:00:00'),
(137, 'en_US', 'website.myaccount.alert.allready', 'You already added that product to your wishlist', NULL, '2016-06-01 00:00:00'),
(138, 'en_US', 'website.form.button.addtowishlist', 'Add to Wishlist', NULL, '2016-06-01 00:00:00'),
(139, 'en_US', 'website.myaccount.alert.crashlist', 'Could not add the product to the wishlist, please try again', NULL, '2016-06-01 00:00:00'),
(140, 'en_US', 'website.form.button.remove', 'Remove', NULL, '2016-06-01 00:00:00'),
(141, 'en_US', 'website.form.button.mycart', 'My Cart', NULL, '2016-06-02 00:00:00'),
(142, 'en_US', 'website.cart.text.checkout', 'Checkout', NULL, '2016-06-02 00:00:00'),
(143, 'en_US', 'website.cart.text.coupon', 'Coupon', NULL, '2016-06-02 00:00:00'),
(144, 'en_US', 'website.form.button.applycoupon', 'Apply Coupon', NULL, '2016-06-02 00:00:00'),
(145, 'en_US', 'website.form.placefolder.couponcode', 'Coupon Code', NULL, '2016-06-02 00:00:00'),
(146, 'en_US', 'website.cart.alert.couponwrong', 'That coupon is not available', NULL, '2016-06-02 00:00:00'),
(147, 'en_US', 'website.cart.alert.emptycart', 'Your shopping cart is empty', NULL, '2016-06-02 00:00:00'),
(148, 'en_US', 'website.cart.text.shoppingcart', 'Shopping Cart', NULL, '2016-06-02 00:00:00'),
(149, 'en_US', 'website.cart.text.product', 'Product', NULL, '2016-06-02 00:00:00'),
(150, 'en_US', 'website.cart.text.quantity', 'Quantity', NULL, '2016-06-02 00:00:00'),
(151, 'en_US', 'website.cart.text.price', 'Price', NULL, '2016-06-02 00:00:00'),
(152, 'en_US', 'website.cart.text.total', 'Total', NULL, '2016-06-02 00:00:00'),
(153, 'en_US', 'website.cart.alert.nogates', 'You must configure some payments methods for your customers', NULL, '2016-06-02 00:00:00'),
(154, 'en_US', 'website.cart.text.paywithpaypal', 'Pay with PayPal', NULL, '2016-06-02 00:00:00'),
(155, 'en_US', 'website.cart.text.paywithbt', 'Pay by making Bank Transfer', NULL, '2016-06-02 00:00:00'),
(156, 'en_US', 'website.cart.text.discount', 'Discount', NULL, '2016-06-03 00:00:00'),
(157, 'en_US', 'website.cart.text.taxes', 'Taxes', NULL, '2016-06-03 00:00:00'),
(158, 'en_US', 'website.cart.alert.minorder', 'Your subtotal order must be at least', NULL, '2016-06-03 00:00:00'),
(159, 'en_US', 'website.cart.alert.maxnorder', 'Your subtotal order cannot be more than', NULL, '2016-06-03 00:00:00'),
(160, 'en_US', 'website.cart.text.shippingcosts', 'Shipping Costs', NULL, '2016-06-03 00:00:00'),
(161, 'en_US', 'website.cart.text.subtotal', 'Subtotal', NULL, '2016-06-03 00:00:00'),
(162, 'en_US', 'website.cart.text.total', 'Total', NULL, '2016-06-03 00:00:00'),
(163, 'en_US', 'website.payment.title', 'Payment', NULL, '2016-06-03 00:00:00'),
(164, 'en_US', 'website.payment.ordernumber', 'Order Number', NULL, '2016-06-04 00:00:00'),
(165, 'en_US', 'website.download.title', 'Download', NULL, '2016-06-04 00:00:00'),
(166, 'en_US', 'website.payment.text.digitalproducts', 'Digital Products', NULL, '2016-06-05 00:00:00'),
(167, 'en_US', 'website.payment.text.orderdetails', NULL, NULL, '2016-06-05 00:00:00'),
(168, 'en_US', 'website.payment.email.title', 'Hello there!', NULL, '2016-06-05 00:00:00'),
(169, 'en_US', 'website.payment.email.message', 'We received your order and we shall contact you soon with more details. Thank you very much for choosing our products and services.', NULL, '2016-06-05 00:00:00'),
(170, 'en_US', 'website.payment.text.shippingaddress', 'Shipping Address', NULL, '2016-06-05 00:00:00'),
(171, 'en_US', 'website.download.remainingdownloads', 'Remaining downloads', NULL, '2016-06-05 00:00:00'),
(172, 'en_US', 'website.download.downloadedtimes', 'Downloaded times', NULL, '2016-06-05 00:00:00'),
(173, 'en_US', 'website.download.text.accessexpire', 'Access expire', NULL, '2016-06-05 00:00:00'),
(174, 'en_US', 'website.download.text.info', 'Thank you for your order!', NULL, '2016-06-05 00:00:00'),
(175, 'en_US', 'website.download.alert.unexsitingorder', 'No order was found for this digital product', NULL, '2016-06-05 00:00:00'),
(176, 'en_US', 'website.download.alert.noremainingdownloads', 'You already reached the allowed download times.', NULL, '2016-06-05 00:00:00'),
(177, 'en_US', 'website.download.alert.unexsitingproduct', 'That digital product doesn''t exists or have been removed', NULL, '2016-06-05 00:00:00'),
(178, 'en_US', 'website.payment.text.success.title', 'Payment Successfully', NULL, '2016-06-05 00:00:00'),
(179, 'en_US', '''website.payment.text.pending.title', 'Payment Pending', NULL, '2016-06-05 00:00:00'),
(180, 'en_US', 'website.payment.text.failed.title', 'Payment Failed', NULL, '2016-06-05 00:00:00'),
(181, 'en_US', 'website.payment.alert.successpayment', 'Your payment has been successfully made, check your email Inbox or Spam for the download link. Thanks for choosing Proeminent Code!', NULL, '2016-06-05 00:00:00'),
(182, 'en_US', 'website.payment.alert.pendingpayment', 'Your payment has been successfully made and it\\''s under review, this may take a few hours in some cases. After it\\''s approved you will receive an email with the download link. Thanks for choosing Proeminent Code!', NULL, '2016-06-05 00:00:00'),
(183, 'en_US', 'website.payment.alert.failedpayment.1', 'We are sorry, your payment could not be made. The hash key is invalid', NULL, '2016-06-05 00:00:00'),
(184, 'en_US', 'website.payment.alert.failedpayment.2', 'We are sorry, your order could not be placed. One or more products from your order are not valid.', NULL, '2016-06-05 00:00:00'),
(185, 'en_US', 'website.payment.alert.failedpayment.3', 'We are sorry, something went wrong with your order, please contact us for more details.', NULL, '2016-06-05 00:00:00'),
(186, 'en_US', 'website.checkout.title', 'Checkout', NULL, '2016-06-05 00:00:00'),
(187, 'en_US', 'website.checkout.text.banktransfer', 'Bank Transfer', NULL, '2016-06-05 00:00:00'),
(188, 'en_US', 'website.checkout.text.cash', 'Cash', NULL, '2016-06-05 00:00:00'),
(189, 'en_US', 'website.form.button.placeorder', 'Place Order', NULL, '2016-06-06 00:00:00'),
(190, 'en_US', 'website.checkout.text.billingdetails', 'Billing Details', NULL, '2016-06-06 00:00:00'),
(191, 'en_US', 'website.checkout.text.details', 'Details', NULL, '2016-06-06 00:00:00'),
(192, 'en_US', 'website.checkout.text.banktransfer.details', 'After you will place the order, you will receive an email from us with the details necessary to make the bank transfer. Use the order number as a reference for the bank transfer. When we receive the transfer, we shall send you the products. For any help or questions please contact us.', NULL, '2016-06-06 00:00:00'),
(193, 'en_US', 'website.checkout.alert.products.wrong', 'Something went wrong, please try again', NULL, '2016-06-06 00:00:00'),
(194, 'en_US', 'website.checkout.alert.banktransfer.crash', 'Something went wrong with your order, please try again', NULL, '2016-06-06 00:00:00'),
(195, 'en_US', 'website.payment.alert.banktransfer', 'Thank you for your order! You will receive an email containing more details about the bank transfer. We will contact you soon.', NULL, '2016-06-06 00:00:00'),
(196, 'en_US', 'website.checkout.text.rememberdownload', 'Below you have the link to download your digital product. After we receive the money, we shall email you. Than you can come back and click the link to download.', NULL, '2016-06-06 00:00:00'),
(197, 'en_US', 'website.checkout.text.banktransfer.h3', 'Bank Transfer Details', NULL, '2016-06-06 00:00:00'),
(198, 'en_US', 'website.checkout.text.banktransfer.orderreference', 'Reference Order', NULL, '2016-06-06 00:00:00'),
(199, 'en_US', 'website.checkout.text.accountname', 'Account Name', NULL, '2016-06-06 00:00:00'),
(200, 'en_US', 'website.checkout.text.accountnumber', 'Account Number', NULL, '2016-06-06 00:00:00'),
(201, 'en_US', 'website.checkout.text.bankname', 'Bank Name', NULL, '2016-06-06 00:00:00'),
(202, 'en_US', 'website.checkout.text.sortcode', 'Sort Code', NULL, '2016-06-06 00:00:00'),
(203, 'en_US', 'website.checkout.text.IBAN', 'IBAN', NULL, '2016-06-06 00:00:00'),
(204, 'en_US', 'website.checkout.text.bic', 'BIC / SWIFT', NULL, '2016-06-06 00:00:00'),
(205, 'en_US', 'website.checkout.text.cash.details', 'After you place the order we shall contact you. Then we will deliver your products with the pay when they arrive at your address. Please note that for digital products this option cannot be applied, contact us for more.', NULL, '2016-06-06 00:00:00'),
(206, 'en_US', 'website.payment.alert.cash', 'Thank you for your order! You will receive an email containing more details about your order. We will contact you soon.', NULL, '2016-06-06 00:00:00'),
(207, 'en_US', 'website.download.alert.pending', 'The payment is under review, after it will be approve you will receive an email regarding this. Then you can come back here and download your products. This usually happens quickly. Thank you for your patience.', NULL, '2016-06-07 00:00:00'),
(208, 'en_US', 'website.download.alert.fraud', 'Your payment didn''t pass the security review. No actions need to be taken, if you want more information please contact us.', NULL, '2016-06-07 00:00:00'),
(209, 'en_US', 'website.myaccount.text.id', 'ID', NULL, '2016-06-07 00:00:00'),
(210, 'en_US', 'website.myaccount.text.state', 'Status', NULL, '2016-06-07 00:00:00'),
(211, 'en_US', 'website.myaccount.text.total', 'Total', NULL, '2016-06-07 00:00:00'),
(212, 'en_US', 'website.myaccount.text.date', 'Date', NULL, '2016-06-07 00:00:00'),
(213, 'en_US', 'website.invoice.title', 'Invoice', NULL, '2016-06-07 00:00:00'),
(214, 'en_US', 'website.invoice.text.customerinfo', 'Customer Info', NULL, '2016-06-07 00:00:00'),
(215, 'en_US', 'website.invoice.text.shippingaddress', 'Shipping Address', NULL, '2016-06-07 00:00:00'),
(216, 'en_US', 'website.invoice.text.order', 'Order', NULL, '2016-06-07 00:00:00'),
(217, 'en_US', 'website.invoice.text.payment', 'Payment', NULL, '2016-06-07 00:00:00'),
(218, 'en_US', 'website.invoice.text.banktransfer', 'Bank Transfer', NULL, '2016-06-07 00:00:00'),
(219, 'en_US', 'website.invoice.text.cashondelivery', 'Cash on Delivery', NULL, '2016-06-07 00:00:00'),
(220, 'en_US', 'website.invoice.text.method', 'Method', NULL, '2016-06-07 00:00:00'),
(221, 'en_US', 'website.invoice.text.approved', 'Approved', NULL, '2016-06-07 00:00:00'),
(222, 'en_US', 'website.invoice.text.pending', 'Pending', NULL, '2016-06-07 00:00:00'),
(223, 'en_US', 'website.invoice.text.failed', 'Failed', NULL, '2016-06-07 00:00:00'),
(224, 'en_US', 'website.invoice.text.amount', 'Amount', NULL, '2016-06-07 00:00:00'),
(225, 'en_US', 'website.invoice.text.items', 'Items', NULL, '2016-06-07 00:00:00'),
(226, 'en_US', 'website.invoice.text.productremoved', 'Product Removed', NULL, '2016-06-07 00:00:00'),
(227, 'en_US', 'website.form.label.fullname', 'Full Name', NULL, '2016-06-10 00:00:00'),
(228, 'en_US', 'website.form.label.subject', 'Subject', NULL, '2016-06-10 00:00:00'),
(229, 'en_US', 'website.form.label.message', 'Message', NULL, '2016-06-10 00:00:00'),
(230, 'en_US', 'website.form.button.sendmessage', 'Send Message', NULL, '2016-06-10 00:00:00'),
(231, 'en_US', 'website.contact.alert.fullname.empty', 'Please enter your full name', NULL, '2016-06-10 00:00:00'),
(232, 'en_US', 'website.contact.alert.fullname.len', 'Your full name cannot be that long, please enter a shorter version of your name', NULL, '2016-06-10 00:00:00'),
(233, 'en_US', 'website.contact.alert.fullname.char', 'Your full name cannot contain HTML tags, please remove them', NULL, '2016-06-10 00:00:00'),
(234, 'en_US', 'website.contact.alert.email.empty', 'Please enter your email address', NULL, '2016-06-10 00:00:00'),
(235, 'en_US', 'website.contact.alert.email.len', 'The email cannot be that long, check it again please', NULL, '2016-06-10 00:00:00'),
(236, 'en_US', 'website.contact.alert.email.wrong', 'Your email address is not correct, please review it again', NULL, '2016-06-10 00:00:00'),
(237, 'en_US', 'website.contact.alert.phone.empty', 'Please enter your phone number', NULL, '2016-06-10 00:00:00'),
(238, 'en_US', 'website.contact.alert.phone.len', 'Your phone number cannot be that long', NULL, '2016-06-10 00:00:00'),
(239, 'en_US', 'website.contact.alert.phone.char', 'Please enter the phone number only with numbers and not white spaces or other chars', NULL, '2016-06-10 00:00:00'),
(240, 'en_US', 'website.contact.alert.subject.empty', 'Please enter a subject', NULL, '2016-06-10 00:00:00'),
(241, 'en_US', 'website.contact.alert.subject.len', 'Your subject cannot be that long', NULL, '2016-06-10 00:00:00'),
(242, 'en_US', 'website.contact.alert.subject.char', 'Your subject cannot contain HTML tags', NULL, '2016-06-10 00:00:00'),
(243, 'en_US', 'website.contact.alert.message.empty', 'Please enter a message', NULL, '2016-06-10 00:00:00'),
(244, 'en_US', 'website.contact.alert.message.len', 'Your message is too long, please make it shorter', NULL, '2016-06-10 00:00:00'),
(245, 'en_US', 'website.contact.alert.mail.success', 'Thank you! We received your email and we shall contact you soon with news.', NULL, '2016-06-10 00:00:00'),
(246, 'en_US', 'website.contact.alert.mail.crash', 'Something went wrong ,please try again', NULL, '2016-06-10 00:00:00'),
(247, 'en_US', 'website.secretpassword.title', 'Private Post', NULL, '2016-06-14 00:00:00'),
(248, 'en_US', 'website.secretpassword.alert.wrong.password', 'Nope, that is not a good password', NULL, '2016-06-14 00:00:00'),
(249, 'en_US', 'website.form.button.confirm', 'Confirm', NULL, '2016-06-14 00:00:00'),
(250, 'en_US', 'website.secretpassword.text.enterpass', 'Please enter the secret password to continue', NULL, '2016-06-14 00:00:00'),
(251, 'en_US', 'website.blog.noposts', 'No posts found by this time, sorry.', NULL, '2016-09-11 00:00:00'),
(252, 'en_US', 'website.logout.alert.success', 'You just logged out successfully!', NULL, '2016-09-12 00:00:00'),
(253, 'en_US', 'website.logout.alert.crash', 'Something went wrong, please refresh the page to log out.', NULL, '2016-09-12 00:00:00'),
(254, 'en_US', 'website.form.button.choosephoto', 'Choose Photo', NULL, '2016-09-12 00:00:00'),
(255, 'en_US', 'website.form.button.removephoto', 'Remove Photo', NULL, '2016-09-12 00:00:00'),
(256, 'en_US', 'website.forums.alert.nocforumsfound', 'No forums found.', NULL, '2016-09-13 00:00:00'),
(257, 'en_US', 'website.forums.text.replies', 'Replies', NULL, '2016-09-13 00:00:00'),
(259, 'en_US', 'website.forums.text.views', 'Views', NULL, '2016-09-13 00:00:00'),
(260, 'en_US', 'website.forums.alert.nocategories', 'No forum categories found.', NULL, '2016-09-15 00:00:00'),
(261, 'en_US', 'website.forums.alert.nocthreadsfound', 'No threads found.', NULL, '2016-09-15 00:00:00'),
(262, 'en_US', 'website_forums.text.threadtitle', 'Thread Title', NULL, '2016-09-15 00:00:00'),
(263, 'en_US', 'website_forums.text.lastactivity', 'Last Activity', NULL, '2016-09-15 00:00:00'),
(264, 'en_US', 'website.forums.text.lastreply', 'Last reply', NULL, '2016-09-15 00:00:00'),
(265, 'en_US', 'website.forums.text.newreply', 'New Reply', NULL, '2016-09-16 00:00:00'),
(266, 'en_US', 'website.forums.alert.repliesfound', 'No replies found', NULL, '2016-09-19 00:00:00'),
(267, 'en_US', 'website.forms.button.postreply', 'Post Reply', NULL, '2016-09-19 00:00:00'),
(268, 'en_US', 'website.forum.alert.postreply.empty', 'Please enter a message to post the reply.', NULL, '2016-09-19 00:00:00'),
(269, 'en_US', 'website.forums.alert.postreply.len', 'The reply length it''s too long, make it shorter please.', NULL, '2016-09-19 00:00:00'),
(270, 'en_US', 'website.forums.alert.postreply.crash', 'Something went wrong, please try again.', NULL, '2016-09-19 00:00:00'),
(271, 'en_US', 'website.forms.alert.postreply.success', 'Your reply was added successfully!', NULL, '2016-09-19 00:00:00'),
(272, 'en_US', 'website.forms.button.newthread', 'New Thread', NULL, '2016-09-22 00:00:00'),
(273, 'en_US', 'website.forms.button.postthread', 'Post Thread', NULL, '2016-09-22 00:00:00'),
(274, 'en_US', 'website.forms.button.cancel', 'Cancel', NULL, '2016-09-22 00:00:00'),
(275, 'en_US', 'website.forums.alert.newthread.empty', 'Please enter a content for the thread.', NULL, '2016-09-22 00:00:00'),
(276, 'en_US', 'website.forums.alert.newthread.len', 'The content of the thread it''s too long, make it shorter please.', NULL, '2016-09-22 00:00:00'),
(277, 'en_US', 'website.forms.label.threadtitle', 'Thread Title', NULL, '2016-09-22 00:00:00'),
(278, 'en_US', 'website.forms.label.content', 'Content', NULL, '2016-09-22 00:00:00'),
(279, 'en_US', 'website.forums.alert.newthread.title.empty', 'Please enter a title for the thread.', NULL, '2016-09-22 00:00:00'),
(280, 'en_US', 'website.forums.alert.newthread.title.len', 'The title it''s too long, make it shorter please.', NULL, '2016-09-22 00:00:00'),
(281, 'en_US', 'website.forums.alert.newthread.crash', 'Could not add the thread, please try again.', NULL, '2016-09-22 00:00:00'),
(282, 'en_US', 'website.form.button.subscribe', 'Subscribe', NULL, '2016-09-27 00:00:00'),
(283, 'en_US', 'website.form.placeholder.emailaddress', 'Email address', NULL, '2016-09-27 00:00:00'),
(284, 'en_US', 'website.subscribe.alert.emptymail', 'Please enter your email address.', NULL, '2016-09-27 00:00:00'),
(285, 'en_US', 'website.subscribe.alert.crash', 'Something went, please try again.', NULL, '2016-09-27 00:00:00'),
(286, 'en_US', 'website.subscribe.alert.already', 'You already subscribed with this email address.', NULL, '2016-09-27 00:00:00'),
(287, 'en_US', 'website.subscribe.alert.success', 'You subscribed successfully.', NULL, '2016-09-27 00:00:00'),
(288, 'en_US', 'website.subscribe.alert.wrong', 'Please enter a valid email address.', NULL, '2016-09-27 00:00:00'),
(289, 'en_US', 'website.affiliate.text.clicks', 'Clicks', NULL, '2016-10-18 00:00:00'),
(290, 'en_US', 'website.affiliate.text.signups', 'Signups', NULL, '2016-10-18 00:00:00'),
(291, 'en_US', 'website.affiliate.text.conversions', 'Conversions', NULL, '2016-10-18 00:00:00'),
(292, 'en_US', 'website.affiliate.text.referallink', 'Your Unique Referral Link', NULL, '2016-10-18 00:00:00'),
(293, 'en_US', 'website.affiliate.text.totalamountwithdrawn', 'Total Amount Withdrawn', NULL, '2016-10-19 00:00:00'),
(294, 'en_US', 'website.affiliate.text.availablecommissionsbalance', 'Available Commissions Balance', NULL, '2016-10-19 00:00:00'),
(295, 'en_US', 'website.affiliate.text.commissionspendingmaturation', 'Commissions Pending', NULL, '2016-10-19 00:00:00'),
(296, 'en_US', 'website.forms.button.requestwithdrawal', 'Request Withdrawal', NULL, '2016-10-19 00:00:00'),
(297, 'en_US', 'website.affiliate.text.affiliatecommissionpercent', 'Affiliate Commission Percent', NULL, '2016-10-19 00:00:00'),
(298, 'en_US', 'website.affiliate.text.minimumammount', 'You will be able to request a withdrawal as soon as your balance reaches the minimum required amount of', NULL, '2016-10-19 00:00:00'),
(299, 'en_US', 'website.affiliate.text.yourcommissions', 'Your Commissions', NULL, '2016-10-19 00:00:00'),
(300, 'en_US', 'website.affiliate.alert.nocommmissions', 'No commissions found by this time.', NULL, '2016-10-19 00:00:00'),
(301, 'en_US', 'website.affiliate.text.ordernumber', 'Order Number', NULL, '2016-10-19 00:00:00'),
(302, 'en_US', 'website.affiliate.text.total', 'Total', NULL, '2016-10-19 00:00:00'),
(303, 'en_US', 'website.affiliate.text.commission', 'Commission', NULL, '2016-10-19 00:00:00'),
(304, 'en_US', 'website.affiliate.text.status', 'Status', NULL, '2016-10-19 00:00:00'),
(305, 'en_US', 'website.affiliate.text.date', 'Date', NULL, '2016-10-19 00:00:00'),
(306, 'en_US', 'website.affiliate.text.approved', 'Approved', NULL, '2016-10-19 00:00:00'),
(307, 'en_US', 'website.affiliate.text.pending', 'Pending', NULL, '2016-10-19 00:00:00'),
(308, 'en_US', 'website.affiliate.text.rejected', 'Rejected', NULL, '2016-10-19 00:00:00'),
(309, 'en_US', 'website.affiliate.text.yourwithdraws', 'Your Withdrawals', NULL, '2016-10-19 00:00:00'),
(310, 'en_US', 'website.affiliate.text.alert.withdrawproccessing', 'Your withdrawal request is under processing, please be patient.', NULL, '2016-10-19 00:00:00'),
(311, 'en_US', 'website.affiliate.alert.nowithdrawls', 'By this time you have no withdrawals.', NULL, '2016-10-19 00:00:00'),
(312, 'en_US', 'website.affiliate.text.amount', 'Amount', NULL, '2016-10-19 00:00:00'),
(313, 'en_US', 'website.affiliate.alert.withdraw.notenought', 'You don''t have enough funds to make this withdraw.', NULL, '2016-10-19 00:00:00'),
(314, 'en_US', 'website.affiliate.alert.withdraw.pendingwithdraw', 'You already have a withdrawal under pending, please wait.', NULL, '2016-10-19 00:00:00'),
(315, 'en_US', 'website.affiliate.alert.withdraw.crash', 'We couldn''t process your withdrawal request, please try again.', NULL, '2016-10-19 00:00:00'),
(316, 'en_US', 'website.affiliate.alert.withdraw.success', 'Your withdrawal request is under processing, please wait.', NULL, '2016-10-19 00:00:00'),
(317, 'en_US', 'website.support.alert.noticketsfound', 'No support tickets found.', NULL, '2016-11-02 00:00:00'),
(318, 'en_US', 'website.forms.button.newticket', 'New Ticket', NULL, '2016-11-02 00:00:00'),
(319, 'en_US', 'website.support.text.number', 'Number', NULL, '2016-11-02 00:00:00'),
(320, 'en_US', 'website.support.text.subject', 'Subject', NULL, '2016-11-02 00:00:00'),
(321, 'en_US', 'website.support.text.lastreply', 'Last Reply', NULL, '2016-11-02 00:00:00'),
(322, 'en_US', 'website.support.text.status', 'Status', NULL, '2016-11-02 00:00:00'),
(323, 'en_US', 'website.support.text.new', 'New', NULL, '2016-11-02 00:00:00'),
(324, 'en_US', 'website.support.text.closed', 'Closed', NULL, '2016-11-02 00:00:00'),
(325, 'en_US', 'website.support.text.supportreply', 'Support Reply', NULL, '2016-11-02 00:00:00'),
(326, 'en_US', 'website.support.text.pending', 'Pending', NULL, '2016-11-02 00:00:00'),
(327, 'en_US', 'website.forms.label.orderid', 'Order ID', NULL, '2016-11-02 00:00:00'),
(328, 'en_US', 'website.forms.placeholder.naorderid', 'Put N/A if no order', NULL, '2016-11-02 00:00:00'),
(329, 'en_US', 'website.forms.button.submitticket', 'Submit Ticket', NULL, '2016-11-02 00:00:00'),
(330, 'en_US', 'website.support.newticket.alert.orderid.wrong', 'The order ID it''s not correct, a correct order ID should be like this: #35868', NULL, '2016-11-02 00:00:00'),
(331, 'en_US', 'website.support.newticket.alert.orderid.empty', 'Please enter the order ID or type N/A', NULL, '2016-11-02 00:00:00'),
(332, 'en_US', 'website.support.newticket.alert.subject.len', 'The subject it''s way too long, make it shorter please.', NULL, '2016-11-02 00:00:00'),
(333, 'en_US', 'website.support.newticket.alert.subject.empty', 'Please enter a subject.', NULL, '2016-11-02 00:00:00'),
(334, 'en_US', 'website.support.newticket.alert.message.len', 'The message it''s too long, make it shorter please.', NULL, '2016-11-02 00:00:00'),
(335, 'en_US', 'website.support.newticket.alert.message.empty', 'Please enter a message for the ticket.', NULL, '2016-11-02 00:00:00'),
(336, 'en_US', 'website.support.newticket.alert.status.wrong', 'Something went wrong, please try to submit your ticket again.', NULL, '2016-11-02 00:00:00'),
(337, 'en_US', 'website.support.text.supportticket', 'Support Ticket', NULL, '2016-11-02 00:00:00'),
(338, 'en_US', 'website.support.text.datecreated', 'Date Created', NULL, '2016-11-02 00:00:00'),
(339, 'en_US', 'website.support.text.newreply', 'New Reply', NULL, '2016-11-02 00:00:00'),
(340, 'en_US', 'website.forms.button.closeticket', 'Close Ticket', NULL, '2016-11-02 00:00:00'),
(341, 'en_US', 'website.support.text.staffmember', 'Staff Member', NULL, '2016-11-02 00:00:00'),
(342, 'en_US', 'website.support.alert.newreply.crash', 'Could not submit your reply, please try again.', NULL, '2016-11-02 00:00:00'),
(343, 'en_US', 'website.support.alert.closeticket.crash', 'Could not close the ticket, please try again.', NULL, '2016-11-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_layout`
--

CREATE TABLE IF NOT EXISTS `pc_layout` (
  `layout_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `layout_website_ID` bigint(20) NOT NULL,
  `layout_homePage` bigint(20) NOT NULL,
  `layout_sidebar` bigint(20) NOT NULL,
  `layout_topMenu` bigint(20) NOT NULL,
  `layout_primaryMenu` bigint(20) NOT NULL,
  `layout_footer_Wigets` enum('1','0') DEFAULT '1',
  `layout_footer_WigetsLayout` int(1) NOT NULL DEFAULT '4',
  `footer_layout_icons` enum('1','0') NOT NULL DEFAULT '1',
  `layout_footer_widget_1` bigint(20) NOT NULL DEFAULT '0',
  `layout_footer_widget_2` bigint(20) NOT NULL DEFAULT '0',
  `layout_footer_widget_3` bigint(20) NOT NULL DEFAULT '0',
  `layout_footer_widget_4` bigint(20) NOT NULL DEFAULT '0',
  `layout_footer_leftSide` varchar(255) DEFAULT NULL,
  `layout_footer_rightSide` varchar(255) DEFAULT NULL,
  `layout_update` datetime DEFAULT NULL,
  `layout_date` datetime NOT NULL,
  PRIMARY KEY (`layout_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pc_layout`
--

INSERT INTO `pc_layout` (`layout_ID`, `layout_website_ID`, `layout_homePage`, `layout_sidebar`, `layout_topMenu`, `layout_primaryMenu`, `layout_footer_Wigets`, `layout_footer_WigetsLayout`, `footer_layout_icons`, `layout_footer_widget_1`, `layout_footer_widget_2`, `layout_footer_widget_3`, `layout_footer_widget_4`, `layout_footer_leftSide`, `layout_footer_rightSide`, `layout_update`, `layout_date`) VALUES
(1, 1, 1, 1, 1, 1, '1', 4, '0', 2, 1, 5, 6, '&copy; 2016 Proeminent Code SRL. All rights reserverd.', 'Power by &lt;a href=&quot;https://www.proeminentcode.com&quot; target=&quot;_blank&quot;&gt;Proeminent Code&lt;/a&gt;', '2016-09-27 09:54:51', '2016-04-22 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_media`
--

CREATE TABLE IF NOT EXISTS `pc_media` (
  `media_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `media_role` enum('tumbnail','media','digital') NOT NULL DEFAULT 'media',
  `media_title` varchar(500) NOT NULL,
  `media_name` text NOT NULL,
  `media_type` varchar(255) NOT NULL,
  `media_size` varchar(20) NOT NULL,
  `media_path` varchar(255) NOT NULL,
  `media_status` enum('Public','Private','Password') NOT NULL DEFAULT 'Public',
  `media_uploaded` datetime NOT NULL,
  PRIMARY KEY (`media_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_media_download`
--

CREATE TABLE IF NOT EXISTS `pc_media_download` (
  `download_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_country` varchar(100) NOT NULL,
  `download_code` varchar(10) NOT NULL,
  `download_file` text,
  `download_ip` varchar(50) NOT NULL,
  `download_date` datetime NOT NULL,
  PRIMARY KEY (`download_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_members`
--

CREATE TABLE IF NOT EXISTS `pc_members` (
  `member_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `member_firstname` varchar(100) DEFAULT NULL,
  `member_lastname` varchar(100) DEFAULT NULL,
  `member_company` varchar(150) DEFAULT NULL,
  `member_user` varchar(30) NOT NULL,
  `member_email` varchar(255) NOT NULL,
  `member_phone` varchar(15) NOT NULL,
  `member_pass` varchar(32) DEFAULT NULL,
  `member_temp_pass` varchar(255) NOT NULL,
  `member_country` varchar(50) DEFAULT NULL,
  `member_state` varchar(100) DEFAULT NULL,
  `member_city` varchar(100) DEFAULT NULL,
  `member_address` text NOT NULL,
  `member_zipcode` varchar(32) DEFAULT NULL,
  `member_notes` text,
  `member_last_IP` varchar(255) DEFAULT NULL,
  `member_signup_IP` varchar(255) NOT NULL,
  `member_login` datetime DEFAULT NULL,
  `member_status` enum('g','f','b','d') NOT NULL DEFAULT 'g',
  `member_activated` enum('1','0') NOT NULL DEFAULT '0',
  `member_last_update` datetime DEFAULT NULL,
  `member_signup` datetime NOT NULL,
  PRIMARY KEY (`member_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_menus`
--

CREATE TABLE IF NOT EXISTS `pc_menus` (
  `menu_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `menu_links` text NOT NULL,
  `menu_status` enum('1','0') NOT NULL DEFAULT '1',
  `menu_update` datetime DEFAULT NULL,
  `menu_date` datetime NOT NULL,
  PRIMARY KEY (`menu_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pc_menus`
--

INSERT INTO `pc_menus` (`menu_ID`, `menu_name`, `menu_links`, `menu_status`, `menu_update`, `menu_date`) VALUES
(1, 'Main Menu', '', '1', NULL, '2016-11-10 06:44:38'),
(2, 'Right Menu', '', '1', NULL, '2016-12-04 04:19:43');

-- --------------------------------------------------------

--
-- Table structure for table `pc_menus_links`
--

CREATE TABLE IF NOT EXISTS `pc_menus_links` (
  `link_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_ID` bigint(20) NOT NULL,
  `link_parrent` bigint(20) DEFAULT '0',
  `link_order` int(2) NOT NULL,
  `link_icon` varchar(100) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `link_name` varchar(255) DEFAULT NULL,
  `link_url` text,
  `link_status` enum('p','m','v') NOT NULL DEFAULT 'p',
  `link_date` datetime DEFAULT NULL,
  PRIMARY KEY (`link_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pc_menus_links`
--

INSERT INTO `pc_menus_links` (`link_ID`, `menu_ID`, `link_parrent`, `link_order`, `link_icon`, `link_title`, `link_name`, `link_url`, `link_status`, `link_date`) VALUES
(1, 1, 0, 1, 'fa-home', '', 'Home', 'http://www.esv317.proeminentcode.com/', 'p', '2016-11-10 06:45:51'),
(2, 1, 0, 2, 'fa-folder-open', '', 'Categories', 'http://www.esv317.proeminentcode.com/categories/', 'p', '2016-11-10 06:46:09'),
(3, 1, 0, 3, 'fa-bullhorn', '', 'Products', 'http://www.esv317.proeminentcode.com/products/', 'p', '2016-11-10 06:47:16'),
(4, 1, 0, 4, 'fa-heart', '', 'Account', 'http://www.esv317.proeminentcode.com/member-area/', 'p', '2016-11-10 06:47:30'),
(7, 2, 0, 1, 'fa-shopping-cart', '', 'My Cart', 'http://www.esv317.proeminentcode.com/cart/', 'p', '2016-12-04 04:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `pc_options`
--

CREATE TABLE IF NOT EXISTS `pc_options` (
  `option_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `option_name` varchar(255) NOT NULL,
  `option_value` longtext,
  `option_load` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`option_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=88 ;

--
-- Dumping data for table `pc_options`
--

INSERT INTO `pc_options` (`option_ID`, `option_name`, `option_value`, `option_load`) VALUES
(1, 'url', 'http://www.ce.proeminentcode.com', '1'),
(2, 'site_name', 'Proeminent Code', '1'),
(3, 'site_title', 'Ecommerce Software Script', '1'),
(4, 'website_mainPage', '1', '1'),
(5, 'language', 'en_US', '1'),
(6, 'auto_email', 'auto-reply@yourwebsite.com', '1'),
(8, 'theme', 'Default', '1'),
(9, 'websiteSetting_script_top', '', '1'),
(10, 'websiteSetting_script_bottom', '', '1'),
(11, 'websiteSetting_image_size', '4194304', '1'),
(12, 'websiteSetting_video_size', '0', '1'),
(13, 'shop_status', '1', '1'),
(15, 'shop_currency', 'USD', '1'),
(16, 'shop_currency_ts', 'c', '1'),
(17, 'shop_currency_ds', 'd', '1'),
(18, 'shop_currency_nd', '2', '1'),
(19, 'shop_min_order', '10', '1'),
(20, 'shop_max_order', '1000000', '1'),
(21, 'shop_members_order', '0', '1'),
(22, 'shop_free_shipping', '1', '1'),
(23, 'shop_coupons', '1', '1'),
(24, 'shop_taxes', '24', '1'),
(25, 'shop_weight_unit', 'lb', '1'),
(26, 'shop_dimensions_unit', 'in', '1'),
(27, 'shop_ratings_reviews', '1', '1'),
(28, 'shop_ratings_required', '0', '1'),
(29, 'shop_reviews_verified', '0', '1'),
(30, 'shop_reviews_verified_only', '0', '1'),
(31, 'shop_reviews_auto', '1', '1'),
(32, 'shop_stock_lowStock_notification', '1', '1'),
(33, 'shop_stock_outStock_notification', '1', '1'),
(34, 'shop_stock_low', '10', '1'),
(35, 'shop_stock_out', '0', '1'),
(36, 'shop_stock_hide', '1', '1'),
(37, 'shop_stock_format', 'n', '1'),
(38, 'layout_sidebar', '1', '1'),
(39, 'layout_topMenu', '1', '1'),
(40, 'layout_primaryMenu', '1', '1'),
(41, 'layout_footer_Wigets', '1', '1'),
(42, 'layout_footer_WigetsLayout', '4', '1'),
(43, 'footer_layout_icons', '0', '1'),
(44, 'layout_footer_widget_1', '2', '1'),
(45, 'layout_footer_widget_2', '1', '1'),
(46, 'layout_footer_widget_3', '5', '1'),
(47, 'layout_footer_widget_4', '6', '1'),
(48, 'layout_footer_leftSide', '&copy; 2016 Proeminent Code SRL. All rights reserverd.', '1'),
(49, 'layout_footer_rightSide', 'Power by &lt;a href=&quot;https://www.proeminentcode.com&quot; target=&quot;_blank&quot;&gt;Proeminent Code&lt;/a&gt;', '1'),
(50, 'meta_charset', 'UTF-8', '1'),
(51, 'site_update', '2016-30-05', '1'),
(54, 'shop_shipping_cost_weight', '2.49', '1'),
(55, 'shop_shipping_cost_dimensions', '0.10', '1'),
(56, 'website_blog', '4', '1'),
(57, 'website_products', '2', '1'),
(58, 'website_cart', '3', '1'),
(59, 'member_profile_photo', '1', '1'),
(60, 'member_profile_photo_comments', '0', '1'),
(61, 'member_profile_photo_reviews', '0', '1'),
(62, 'website_payment', '5', '1'),
(63, 'website_login', '6', '1'),
(64, 'website_signup', '7', '1'),
(65, 'website_settings', '8', '1'),
(66, 'website_memberArea', '9', '1'),
(67, 'website_lostPass', '10', '1'),
(68, 'website_logout', '11', '1'),
(69, 'website_invoice', '12', '1'),
(75, 'website_changePass', '17', '1'),
(76, 'website_productZoom', '1', '1'),
(77, 'php_display_errors', '1', '1'),
(78, 'server_mails_hour', '10000000', '1'),
(82, 'products_pagination', '12', '1'),
(83, 'post_pagination', '12', '1'),
(86, 'layout_rightMenu_display', '1', '1'),
(87, 'layout_rightMenu', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pc_orders`
--

CREATE TABLE IF NOT EXISTS `pc_orders` (
  `order_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_products` text NOT NULL,
  `order_member` bigint(20) DEFAULT NULL,
  `order_payer_email` varchar(255) NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_firstname` varchar(255) NOT NULL,
  `order_lastname` varchar(255) NOT NULL,
  `order_company` varchar(100) NOT NULL,
  `order_method` varchar(50) NOT NULL,
  `order_total` varchar(255) NOT NULL,
  `order_discount` varchar(30) NOT NULL,
  `order_taxes` varchar(255) DEFAULT NULL,
  `order_shipping` varchar(255) DEFAULT NULL,
  `order_payment_currency` varchar(255) NOT NULL,
  `order_txn_id` varchar(255) NOT NULL,
  `order_txn_number` varchar(255) DEFAULT NULL,
  `order_receiver_id` varchar(255) DEFAULT NULL,
  `order_receiver_email` varchar(255) NOT NULL,
  `order_payment_type` varchar(255) NOT NULL,
  `order_payment_status` varchar(255) NOT NULL,
  `order_txn_type` varchar(255) NOT NULL,
  `order_payer_status` varchar(255) NOT NULL,
  `order_address_street` varchar(255) NOT NULL,
  `order_address_city` varchar(255) NOT NULL,
  `order_address_state` varchar(255) NOT NULL,
  `order_address_zip` varchar(255) NOT NULL,
  `order_country` varchar(255) NOT NULL,
  `order_address_status` varchar(255) NOT NULL,
  `order_notify_version` varchar(255) NOT NULL,
  `order_verify_sign` varchar(255) NOT NULL,
  `order_payer_id` varchar(255) NOT NULL,
  `order_mc_currency` varchar(255) NOT NULL,
  `order_mc_fee` varchar(255) NOT NULL,
  `order_status` enum('p','a','r') NOT NULL DEFAULT 'p',
  `order_sandbox` enum('1','0') NOT NULL DEFAULT '0',
  `order_update` datetime DEFAULT NULL,
  `order_date` datetime NOT NULL,
  PRIMARY KEY (`order_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_pages`
--

CREATE TABLE IF NOT EXISTS `pc_pages` (
  `page_ID` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(100) NOT NULL,
  `page_url` text NOT NULL,
  `page_keywords` varchar(255) DEFAULT NULL,
  `page_description` varchar(60) DEFAULT NULL,
  `page_role` varchar(50) DEFAULT NULL,
  `page_content` longtext NOT NULL,
  `page_topScript` text,
  `page_bottomScript` text,
  `page_topPHP` text,
  `page_bottomPHP` text,
  `page_css` text,
  `page_blocks` text,
  `page_sidebar` enum('left','right','none') NOT NULL DEFAULT 'right',
  `page_sidebar_ID` varchar(20) DEFAULT NULL,
  `page_slider` enum('1','0') NOT NULL DEFAULT '0',
  `page_slider_ID` bigint(20) DEFAULT '0',
  `page_slider_position` enum('f','b') NOT NULL DEFAULT 'f',
  `page_views` bigint(20) DEFAULT '0',
  `page_status` enum('p','t','d','h','m','g') NOT NULL DEFAULT 'p',
  `page_update` datetime DEFAULT NULL,
  `page_date` datetime NOT NULL,
  PRIMARY KEY (`page_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `pc_pages`
--

INSERT INTO `pc_pages` (`page_ID`, `page_title`, `page_url`, `page_keywords`, `page_description`, `page_role`, `page_content`, `page_topScript`, `page_bottomScript`, `page_topPHP`, `page_bottomPHP`, `page_css`, `page_blocks`, `page_sidebar`, `page_sidebar_ID`, `page_slider`, `page_slider_ID`, `page_slider_position`, `page_views`, `page_status`, `page_update`, `page_date`) VALUES
(1, 'Home', 'home', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(2, 'Products', 'products', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(3, 'Cart', 'cart', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(4, 'Blog', 'blog', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(5, 'Payment', 'payment', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(6, 'Log In', 'log-in', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(7, 'Sign Up', 'sign-up', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(8, 'Settings', 'settings', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(9, 'Member Area', 'member-area', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(10, 'Lost Password', 'lost-password', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(11, 'Log Out', 'log-out', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(12, 'Invoice', 'invoice', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(13, 'Wish List', 'wish-list', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(14, 'Forum', 'forum', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(15, 'Affiliate Program', 'affiliate-program', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(16, 'Subscribe', 'subscribe', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(17, 'Change Password', 'change-password', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00'),
(18, 'Support', 'support', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 'right', '1', '0', 0, 'f', 0, 'p', NULL, '2016-12-20 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_pages_blocks`
--

CREATE TABLE IF NOT EXISTS `pc_pages_blocks` (
  `block_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `block_title` varchar(100) NOT NULL,
  `block_show` enum('1','0') NOT NULL DEFAULT '1',
  `block_type` varchar(50) DEFAULT NULL,
  `block_var_1` varchar(255) DEFAULT NULL,
  `block_var_2` varchar(255) DEFAULT NULL,
  `block_var_3` varchar(255) DEFAULT NULL,
  `block_var_4` varchar(255) DEFAULT NULL,
  `block_var_5` varchar(255) DEFAULT NULL,
  `block_content` longtext,
  `block_status` enum('1','0') NOT NULL DEFAULT '0',
  `block_update` datetime DEFAULT NULL,
  `block_date` datetime NOT NULL,
  PRIMARY KEY (`block_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_plugins`
--

CREATE TABLE IF NOT EXISTS `pc_plugins` (
  `plugin_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `plugin_name` varchar(100) NOT NULL,
  `plugin_url` varchar(255) NOT NULL,
  `plugin_status` enum('1','0') NOT NULL DEFAULT '1',
  `plugin_update` datetime DEFAULT NULL,
  `plugin_date` datetime NOT NULL,
  PRIMARY KEY (`plugin_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_posts`
--

CREATE TABLE IF NOT EXISTS `pc_posts` (
  `post_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_thumbnail` text,
  `post_author` bigint(20) NOT NULL,
  `post_title` varchar(100) NOT NULL,
  `post_url` varchar(255) NOT NULL,
  `post_content` longtext NOT NULL,
  `post_category` varchar(255) DEFAULT NULL,
  `post_keywords` varchar(255) DEFAULT NULL,
  `post_description` varchar(60) DEFAULT NULL,
  `post_status` enum('Draft','Public','Members','Private','Password') NOT NULL DEFAULT 'Public',
  `post_password` varchar(255) DEFAULT NULL,
  `post_views` bigint(20) NOT NULL DEFAULT '0',
  `post_commenting` enum('1','0') NOT NULL DEFAULT '1',
  `post_sidebar` enum('left','right','none') NOT NULL DEFAULT 'none',
  `post_sidebar_ID` varchar(20) DEFAULT NULL,
  `post_update` datetime DEFAULT NULL,
  `post_date` datetime NOT NULL,
  PRIMARY KEY (`post_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_posts_categories`
--

CREATE TABLE IF NOT EXISTS `pc_posts_categories` (
  `category_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_parent` bigint(20) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_url` varchar(500) NOT NULL,
  `category_thumbnail` text,
  `category_banner` text,
  `category_content` text NOT NULL,
  `category_sidebar` enum('left','right','none') NOT NULL DEFAULT 'right',
  `category_sidebar_ID` bigint(20) NOT NULL,
  `category_status` enum('p','u') NOT NULL DEFAULT 'p',
  `category_update` datetime NOT NULL,
  `category_date` datetime NOT NULL,
  PRIMARY KEY (`category_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_products`
--

CREATE TABLE IF NOT EXISTS `pc_products` (
  `product_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_SKU` varchar(255) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_tumbnail` text,
  `product_url` varchar(255) NOT NULL,
  `product_stock` varchar(20) DEFAULT NULL,
  `product_price` varchar(20) NOT NULL,
  `product_sale` varchar(20) NOT NULL,
  `product_about` varchar(255) DEFAULT NULL,
  `product_content` longtext NOT NULL,
  `product_category` text,
  `product_subcategory` varchar(20) DEFAULT NULL,
  `product_brand` varchar(20) NOT NULL,
  `product_feature_1` text,
  `product_feature_2` text,
  `product_feature_3` text,
  `product_tags` varchar(255) DEFAULT NULL,
  `products_linked` text,
  `product_comments` enum('1','0') NOT NULL DEFAULT '1',
  `product_sidebar` enum('none','left','right') NOT NULL DEFAULT 'right',
  `product_sidebar_ID` varchar(20) DEFAULT NULL,
  `product_weight` varchar(32) DEFAULT NULL,
  `product_dimension_length` varchar(32) DEFAULT NULL,
  `product_dimension_width` varchar(32) DEFAULT NULL,
  `product_dimension_height` varchar(32) DEFAULT NULL,
  `product_virtual` enum('1','0') NOT NULL DEFAULT '0',
  `product_downloadable` enum('1','0') NOT NULL DEFAULT '0',
  `product_source` text,
  `product_limits` varchar(20) DEFAULT NULL,
  `product_expiry` varchar(20) DEFAULT NULL,
  `product_sells` bigint(20) NOT NULL DEFAULT '0',
  `product_views` bigint(20) NOT NULL DEFAULT '0',
  `product_css` text,
  `product_vendor` enum('1','0') NOT NULL DEFAULT '0',
  `vendor_ID` bigint(20) DEFAULT NULL,
  `product_rating` varchar(3) NOT NULL DEFAULT '0',
  `product_status` enum('p','u','d','h','t') NOT NULL DEFAULT 'p',
  `product_update` datetime DEFAULT NULL,
  `product_date` datetime NOT NULL,
  PRIMARY KEY (`product_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_products_brands`
--

CREATE TABLE IF NOT EXISTS `pc_products_brands` (
  `brand_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) NOT NULL,
  `brand_url` varchar(255) NOT NULL,
  `brand_content` text,
  `brand_thumbnail` text,
  `brand_banner` text,
  `brand_sidebar` enum('left','right','none') NOT NULL DEFAULT 'right',
  `brand_sidebar_ID` bigint(20) DEFAULT NULL,
  `brand_status` enum('p','u') NOT NULL DEFAULT 'u',
  `brand_update` datetime DEFAULT NULL,
  `brand_date` datetime NOT NULL,
  PRIMARY KEY (`brand_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_products_categories`
--

CREATE TABLE IF NOT EXISTS `pc_products_categories` (
  `category_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_parent` bigint(20) DEFAULT '0',
  `category_name` varchar(100) NOT NULL,
  `category_url` varchar(255) NOT NULL,
  `category_thumbnail` text,
  `category_banner` text NOT NULL,
  `category_content` text,
  `category_sidebar` enum('left','right','none') NOT NULL DEFAULT 'right',
  `category_sidebar_ID` int(11) NOT NULL,
  `category_status` enum('p','u') NOT NULL DEFAULT 'p',
  `category_update` datetime DEFAULT NULL,
  `category_date` datetime NOT NULL,
  PRIMARY KEY (`category_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_products_reviews`
--

CREATE TABLE IF NOT EXISTS `pc_products_reviews` (
  `review_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `review_product` bigint(20) NOT NULL,
  `review_author` bigint(20) NOT NULL,
  `review_content` text NOT NULL,
  `review_rating` int(1) DEFAULT '0',
  `review_user_IP` varchar(100) DEFAULT NULL,
  `review_status` enum('a','p','t','s') NOT NULL DEFAULT 'p',
  `review_update` datetime DEFAULT NULL,
  `review_date` datetime NOT NULL,
  PRIMARY KEY (`review_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_products_virtualDownloadable`
--

CREATE TABLE IF NOT EXISTS `pc_products_virtualDownloadable` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime DEFAULT NULL,
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  `permission_date` datetime NOT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_sidebars`
--

CREATE TABLE IF NOT EXISTS `pc_sidebars` (
  `sidebar_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `sidebar_name` varchar(100) NOT NULL,
  `sidebar_widgets` varchar(255) DEFAULT NULL,
  `sidebar_status` enum('1','0') NOT NULL DEFAULT '1',
  `sidebar_update` datetime DEFAULT NULL,
  `sidebar_date` datetime NOT NULL,
  PRIMARY KEY (`sidebar_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pc_sidebars`
--

INSERT INTO `pc_sidebars` (`sidebar_ID`, `sidebar_name`, `sidebar_widgets`, `sidebar_status`, `sidebar_update`, `sidebar_date`) VALUES
(1, 'Default', NULL, '1', NULL, '2016-11-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_sidebars_widgets`
--

CREATE TABLE IF NOT EXISTS `pc_sidebars_widgets` (
  `widget_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `widget_title` varchar(100) DEFAULT NULL,
  `widget_type` varchar(100) NOT NULL,
  `widget_option_1` varchar(50) DEFAULT NULL,
  `widget_option_2` varchar(50) DEFAULT NULL,
  `widget_option_3` varchar(50) DEFAULT NULL,
  `widget_text` text,
  `widget_status` enum('1','0') NOT NULL DEFAULT '1',
  `widget_update` datetime DEFAULT NULL,
  `widget_date` datetime NOT NULL,
  PRIMARY KEY (`widget_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pc_sidebars_widgets`
--

INSERT INTO `pc_sidebars_widgets` (`widget_ID`, `widget_title`, `widget_type`, `widget_option_1`, `widget_option_2`, `widget_option_3`, `widget_text`, `widget_status`, `widget_update`, `widget_date`) VALUES
(1, 'Footer Widget 1', 'text_html', '', '', NULL, '&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com&quot;&gt;Link 1&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com&quot;&gt;Link 2&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com&quot;&gt;Link 3&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com&quot;&gt;Link 4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com&quot;&gt;Link 5&lt;/a&gt;&lt;/p&gt;', '1', '2016-12-10 10:42:30', '2016-12-10 10:34:26'),
(2, 'Footer Widget 2', 'text_html', '', '', NULL, '&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 1&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 2&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 3&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 5&lt;/a&gt;&lt;/p&gt;', '1', '2016-12-10 10:42:40', '2016-12-10 10:39:47'),
(3, 'Footer Widget 3', 'text_html', '', '', NULL, '&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 1&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 2&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 3&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 5&lt;/a&gt;&lt;/p&gt;', '1', '2016-12-10 10:42:51', '2016-12-10 10:40:01'),
(4, 'Footer Widget 4', 'text_html', '', '', NULL, '&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 1&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 2&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 3&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.proeminentcode.com/&quot;&gt;Link 5&lt;/a&gt;&lt;/p&gt;', '1', '2016-12-10 10:42:59', '2016-12-10 10:40:09'),
(5, 'Search', 'products_search', '', '', NULL, '', '1', NULL, '2016-12-10 14:46:43');

-- --------------------------------------------------------

--
-- Table structure for table `pc_sliders`
--

CREATE TABLE IF NOT EXISTS `pc_sliders` (
  `slider_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `slider_name` varchar(100) NOT NULL,
  `slider_status` enum('1','0') NOT NULL DEFAULT '1',
  `slider_update` datetime DEFAULT NULL,
  `slider_date` datetime NOT NULL,
  PRIMARY KEY (`slider_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_sliders_slides`
--

CREATE TABLE IF NOT EXISTS `pc_sliders_slides` (
  `slide_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `slider_ID` bigint(20) NOT NULL,
  `slide_title` varchar(50) DEFAULT NULL,
  `slide_link` text NOT NULL,
  `slide_caption` varchar(255) DEFAULT NULL,
  `slide_image` text NOT NULL,
  `slide_date` datetime NOT NULL,
  PRIMARY KEY (`slide_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_targets`
--

CREATE TABLE IF NOT EXISTS `pc_targets` (
  `target_ID` int(2) NOT NULL AUTO_INCREMENT,
  `target_time` varchar(30) NOT NULL,
  `target_goal` varchar(30) NOT NULL,
  `target_update` datetime DEFAULT NULL,
  `target_date` datetime NOT NULL,
  PRIMARY KEY (`target_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pc_targets`
--

INSERT INTO `pc_targets` (`target_ID`, `target_time`, `target_goal`, `target_update`, `target_date`) VALUES
(1, 'Daily', '2000', '2016-04-10 04:32:14', '2015-09-27 00:00:00'),
(2, 'Weekly', '1500', NULL, '2015-09-27 00:00:00'),
(3, 'Monthly', '60000', '2016-04-10 04:32:25', '2015-09-27 00:00:00'),
(4, 'Yearly', '720000', '2016-04-10 04:32:36', '2015-09-27 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pc_themes`
--

CREATE TABLE IF NOT EXISTS `pc_themes` (
  `theme_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `theme_name` varchar(100) NOT NULL,
  `theme_status` enum('1','0') NOT NULL DEFAULT '1',
  `theme_path` varchar(255) DEFAULT NULL,
  `theme_author` varchar(255) NOT NULL,
  `theme_description` varchar(500) DEFAULT 'This is a blank theme, feel free to design it',
  `body_text_color` varchar(30) DEFAULT '#333333',
  `body_link_color` varchar(30) DEFAULT '#f0ad4e',
  `body_link_hover` varchar(30) DEFAULT '#f0ad4e',
  `body_font_size` varchar(5) DEFAULT '15px',
  `body_font_family` varchar(100) DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `body_background_color` varchar(30) DEFAULT '#F1F1F1',
  `body_background_image` text,
  `body_background_position` varchar(50) DEFAULT NULL,
  `body_background_repeat` varchar(50) DEFAULT NULL,
  `body_background_size` varchar(50) DEFAULT NULL,
  `wrapper_width` varchar(4) DEFAULT NULL,
  `wrapper_position` enum('f','c') NOT NULL DEFAULT 'f',
  `wrapper_background` varchar(30) DEFAULT '#F1F1F1',
  `header_text_color` varchar(30) DEFAULT '#000000',
  `header_link_color` varchar(30) NOT NULL DEFAULT '#f0ad4e',
  `header_link_hover` varchar(30) NOT NULL DEFAULT '#f0ad4e',
  `header_font_size` varchar(5) DEFAULT '15px',
  `header_font_family` varchar(100) DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `header_background_color` varchar(30) NOT NULL DEFAULT '#ffffff',
  `header_background_image` text,
  `header_background_position` varchar(50) DEFAULT NULL,
  `header_background_repeat` varchar(50) DEFAULT NULL,
  `header_background_size` varchar(50) DEFAULT NULL,
  `menu_link_color` varchar(30) DEFAULT '#777777',
  `menu_link_hover` varchar(30) DEFAULT '#333333',
  `menu_link_hover_background` varchar(30) DEFAULT '#f0ad4e',
  `menu_font_size` varchar(5) DEFAULT '15px',
  `menu_font_family` varchar(100) DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `menu_background_color` varchar(30) DEFAULT '#333',
  `menu_border_color` varchar(30) DEFAULT '#e7e7e7',
  `content_title_color` varchar(30) NOT NULL DEFAULT '#333333',
  `content_title_font_size` varchar(5) NOT NULL DEFAULT '36px',
  `content_title_font_family` varchar(100) NOT NULL DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `product_box_background_color` varchar(30) NOT NULL DEFAULT '#FFFFFF',
  `product_box_border_color` varchar(30) NOT NULL DEFAULT '#FFFFFF',
  `product_name_color` varchar(30) NOT NULL DEFAULT '#f0ad4e',
  `product_name_font_size` varchar(5) NOT NULL DEFAULT '14px',
  `product_name_font_family` varchar(100) NOT NULL DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `product_price_color` varchar(30) NOT NULL DEFAULT '#333333',
  `product_price_font_size` varchar(5) NOT NULL DEFAULT '15px',
  `product_price_font_family` varchar(100) NOT NULL DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `product_button_color` varchar(30) NOT NULL DEFAULT '#FFFFFF',
  `product_button_font_size` varchar(5) NOT NULL DEFAULT '14px',
  `product_button_font_family` varchar(100) NOT NULL DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `product_button_background_color` varchar(30) NOT NULL DEFAULT '#f0ad4e',
  `product_button_border_color` varchar(30) NOT NULL DEFAULT '#eea236',
  `product_button_hover_color` varchar(30) NOT NULL DEFAULT '#FFFFFF',
  `product_button_hover_background_color` varchar(30) NOT NULL DEFAULT '#EC971D',
  `product_button_hover_border_color` varchar(30) NOT NULL DEFAULT '#d58512',
  `cart_color` varchar(30) NOT NULL DEFAULT '#333333',
  `cart_font_size` varchar(5) NOT NULL DEFAULT '14px',
  `cart_font_family` varchar(100) NOT NULL DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `aside_title_color` varchar(30) DEFAULT '#000000',
  `aside_title_font_family` varchar(100) NOT NULL DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `aside_title_font_size` varchar(5) DEFAULT '18px',
  `footer_text_color` varchar(30) DEFAULT '#ffffff',
  `footer_link_color` varchar(30) DEFAULT '#f0ad4e',
  `footer_link_hover` varchar(30) DEFAULT '#f0ad4e',
  `footer_font_size` varchar(5) DEFAULT '15px',
  `footer_font_family` varchar(100) DEFAULT '''Helvetica Neue'',Helvetica,Arial,sans-serif',
  `footer_background_color` varchar(30) DEFAULT '#ffffff',
  `footer_widgets_title_color` varchar(30) DEFAULT '#ffffff',
  `footer_widgets_title_size` varchar(5) DEFAULT '15px',
  `footer_top_background_color` varchar(30) NOT NULL DEFAULT '#1a1a1a',
  `footer_bottom_background_color` varchar(30) NOT NULL DEFAULT '#1c1f21',
  `theme_css` longtext,
  `theme_update` datetime DEFAULT NULL,
  `theme_added` datetime NOT NULL,
  PRIMARY KEY (`theme_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pc_themes`
--

INSERT INTO `pc_themes` (`theme_ID`, `theme_name`, `theme_status`, `theme_path`, `theme_author`, `theme_description`, `body_text_color`, `body_link_color`, `body_link_hover`, `body_font_size`, `body_font_family`, `body_background_color`, `body_background_image`, `body_background_position`, `body_background_repeat`, `body_background_size`, `wrapper_width`, `wrapper_position`, `wrapper_background`, `header_text_color`, `header_link_color`, `header_link_hover`, `header_font_size`, `header_font_family`, `header_background_color`, `header_background_image`, `header_background_position`, `header_background_repeat`, `header_background_size`, `menu_link_color`, `menu_link_hover`, `menu_link_hover_background`, `menu_font_size`, `menu_font_family`, `menu_background_color`, `menu_border_color`, `content_title_color`, `content_title_font_size`, `content_title_font_family`, `product_box_background_color`, `product_box_border_color`, `product_name_color`, `product_name_font_size`, `product_name_font_family`, `product_price_color`, `product_price_font_size`, `product_price_font_family`, `product_button_color`, `product_button_font_size`, `product_button_font_family`, `product_button_background_color`, `product_button_border_color`, `product_button_hover_color`, `product_button_hover_background_color`, `product_button_hover_border_color`, `cart_color`, `cart_font_size`, `cart_font_family`, `aside_title_color`, `aside_title_font_family`, `aside_title_font_size`, `footer_text_color`, `footer_link_color`, `footer_link_hover`, `footer_font_size`, `footer_font_family`, `footer_background_color`, `footer_widgets_title_color`, `footer_widgets_title_size`, `footer_top_background_color`, `footer_bottom_background_color`, `theme_css`, `theme_update`, `theme_added`) VALUES
(1, 'Default', '1', 'default', 'Eduard Stefanescu', 'Meet our favorite theme! First time we designed it we were thinking at Ben & Jerry''s ice cream. This is the reason why it looks so delicious. The theme it''s friendly and perfect for stores that sell food.', '#333333', '#f0ad4e', '#f0ad4e', '15px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#f1f1f1', '', '', '', '', '', 'c', '#f1f1f1', '#000000', '#f0ad4e', '#f0ad4e', '15px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#ffffff', '', '', '', '', '#ffffff', '#ffffff', '#f0ad4e', '15px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#333333', '#e7e7e7', '#333333', '36px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#ffffff', '#ffffff', '#f0ad4e', '15px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#333333', '15px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#ffffff', '14px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#f0ad4e', '#eea236', '#ffffff', '#ec971d', '#d58512', '#333333', '14px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#000000', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '18px', '#1c1f21', '#f0ad4e', '#f0ad4e', '15px', '''Helvetica Neue'',Helvetica,Arial,sans-serif', '#ffffff', '#ffffff', '15px', '#1a1a1a', '#1c1f21', '', NULL, '2016-12-20 09:16:13');

-- --------------------------------------------------------

--
-- Table structure for table `pc_traffic`
--

CREATE TABLE IF NOT EXISTS `pc_traffic` (
  `traffic_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `traffic_code` varchar(32) NOT NULL,
  `traffic_IP` varchar(255) NOT NULL,
  `traffic_country` varchar(255) DEFAULT NULL,
  `traffic_country_code` varchar(255) DEFAULT NULL,
  `traffic_state` varchar(255) CHARACTER SET swe7 DEFAULT NULL,
  `traffic_city` varchar(255) DEFAULT NULL,
  `traffic_page` text NOT NULL,
  `traffic_title` text,
  `traffic_url` text NOT NULL,
  `traffic_from` text,
  `traffic_screen_size` varchar(20) NOT NULL,
  `traffic_browser` varchar(50) NOT NULL,
  `traffic_OS` varchar(30) NOT NULL,
  `traffic_date` datetime NOT NULL,
  PRIMARY KEY (`traffic_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pc_traffic_from`
--

CREATE TABLE IF NOT EXISTS `pc_traffic_from` (
  `from_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `from_where` text NOT NULL,
  `from_times` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`from_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `pc_traffic_from`
--

INSERT INTO `pc_traffic_from` (`from_ID`, `from_where`, `from_times`) VALUES
(1, 'Google', 0),
(2, 'YouTube', 0),
(3, 'Facebook', 0),
(4, 'Instagram', 0),
(5, 'Twitter', 0),
(6, 'LinkedIn', 0),
(7, 'Yahoo', 0),
(8, 'Snapchat', 0),
(9, 'Bing', 0),
(10, 'Pinterest', 0),
(11, 'Unknown', 0);

-- --------------------------------------------------------

--
-- Table structure for table `traffic_browser`
--

CREATE TABLE IF NOT EXISTS `traffic_browser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `browser_name` varchar(50) NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=194 ;

--
-- Dumping data for table `traffic_browser`
--

INSERT INTO `traffic_browser` (`id`, `browser_name`, `views`) VALUES
(2, 'Google Chrome', 0),
(192, 'Windows Mobile', 0),
(4, 'Firefox', 0),
(191, 'Safari', 0),
(8, 'Android Mobile', 0),
(9, 'Browser Unknown', 0),
(10, 'iPhone Mobile', 0),
(11, 'Internet Explorer', 0),
(193, 'Opera', 0);

-- --------------------------------------------------------

--
-- Table structure for table `traffic_countryes`
--

CREATE TABLE IF NOT EXISTS `traffic_countryes` (
  `traffic_country_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `traffic_country_name` varchar(255) NOT NULL,
  `traffic_country_code` varchar(255) NOT NULL,
  `traffic_country_flag` varchar(255) NOT NULL,
  `traffic_country_views` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`traffic_country_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `traffic_countryes`
--

INSERT INTO `traffic_countryes` (`traffic_country_ID`, `traffic_country_name`, `traffic_country_code`, `traffic_country_flag`, `traffic_country_views`) VALUES
(1, 'Romania', 'RO', 'Romania.png', 0),
(2, 'Russian Federation', 'RU', 'Russia.png', 0),
(3, 'United States', 'US', 'United States of America.png', 0),
(4, 'Armenia', 'AM', 'Armenia.png', 0),
(5, 'Brazil', 'BR', 'Brazil.png', 0),
(6, 'China', 'CN', 'China.png', 0),
(7, 'Czech Republic', 'CZ', '', 0),
(8, 'Malaysia', 'MY', '', 0),
(9, 'Mexico', 'MX', '', 0),
(10, 'Palestinian Territory', 'PS', '', 0),
(11, 'Germany', 'DE', '', 0),
(12, 'France', 'FR', '', 0),
(13, 'United Kingdom', 'GB', '', 0),
(14, 'Canada', 'CA', '', 0),
(15, 'Algeria', 'DZ', '', 0),
(16, 'Portugal', 'PT', '', 0),
(18, 'India', 'IN', '', 0),
(19, 'Albania', 'AL', '', 0),
(20, 'Australia', 'AU', '', 0),
(26, 'Poland', 'PL', '', 0),
(22, 'Italy', 'IT', '', 0),
(23, 'Turkey', 'TR', '', 0),
(24, 'Greece', 'GR', '', 0),
(25, 'Ireland', 'IE', '', 0),
(27, 'Bulgaria', 'BG', '', 0),
(28, 'Unknown Country', '', '', 0),
(29, 'Hong Kong', 'HK', '', 0),
(30, 'Cape Verde', 'CV', '', 0),
(31, 'Moldova, Republic of', 'MD', 'Moldova.png', 0),
(32, 'Indonesia', 'ID', '', 0),
(33, 'Pakistan', 'PK', '', 0),
(34, 'Sweden', 'SE', '', 0),
(35, 'Kazakhstan', 'KZ', '', 0),
(36, 'Anonymous Proxy', 'A1', '', 0),
(37, 'Netherlands', 'NL', '', 0),
(38, 'Luxembourg', 'LU', '', 0),
(39, 'Philippines', 'PH', '', 0),
(40, 'Ukraine', 'UA', '', 0),
(41, 'Kenya', 'KE', '', 0),
(42, 'Chile', 'CL', '', 0),
(43, 'Iraq', 'IQ', '', 0),
(44, 'Belgium', 'BE', '', 0),
(45, 'Estonia', 'EE', '', 0),
(46, 'Japan', 'JP', '', 0),
(47, 'Latvia', 'LV', '', 0),
(48, 'Colombia', 'CO', '', 0),
(49, 'Ecuador', 'EC', '', 0),
(50, 'Singapore', 'SG', '', 0),
(51, 'Peru', 'PE', '', 0),
(52, 'Thailand', 'TH', '', 0),
(53, 'Croatia', 'HR', '', 0),
(54, 'Bosnia and Herzegovina', 'BA', 'Bosnia.png', 0),
(55, 'Belarus', 'BY', '', 0),
(56, 'Venezuela', 'VE', '', 0),
(57, 'United Arab Emirates', 'AE', '', 0),
(58, 'Uruguay', 'UY', '', 0),
(59, 'Spain', 'ES', '', 0),
(60, 'Egypt', 'EG', '', 0),
(61, 'Panama', 'PA', '', 0),
(62, 'Paraguay', 'PY', '', 0),
(63, 'Saudi Arabia', 'SA', '', 0),
(64, 'Argentina', 'AR', '', 0),
(65, 'Vietnam', 'VN', '', 0),
(66, 'South Africa', 'ZA', '', 0),
(67, 'Korea, Republic of', 'KR', '', 0),
(68, 'Sri Lanka', 'LK', '', 0),
(69, 'Lebanon', 'LB', '', 0),
(70, 'Morocco', 'MA', '', 0),
(71, 'Taiwan', 'TW', '', 0),
(72, 'Lithuania', 'LT', '', 0),
(73, 'Somalia', 'SO', '', 0),
(74, 'Ethiopia', 'ET', '', 0),
(75, 'Switzerland', 'CH', '', 0),
(76, 'Norway', 'NO', '', 0),
(77, 'Bangladesh', 'BD', '', 0),
(78, 'Ghana', 'GH', '', 0),
(79, 'Denmark', 'DK', '', 0),
(80, 'Libya', 'LY', '', 0),
(81, 'Finland', 'FI', '', 0),
(82, 'Slovakia', 'SK', '', 0),
(83, 'Austria', 'AT', '', 0),
(84, 'Serbia', 'RS', '', 0),
(85, 'Israel', 'IL', '', 0),
(86, 'Hungary', 'HU', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `traffic_OS`
--

CREATE TABLE IF NOT EXISTS `traffic_OS` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `os_name` varchar(50) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `traffic_OS`
--

INSERT INTO `traffic_OS` (`id`, `os_name`, `views`) VALUES
(1, 'Other', 0),
(18, 'Windows 98', 0),
(17, 'Windows 2000', 0),
(7, 'Windows XP', 0),
(8, 'Windows Vista', 0),
(9, 'Windows 7', 0),
(10, 'Windows 8', 0),
(11, 'Windows 10', 0),
(12, 'Linux', 0),
(13, 'Mac OS', 0),
(16, 'Unknown OS', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
